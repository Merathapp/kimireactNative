# حاسبة المواريث الإسلامية - React Native

## نظرة عامة

تطبيق React Native متكامل لحساب المواريث الإسلامية وفق المذاهب الفقهية الأربعة.

## المميزات

### المذاهب الأربعة
- المذهب الشافعي 🟢
- المذهب الحنفي 🔴
- المذهب المالكي 🟣
- المذهب الحنبلي 🔵

### أنواع الورثة المدعومة
- الزوج/الزوجة
- الأب/الأم
- الجد/الجدة
- الأبناء/البنات
- الأحفاد
- الإخوة/الأخوات (أشقاء، لأب، لأم)
- الأعمام/العمات
- الأخوال/الخالات

### الحالات الخاصة
- العول
- الرد
- العُمَريَّة
- المشتركة (الحمارية)
- الأكدرية (الغرّاء)

### الشاشات
1. **الحاسبة** - حساب المواريث مع إمكانية إدخال الورثة
2. **مقارنة** - مقارنة النتائج بين المذاهب الأربعة
3. **اختبارات** - نظام اختبارات شامل (50+ اختبار)
4. **القواعد** - جداول الفروض وقواعد الحجب والحالات الخاصة
5. **السجل** - سجل المراجعة مع إمكانية التصدير
6. **حول** - معلومات عن التطبيق

## هيكل المشروع

```
MerathCalculator/
├── src/
│   ├── components/
│   │   ├── Common/
│   │   │   ├── HeirButton.js
│   │   │   ├── MadhhabSelector.js
│   │   │   └── ResultsCard.js
│   │   └── Calculator/
│   │       └── HeirSection.js
│   ├── screens/
│   │   ├── CalculatorScreen.js
│   │   ├── ComparisonScreen.js
│   │   ├── TestsScreen.js
│   │   ├── RulesScreen.js
│   │   ├── AuditScreen.js
│   │   └── AboutScreen.js
│   ├── navigation/
│   │   └── AppNavigator.js
│   ├── core/
│   │   ├── Fraction.js
│   │   ├── InheritanceEngine.js
│   │   ├── FiqhDatabase.js
│   │   ├── TestSuite.js
│   │   ├── AuditLog.js
│   │   └── index.js
│   └── utils/
├── assets/
│   ├── icon.png
│   ├── adaptive-icon.png
│   ├── splash.png
│   └── favicon.png
├── App.js
├── index.js
├── app.json
└── package.json
```

## التثبيت

```bash
# تثبيت التبعيات
npm install

# تشغيل على Android
npm run android

# تشغيل على iOS
npm run ios

# تشغيل على الويب
npm run web
```

## البناء

```bash
# بناء APK
expo build:android

# بناء IPA
expo build:ios
```

## المتطلبات

- Node.js 16+
- React Native CLI
- Android Studio (للبناء على Android)
- Xcode (للبناء على iOS)

## المطور

أبو حسن النسي

## الترخيص

MIT License
