import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Alert,
  Share,
} from 'react-native';
import { AuditLog, MADHABS_LIST } from '../core';

const AuditScreen = () => {
  const [logs, setLogs] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  const auditLog = new AuditLog();

  useEffect(() => {
    loadLogs();
  }, []);

  const loadLogs = async () => {
    setLoading(true);
    await auditLog.load();
    setLogs(auditLog.getAll());
    setStats(auditLog.getStatistics());
    setLoading(false);
  };

  const clearLogs = () => {
    Alert.alert(
      'تأكيد',
      'هل أنت متأكد من مسح جميع السجلات؟',
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'مسح',
          style: 'destructive',
          onPress: async () => {
            await auditLog.clear();
            loadLogs();
          },
        },
      ]
    );
  };

  const exportLogs = async () => {
    try {
      const json = auditLog.exportToJSON();
      await Share.share({
        message: json,
        title: 'سجل مراجعة حاسبة المواريث',
      });
    } catch (error) {
      Alert.alert('خطأ', 'فشل في تصدير السجلات');
    }
  };

  const formatDate = (timestamp) => {
    const date = new Date(timestamp);
    return date.toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getLogTypeLabel = (type) => {
    const labels = {
      calculation: 'حساب',
      test_run: 'اختبار',
      comparison: 'مقارنة',
      export: 'تصدير',
    };
    return labels[type] || type;
  };

  const getLogTypeColor = (type) => {
    const colors = {
      calculation: '#4f46e5',
      test_run: '#10b981',
      comparison: '#f59e0b',
      export: '#8b5cf6',
    };
    return colors[type] || '#64748b';
  };

  const getMadhhabName = (id) => {
    const madhhab = MADHABS_LIST.find((m) => m.id === id);
    return madhhab ? madhhab.name : id;
  };

  const renderStats = () => {
    if (!stats) return null;

    return (
      <View style={styles.statsContainer}>
        <Text style={styles.statsTitle}>إحصائيات السجل:</Text>
        <View style={styles.statsGrid}>
          <View style={styles.statBox}>
            <Text style={styles.statValue}>{stats.total}</Text>
            <Text style={styles.statLabel}>إجمالي السجلات</Text>
          </View>
          
          {Object.entries(stats.byType).map(([type, count]) => (
            <View key={type} style={styles.statBox}>
              <Text style={[styles.statValue, { color: getLogTypeColor(type) }]}>
                {count}
              </Text>
              <Text style={styles.statLabel}>{getLogTypeLabel(type)}</Text>
            </View>
          ))}
        </View>

        {stats.byMadhhab && Object.keys(stats.byMadhhab).length > 0 && (
          <View style={styles.madhhabStats}>
            <Text style={styles.madhhabStatsTitle}>حسب المذهب:</Text>
            {Object.entries(stats.byMadhhab).map(([madhhab, count]) => (
              <View key={madhhab} style={styles.madhhabStatRow}>
                <Text style={styles.madhhabStatName}>
                  {getMadhhabName(madhhab)}
                </Text>
                <Text style={styles.madhhabStatCount}>{count}</Text>
              </View>
            ))}
          </View>
        )}
      </View>
    );
  };

  const renderLogs = () => {
    if (logs.length === 0) {
      return (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyText}>لا توجد سجلات حتى الآن</Text>
        </View>
      );
    }

    return (
      <View style={styles.logsContainer}>
        <Text style={styles.logsTitle}>السجلات:</Text>
        {logs.map((log) => (
          <View key={log.id} style={styles.logCard}>
            <View style={styles.logHeader}>
              <View
                style={[
                  styles.logTypeBadge,
                  { backgroundColor: getLogTypeColor(log.type) },
                ]}
              >
                <Text style={styles.logTypeText}>
                  {getLogTypeLabel(log.type)}
                </Text>
              </View>
              <Text style={styles.logDate}>{formatDate(log.timestamp)}</Text>
            </View>

            {log.madhhab && (
              <View style={styles.logDetail}>
                <Text style={styles.logDetailLabel}>المذهب:</Text>
                <Text style={styles.logDetailValue}>
                  {getMadhhabName(log.madhhab)}
                </Text>
              </View>
            )}

            {log.heirs && (
              <View style={styles.logDetail}>
                <Text style={styles.logDetailLabel}>الورثة:</Text>
                <Text style={styles.logDetailValue}>
                  {Object.entries(log.heirs)
                    .map(([k, v]) => `${k}: ${v}`)
                    .join(', ')}
                </Text>
              </View>
            )}

            {log.summary && (
              <View style={styles.logSummary}>
                {log.summary.heirsCount && (
                  <Text style={styles.summaryText}>
                    عدد الورثة: {log.summary.heirsCount}
                  </Text>
                )}
                {log.summary.totalShares && (
                  <Text style={styles.summaryText}>
                    مجموع الحصص: {log.summary.totalShares}
                  </Text>
                )}
                {log.summary.specialCase && (
                  <Text style={[styles.summaryText, styles.specialCaseText]}>
                    حالة خاصة: {log.summary.specialCase}
                  </Text>
                )}
              </View>
            )}
          </View>
        ))}
      </View>
    );
  };

  return (
    <ScrollView style={styles.container}>
      {/* أزرار التحكم */}
      <View style={styles.buttonsContainer}>
        <TouchableOpacity style={styles.exportButton} onPress={exportLogs}>
          <Text style={styles.exportButtonText}>تصدير السجلات</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.clearButton} onPress={clearLogs}>
          <Text style={styles.clearButtonText}>مسح الكل</Text>
        </TouchableOpacity>
      </View>

      {/* الإحصائيات */}
      {renderStats()}

      {/* السجلات */}
      {renderLogs()}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
    padding: 16,
  },
  buttonsContainer: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  exportButton: {
    flex: 1,
    backgroundColor: '#4f46e5',
    paddingVertical: 12,
    borderRadius: 8,
    marginLeft: 8,
    alignItems: 'center',
  },
  exportButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  clearButton: {
    backgroundColor: '#fef2f2',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#fecaca',
  },
  clearButtonText: {
    color: '#dc2626',
    fontSize: 14,
    fontWeight: '600',
  },
  statsContainer: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    elevation: 2,
  },
  statsTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 12,
    textAlign: 'right',
  },
  statsGrid: {
    flexDirection: 'row-reverse',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  statBox: {
    alignItems: 'center',
    backgroundColor: '#f8fafc',
    padding: 12,
    borderRadius: 8,
    minWidth: '30%',
    marginBottom: 8,
  },
  statValue: {
    fontSize: 20,
    fontWeight: '700',
    color: '#1e293b',
  },
  statLabel: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 4,
  },
  madhhabStats: {
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
  },
  madhhabStatsTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#475569',
    marginBottom: 8,
    textAlign: 'right',
  },
  madhhabStatRow: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    paddingVertical: 6,
  },
  madhhabStatName: {
    fontSize: 13,
    color: '#64748b',
  },
  madhhabStatCount: {
    fontSize: 13,
    fontWeight: '600',
    color: '#1e293b',
  },
  emptyContainer: {
    padding: 40,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 16,
    color: '#94a3b8',
  },
  logsContainer: {
    marginBottom: 16,
  },
  logsTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 12,
    textAlign: 'right',
  },
  logCard: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 12,
    marginBottom: 8,
    elevation: 1,
  },
  logHeader: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  logTypeBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  logTypeText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
  },
  logDate: {
    fontSize: 12,
    color: '#94a3b8',
  },
  logDetail: {
    flexDirection: 'row-reverse',
    marginBottom: 4,
  },
  logDetailLabel: {
    fontSize: 12,
    color: '#64748b',
    marginLeft: 4,
  },
  logDetailValue: {
    fontSize: 12,
    color: '#1e293b',
    flex: 1,
    textAlign: 'right',
  },
  logSummary: {
    backgroundColor: '#f8fafc',
    borderRadius: 6,
    padding: 8,
    marginTop: 8,
  },
  summaryText: {
    fontSize: 12,
    color: '#475569',
  },
  specialCaseText: {
    color: '#f59e0b',
  },
});

export default AuditScreen;
