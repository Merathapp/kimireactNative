import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { InheritanceEngine, MADHABS_LIST, FIQH_DATABASE } from '../core';
import HeirSection from '../components/Calculator/HeirSection';

const ComparisonScreen = () => {
  const [heirs, setHeirs] = useState({});
  const [comparisonResults, setComparisonResults] = useState(null);

  const heirCategories = {
    spouses: [
      { key: 'husband', name: 'زوج', color: '#8b5cf6' },
      { key: 'wife', name: 'زوجة', color: '#ec4899' },
    ],
    parents: [
      { key: 'father', name: 'أب', color: '#3b82f6' },
      { key: 'mother', name: 'أم', color: '#06b6d4' },
      { key: 'grandfather', name: 'جد', color: '#6366f1' },
      { key: 'grandmother', name: 'جدة', color: '#a855f7' },
    ],
    children: [
      { key: 'son', name: 'ابن', color: '#10b981' },
      { key: 'daughter', name: 'بنت', color: '#f59e0b' },
      { key: 'grandson', name: 'ابن الابن', color: '#14b8a6' },
      { key: 'granddaughter', name: 'بنت الابن', color: '#f97316' },
    ],
    siblings: [
      { key: 'full_brother', name: 'أخ شقيق', color: '#ef4444' },
      { key: 'full_sister', name: 'أخت شقيقة', color: '#f43f5e' },
      { key: 'paternal_brother', name: 'أخ لأب', color: '#dc2626' },
      { key: 'paternal_sister', name: 'أخت لأب', color: '#e11d48' },
      { key: 'maternal_brother', name: 'أخ لأم', color: '#b91c1c' },
      { key: 'maternal_sister', name: 'أخت لأم', color: '#be123c' },
    ],
  };

  const addHeir = (heirType) => {
    setHeirs((prev) => ({
      ...prev,
      [heirType]: (prev[heirType] || 0) + 1,
    }));
    setComparisonResults(null);
  };

  const removeHeir = (heirType) => {
    setHeirs((prev) => {
      const newHeirs = { ...prev };
      if (newHeirs[heirType] > 1) {
        newHeirs[heirType]--;
      } else {
        delete newHeirs[heirType];
      }
      return newHeirs;
    });
    setComparisonResults(null);
  };

  const clearAll = () => {
    setHeirs({});
    setComparisonResults(null);
  };

  const compare = () => {
    if (Object.keys(heirs).length === 0) {
      Alert.alert('تنبيه', 'الرجاء إضافة ورثة أولاً');
      return;
    }

    const results = {};
    
    for (const madhhab of MADHABS_LIST) {
      try {
        const engine = new InheritanceEngine(madhhab.id);
        
        for (const [heirType, count] of Object.entries(heirs)) {
          engine.addHeir(heirType, count);
        }
        
        const result = engine.calculate();
        results[madhhab.id] = result;
      } catch (error) {
        results[madhhab.id] = { error: error.message };
      }
    }
    
    setComparisonResults(results);
  };

  const getHeirsWithCount = (categoryHeirs) => {
    return categoryHeirs.map((heir) => ({
      ...heir,
      count: heirs[heir.key] || 0,
    }));
  };

  const renderComparisonTable = () => {
    if (!comparisonResults) return null;

    // جمع جميع أنواع الورثة من جميع المذاهب
    const allHeirTypes = new Set();
    for (const madhhab of MADHABS_LIST) {
      const result = comparisonResults[madhhab.id];
      if (result && result.results) {
        for (const r of result.results) {
          allHeirTypes.add(r.type);
        }
      }
    }

    const heirTypesArray = Array.from(allHeirTypes);

    return (
      <View style={styles.tableContainer}>
        <Text style={styles.tableTitle}>جدول المقارنة:</Text>
        
        {/* رأس الجدول */}
        <View style={styles.tableHeader}>
          <View style={styles.heirNameCell}>
            <Text style={styles.headerText}>الوارث</Text>
          </View>
          {MADHABS_LIST.map((madhhab) => (
            <View key={madhhab.id} style={styles.madhhabCell}>
              <Text style={[styles.headerText, { color: madhhab.color }]}>
                {madhhab.name}
              </Text>
            </View>
          ))}
        </View>

        {/* صفوف الجدول */}
        {heirTypesArray.map((heirType) => (
          <View key={heirType} style={styles.tableRow}>
            <View style={styles.heirNameCell}>
              <Text style={styles.heirNameText}>
                {FIQH_DATABASE.heirNames[heirType] || heirType}
              </Text>
            </View>
            {MADHABS_LIST.map((madhhab) => {
              const result = comparisonResults[madhhab.id];
              const heirResult = result?.results?.find((r) => r.type === heirType);
              
              return (
                <View key={madhhab.id} style={styles.madhhabCell}>
                  <Text style={styles.shareText}>
                    {heirResult ? heirResult.shareArabic : '-'}
                  </Text>
                  {heirResult && heirResult.note && (
                    <Text style={styles.noteText}>{heirResult.note}</Text>
                  )}
                </View>
              );
            })}
          </View>
        ))}

        {/* الحالات الخاصة */}
        <View style={styles.specialCasesRow}>
          <View style={styles.heirNameCell}>
            <Text style={styles.specialCasesLabel}>الحالة الخاصة:</Text>
          </View>
          {MADHABS_LIST.map((madhhab) => {
            const result = comparisonResults[madhhab.id];
            const specialCase = result?.specialCase;
            
            return (
              <View key={madhhab.id} style={styles.madhhabCell}>
                <Text style={styles.specialCaseText}>
                  {specialCase
                    ? specialCase === 'umariyyah'
                      ? 'العمرية'
                      : specialCase === 'musharraka'
                      ? 'المشتركة'
                      : specialCase === 'akdariyya'
                      ? 'الأكدرية'
                      : specialCase
                    : '-'}
                </Text>
              </View>
            );
          })}
        </View>

        {/* العول */}
        <View style={styles.awlRow}>
          <View style={styles.heirNameCell}>
            <Text style={styles.awlLabel}>العول:</Text>
          </View>
          {MADHABS_LIST.map((madhhab) => {
            const result = comparisonResults[madhhab.id];
            const awlFactor = result?.awlFactor;
            
            return (
              <View key={madhhab.id} style={styles.madhhabCell}>
                <Text style={styles.awlText}>
                  {awlFactor ? `من ${awlFactor}` : 'لا يوجد'}
                </Text>
              </View>
            );
          })}
        </View>
      </View>
    );
  };

  return (
    <ScrollView style={styles.container}>
      {/* الورثة */}
      <View style={styles.heirsContainer}>
        <Text style={styles.sectionTitle}>اختر الورثة للمقارنة:</Text>
        
        <HeirSection
          title="الزوج/الزوجة:"
          heirs={getHeirsWithCount(heirCategories.spouses)}
          onAdd={addHeir}
          onRemove={removeHeir}
        />
        
        <HeirSection
          title="الأب/الأم/الجد/الجدة:"
          heirs={getHeirsWithCount(heirCategories.parents)}
          onAdd={addHeir}
          onRemove={removeHeir}
        />
        
        <HeirSection
          title="الأبناء/البنات/الأحفاد:"
          heirs={getHeirsWithCount(heirCategories.children)}
          onAdd={addHeir}
          onRemove={removeHeir}
        />
        
        <HeirSection
          title="الإخوة/الأخوات:"
          heirs={getHeirsWithCount(heirCategories.siblings)}
          onAdd={addHeir}
          onRemove={removeHeir}
        />
      </View>

      {/* أزرار التحكم */}
      <View style={styles.buttonsContainer}>
        <TouchableOpacity style={styles.compareButton} onPress={compare}>
          <Text style={styles.compareButtonText}>مقارنة المذاهب</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.clearButton} onPress={clearAll}>
          <Text style={styles.clearButtonText}>مسح الكل</Text>
        </TouchableOpacity>
      </View>

      {/* جدول المقارنة */}
      {renderComparisonTable()}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
    padding: 16,
  },
  heirsContainer: {
    marginVertical: 8,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 12,
    textAlign: 'right',
  },
  buttonsContainer: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    marginVertical: 16,
  },
  compareButton: {
    flex: 1,
    backgroundColor: '#4f46e5',
    paddingVertical: 14,
    paddingHorizontal: 24,
    borderRadius: 10,
    marginLeft: 8,
    elevation: 3,
  },
  compareButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
    textAlign: 'center',
  },
  clearButton: {
    backgroundColor: '#f1f5f9',
    paddingVertical: 14,
    paddingHorizontal: 24,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  clearButtonText: {
    color: '#64748b',
    fontSize: 16,
    fontWeight: '600',
  },
  tableContainer: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginVertical: 16,
    elevation: 2,
  },
  tableTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 16,
    textAlign: 'right',
  },
  tableHeader: {
    flexDirection: 'row-reverse',
    borderBottomWidth: 2,
    borderBottomColor: '#e2e8f0',
    paddingBottom: 8,
    marginBottom: 8,
  },
  tableRow: {
    flexDirection: 'row-reverse',
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
    paddingVertical: 10,
  },
  specialCasesRow: {
    flexDirection: 'row-reverse',
    borderTopWidth: 2,
    borderTopColor: '#e2e8f0',
    paddingTop: 12,
    marginTop: 8,
  },
  awlRow: {
    flexDirection: 'row-reverse',
    paddingTop: 8,
  },
  heirNameCell: {
    width: 100,
    paddingHorizontal: 4,
  },
  madhhabCell: {
    flex: 1,
    paddingHorizontal: 4,
    alignItems: 'center',
  },
  headerText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#475569',
    textAlign: 'center',
  },
  heirNameText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#1e293b',
    textAlign: 'right',
  },
  shareText: {
    fontSize: 14,
    fontWeight: '700',
    color: '#059669',
    textAlign: 'center',
  },
  noteText: {
    fontSize: 10,
    color: '#f59e0b',
    textAlign: 'center',
    marginTop: 2,
  },
  specialCasesLabel: {
    fontSize: 13,
    fontWeight: '600',
    color: '#7c3aed',
  },
  specialCaseText: {
    fontSize: 12,
    color: '#7c3aed',
    textAlign: 'center',
  },
  awlLabel: {
    fontSize: 13,
    fontWeight: '600',
    color: '#dc2626',
  },
  awlText: {
    fontSize: 12,
    color: '#dc2626',
    textAlign: 'center',
  },
});

export default ComparisonScreen;
