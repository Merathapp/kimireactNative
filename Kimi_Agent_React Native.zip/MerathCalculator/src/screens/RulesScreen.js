import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';
import { MADHABS_LIST, SPECIAL_CASES, FIQH_DATABASE } from '../core';

const RulesScreen = () => {
  const [selectedMadhhab, setSelectedMadhhab] = useState('shafii');
  const [activeTab, setActiveTab] = useState('shares');

  const madhhab = MADHABS_LIST.find((m) => m.id === selectedMadhhab);

  const tabs = [
    { key: 'shares', label: 'جدول الفروض' },
    { key: 'blocking', label: 'قواعد الحجب' },
    { key: 'special', label: 'الحالات الخاصة' },
    { key: 'rules', label: 'قواعد المذهب' },
  ];

  const renderSharesTable = () => {
    const shares = [
      { heir: 'الزوج', withChildren: '1/4', withoutChildren: '1/2' },
      { heir: 'الزوجة', withChildren: '1/8', withoutChildren: '1/4' },
      { heir: 'الأب', withChildren: '1/6', withoutChildren: 'الباقي' },
      { heir: 'الأم', withChildren: '1/6', withoutChildren: '1/3' },
      { heir: 'الجد', withChildren: '1/6', withoutChildren: 'الباقي' },
      { heir: 'الجدة', withChildren: '1/6', withoutChildren: '1/6' },
      { heir: 'البنت', withChildren: '0', withoutChildren: '1/2 أو 2/3' },
      { heir: 'ابن الابن', withChildren: '0', withoutChildren: 'الباقي' },
      { heir: 'الأخ الشقيق', withChildren: '0', withoutChildren: 'الباقي' },
      { heir: 'الأخت الشقيقة', withChildren: '0', withoutChildren: '1/2 أو 2/3' },
      { heir: 'الأخ لأم', withChildren: '0', withoutChildren: '1/6 أو 1/3' },
      { heir: 'الأخت لأم', withChildren: '0', withoutChildren: '1/6 أو 1/3' },
    ];

    return (
      <View style={styles.tableContainer}>
        <View style={styles.tableHeader}>
          <Text style={[styles.tableHeaderCell, { flex: 2 }]}>الوارث</Text>
          <Text style={styles.tableHeaderCell}>مع فرع وارث</Text>
          <Text style={styles.tableHeaderCell}>بدون فرع وارث</Text>
        </View>
        {shares.map((share, index) => (
          <View key={index} style={styles.tableRow}>
            <Text style={[styles.tableCell, { flex: 2, fontWeight: '600' }]}>
              {share.heir}
            </Text>
            <Text style={styles.tableCell}>{share.withChildren}</Text>
            <Text style={styles.tableCell}>{share.withoutChildren}</Text>
          </View>
        ))}
      </View>
    );
  };

  const renderBlockingRules = () => {
    const rules = [
      { blocked: 'الجد', blocker: 'الأب', reason: 'الأب يحجب الجد' },
      { blocked: 'الجدة', blocker: 'الأم', reason: 'الأم تحجب الجدة' },
      { blocked: 'ابن الابن', blocker: 'الابن', reason: 'الابن يحجب ابن الابن' },
      { blocked: 'بنت الابن', blocker: 'البنت', reason: 'البنت تحجب بنت الابن' },
      { blocked: 'بنت الابن', blocker: 'الابن', reason: 'الابن يحجب بنت الابن' },
      { blocked: 'الإخوة', blocker: 'الأب/الجد', reason: 'الأب أو الجد يحجبان الإخوة' },
      { blocked: 'الأخوات لأب', blocker: 'الإخوة الأشقاء', reason: 'الإخوة الأشقاء يحجبون الإخوة لأب' },
      { blocked: 'الإخوة لأم', blocker: 'الأبناء', reason: 'الأبناء يحجبون الإخوة لأم' },
    ];

    return (
      <View style={styles.rulesContainer}>
        {rules.map((rule, index) => (
          <View key={index} style={styles.ruleCard}>
            <View style={styles.ruleHeader}>
              <Text style={styles.blockedText}>{rule.blocked}</Text>
              <Text style={styles.arrow}>←</Text>
              <Text style={styles.blockerText}>{rule.blocker}</Text>
            </View>
            <Text style={styles.ruleReason}>{rule.reason}</Text>
          </View>
        ))}
      </View>
    );
  };

  const renderSpecialCases = () => {
    return (
      <View style={styles.specialCasesContainer}>
        {Object.entries(SPECIAL_CASES).map(([key, caseData]) => (
          <View key={key} style={styles.specialCaseCard}>
            <Text style={styles.specialCaseName}>{caseData.name}</Text>
            <Text style={styles.specialCaseDescription}>
              {caseData.description}
            </Text>
            {caseData.examples && (
              <View style={styles.examplesContainer}>
                <Text style={styles.examplesTitle}>أمثلة:</Text>
                {caseData.examples.map((example, idx) => (
                  <View key={idx} style={styles.exampleRow}>
                    <Text style={styles.exampleName}>• {example.name}</Text>
                    <Text style={styles.exampleHeirs}>
                      {Object.entries(example.heirs)
                        .map(([k, v]) => `${FIQH_DATABASE.heirNames[k] || k}: ${v}`)
                        .join(', ')}
                    </Text>
                  </View>
                ))}
              </View>
            )}
          </View>
        ))}
      </View>
    );
  };

  const renderMadhhabRules = () => {
    if (!madhhab) return null;

    const rules = [
      { label: 'الجد مع الإخوة', value: madhhab.rules.grandfatherWithSiblings === 'blocks' ? 'يحجب' : 'يُقاسم' },
      { label: 'الرد على الزوجين', value: madhhab.rules.raddToSpouse ? 'نعم' : 'لا' },
      { label: 'ذوو الأرحام', value: madhhab.rules.bloodRelativesEnabled ? 'معتبرون' : 'غير معتبرين' },
      { label: 'المشتركة', value: madhhab.rules.musharrakaEnabled ? 'معتبرة' : 'غير معتبرة' },
      { label: 'الأكدرية', value: madhhab.rules.akdariyyaEnabled ? 'معتبرة' : 'غير معتبرة' },
    ];

    return (
      <View style={styles.madhhabRulesContainer}>
        <View style={[styles.madhhabHeader, { backgroundColor: madhhab.lightColor }]}>
          <Text style={[styles.madhhabIcon, { color: madhhab.color }]}>
            {madhhab.icon}
          </Text>
          <Text style={[styles.madhhabName, { color: madhhab.color }]}>
            {madhhab.name}
          </Text>
        </View>
        <Text style={styles.madhhabDescription}>{madhhab.description}</Text>
        
        <View style={styles.rulesList}>
          {rules.map((rule, index) => (
            <View key={index} style={styles.ruleItem}>
              <Text style={styles.ruleLabel}>{rule.label}:</Text>
              <Text style={[styles.ruleValue, { color: madhhab.color }]}>
                {rule.value}
              </Text>
            </View>
          ))}
        </View>
      </View>
    );
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'shares':
        return renderSharesTable();
      case 'blocking':
        return renderBlockingRules();
      case 'special':
        return renderSpecialCases();
      case 'rules':
        return renderMadhhabRules();
      default:
        return null;
    }
  };

  return (
    <ScrollView style={styles.container}>
      {/* اختيار المذهب */}
      <View style={styles.madhhabSelector}>
        <Text style={styles.sectionTitle}>اختر المذهب:</Text>
        <View style={styles.madhhabButtons}>
          {MADHABS_LIST.map((m) => (
            <TouchableOpacity
              key={m.id}
              style={[
                styles.madhhabButton,
                selectedMadhhab === m.id && { backgroundColor: m.color },
              ]}
              onPress={() => setSelectedMadhhab(m.id)}
            >
              <Text
                style={[
                  styles.madhhabButtonText,
                  selectedMadhhab === m.id && styles.selectedMadhhabText,
                ]}
              >
                {m.icon} {m.name}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* علامات التبويب */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.tabsContainer}
        contentContainerStyle={styles.tabsContent}
      >
        {tabs.map((tab) => (
          <TouchableOpacity
            key={tab.key}
            style={[
              styles.tabButton,
              activeTab === tab.key && styles.activeTab,
            ]}
            onPress={() => setActiveTab(tab.key)}
          >
            <Text
              style={[
                styles.tabText,
                activeTab === tab.key && styles.activeTabText,
              ]}
            >
              {tab.label}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* المحتوى */}
      <View style={styles.contentContainer}>{renderContent()}</View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
    padding: 16,
  },
  madhhabSelector: {
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 12,
    textAlign: 'right',
  },
  madhhabButtons: {
    flexDirection: 'row-reverse',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  madhhabButton: {
    backgroundColor: '#f1f5f9',
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 8,
    marginBottom: 8,
    minWidth: '23%',
    alignItems: 'center',
  },
  madhhabButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#475569',
  },
  selectedMadhhabText: {
    color: '#fff',
  },
  tabsContainer: {
    marginBottom: 16,
  },
  tabsContent: {
    paddingHorizontal: 4,
  },
  tabButton: {
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 20,
    backgroundColor: '#f1f5f9',
    marginHorizontal: 4,
  },
  activeTab: {
    backgroundColor: '#4f46e5',
  },
  tabText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#64748b',
  },
  activeTabText: {
    color: '#fff',
  },
  contentContainer: {
    marginBottom: 16,
  },
  tableContainer: {
    backgroundColor: '#fff',
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 2,
  },
  tableHeader: {
    flexDirection: 'row-reverse',
    backgroundColor: '#f1f5f9',
    paddingVertical: 12,
    paddingHorizontal: 8,
  },
  tableHeaderCell: {
    flex: 1,
    fontSize: 13,
    fontWeight: '700',
    color: '#475569',
    textAlign: 'center',
  },
  tableRow: {
    flexDirection: 'row-reverse',
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
    paddingVertical: 12,
    paddingHorizontal: 8,
  },
  tableCell: {
    flex: 1,
    fontSize: 14,
    color: '#1e293b',
    textAlign: 'center',
  },
  rulesContainer: {
    marginBottom: 16,
  },
  ruleCard: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 12,
    marginBottom: 8,
    elevation: 1,
  },
  ruleHeader: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  blockedText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#dc2626',
  },
  arrow: {
    fontSize: 18,
    color: '#94a3b8',
    marginHorizontal: 12,
  },
  blockerText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#059669',
  },
  ruleReason: {
    fontSize: 13,
    color: '#64748b',
    textAlign: 'center',
  },
  specialCasesContainer: {
    marginBottom: 16,
  },
  specialCaseCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
  },
  specialCaseName: {
    fontSize: 18,
    fontWeight: '700',
    color: '#7c3aed',
    marginBottom: 8,
    textAlign: 'right',
  },
  specialCaseDescription: {
    fontSize: 14,
    color: '#475569',
    lineHeight: 22,
    textAlign: 'right',
    marginBottom: 12,
  },
  examplesContainer: {
    backgroundColor: '#f8fafc',
    borderRadius: 8,
    padding: 12,
  },
  examplesTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#64748b',
    marginBottom: 8,
  },
  exampleRow: {
    marginBottom: 8,
  },
  exampleName: {
    fontSize: 13,
    fontWeight: '600',
    color: '#1e293b',
  },
  exampleHeirs: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 2,
  },
  madhhabRulesContainer: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    elevation: 2,
  },
  madhhabHeader: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 12,
    borderRadius: 8,
    marginBottom: 12,
  },
  madhhabIcon: {
    fontSize: 24,
    marginLeft: 8,
  },
  madhhabName: {
    fontSize: 20,
    fontWeight: '700',
  },
  madhhabDescription: {
    fontSize: 14,
    color: '#475569',
    lineHeight: 22,
    textAlign: 'right',
    marginBottom: 16,
  },
  rulesList: {
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
    paddingTop: 12,
  },
  ruleItem: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  ruleLabel: {
    fontSize: 14,
    color: '#475569',
  },
  ruleValue: {
    fontSize: 14,
    fontWeight: '700',
  },
});

export default RulesScreen;
