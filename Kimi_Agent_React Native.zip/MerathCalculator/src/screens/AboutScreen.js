import React from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Linking,
  TouchableOpacity,
} from 'react-native';

const AboutScreen = () => {
  const appInfo = {
    name: 'حاسبة المواريث الإسلامية',
    version: '5.0.0',
    developer: 'أبو حسن النسي',
    description:
      'النظام الاحترافي المتكامل لحساب المواريث الإسلامية وفق المذاهب الأربعة',
  };

  const features = [
    {
      icon: '⚖️',
      title: 'المذاهب الأربعة',
      description: 'دعم كامل للمذاهب الفقهية الأربعة (الشافعي، الحنفي، المالكي، الحنبلي)',
    },
    {
      icon: '👨‍👩‍👧‍👦',
      title: 'جميع أنواع الورثة',
      description: 'دعم جميع أنواع الورثة من الزوجين والأبوين والأبناء والأحفاد والإخوة وغيرهم',
    },
    {
      icon: '📊',
      title: 'الحالات الخاصة',
      description: 'معالجة الحالات الخاصة مثل العول والرد والعمرية والمشتركة والأكدرية',
    },
    {
      icon: '🔍',
      title: 'مقارنة المذاهب',
      description: 'إمكانية مقارنة النتائج بين المذاهب الأربعة في نفس المسألة',
    },
    {
      icon: '✅',
      title: 'نظام اختبارات',
      description: 'نظام اختبارات شامل للتحقق من صحة الحسابات',
    },
    {
      icon: '📜',
      title: 'القواعد الفقهية',
      description: 'قاعدة بيانات شاملة للقواعد الفقهية والفروض والحجب',
    },
  ];

  const madhabs = [
    {
      name: 'الشافعي',
      icon: '🟢',
      color: '#059669',
      description: 'الرد على أصحاب الفروض عدا الزوجين. الجد يحجب الإخوة مطلقاً.',
    },
    {
      name: 'الحنفي',
      icon: '🔴',
      color: '#dc2626',
      description: 'الرد على الزوجين عند عدم وجود غيرهم. الجد يحجب الإخوة.',
    },
    {
      name: 'المالكي',
      icon: '🟣',
      color: '#7c3aed',
      description: 'الجد يُقاسم الإخوة. لا رد على الزوجين. الباقي لبيت المال.',
    },
    {
      name: 'الحنبلي',
      icon: '🔵',
      color: '#0284c7',
      description: 'الجد يُقاسم الإخوة. يُرد على الزوجين عند الحاجة.',
    },
  ];

  const openLink = (url) => {
    Linking.openURL(url);
  };

  return (
    <ScrollView style={styles.container}>
      {/* رأس الصفحة */}
      <View style={styles.header}>
        <View style={styles.logoContainer}>
          <Text style={styles.logo}>⚖️</Text>
        </View>
        <Text style={styles.appName}>{appInfo.name}</Text>
        <Text style={styles.version}>الإصدار {appInfo.version}</Text>
        <Text style={styles.description}>{appInfo.description}</Text>
      </View>

      {/* المميزات */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>المميزات الرئيسية:</Text>
        {features.map((feature, index) => (
          <View key={index} style={styles.featureCard}>
            <Text style={styles.featureIcon}>{feature.icon}</Text>
            <View style={styles.featureContent}>
              <Text style={styles.featureTitle}>{feature.title}</Text>
              <Text style={styles.featureDescription}>
                {feature.description}
              </Text>
            </View>
          </View>
        ))}
      </View>

      {/* المذاهب */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>المذاهب المدعومة:</Text>
        {madhabs.map((madhhab, index) => (
          <View key={index} style={styles.madhhabCard}>
            <Text style={styles.madhhabIcon}>{madhhab.icon}</Text>
            <View style={styles.madhhabContent}>
              <Text
                style={[styles.madhhabName, { color: madhhab.color }]}
              >
                {madhhab.name}
              </Text>
              <Text style={styles.madhhabDescription}>
                {madhhab.description}
              </Text>
            </View>
          </View>
        ))}
      </View>

      {/* معلومات إضافية */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>معلومات إضافية:</Text>
        <View style={styles.infoCard}>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>المطور:</Text>
            <Text style={styles.infoValue}>{appInfo.developer}</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>الترخيص:</Text>
            <Text style={styles.infoValue}>MIT License</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>اللغة:</Text>
            <Text style={styles.infoValue}>العربية</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>المنصة:</Text>
            <Text style={styles.infoValue}>Android</Text>
          </View>
        </View>
      </View>

      {/* حقوق النشر */}
      <View style={styles.footer}>
        <Text style={styles.footerText}>
          © 2024 حاسبة المواريث الإسلامية
        </Text>
        <Text style={styles.footerSubtext}>
          جميع الحقوق محفوظة
        </Text>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    backgroundColor: '#4f46e5',
    padding: 32,
    alignItems: 'center',
  },
  logoContainer: {
    width: 80,
    height: 80,
    backgroundColor: '#fff',
    borderRadius: 40,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    elevation: 4,
  },
  logo: {
    fontSize: 40,
  },
  appName: {
    fontSize: 24,
    fontWeight: '700',
    color: '#fff',
    textAlign: 'center',
  },
  version: {
    fontSize: 14,
    color: '#c7d2fe',
    marginTop: 4,
  },
  description: {
    fontSize: 14,
    color: '#e0e7ff',
    textAlign: 'center',
    marginTop: 12,
    lineHeight: 22,
  },
  section: {
    padding: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 16,
    textAlign: 'right',
  },
  featureCard: {
    flexDirection: 'row-reverse',
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
  },
  featureIcon: {
    fontSize: 28,
    marginLeft: 12,
  },
  featureContent: {
    flex: 1,
  },
  featureTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 4,
    textAlign: 'right',
  },
  featureDescription: {
    fontSize: 13,
    color: '#64748b',
    lineHeight: 20,
    textAlign: 'right',
  },
  madhhabCard: {
    flexDirection: 'row-reverse',
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
  },
  madhhabIcon: {
    fontSize: 24,
    marginLeft: 12,
  },
  madhhabContent: {
    flex: 1,
  },
  madhhabName: {
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 4,
    textAlign: 'right',
  },
  madhhabDescription: {
    fontSize: 13,
    color: '#64748b',
    lineHeight: 20,
    textAlign: 'right',
  },
  infoCard: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    elevation: 2,
  },
  infoRow: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  infoLabel: {
    fontSize: 14,
    color: '#64748b',
  },
  infoValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1e293b',
  },
  footer: {
    padding: 24,
    alignItems: 'center',
  },
  footerText: {
    fontSize: 14,
    color: '#64748b',
  },
  footerSubtext: {
    fontSize: 12,
    color: '#94a3b8',
    marginTop: 4,
  },
});

export default AboutScreen;
