import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { TestSuite, MADHABS_LIST } from '../core';

const TestsScreen = () => {
  const [selectedMadhhab, setSelectedMadhhab] = useState('shafii');
  const [testResults, setTestResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [expandedTests, setExpandedTests] = useState({});

  const runAllTests = () => {
    setLoading(true);
    
    // تشغيل الاختبارات في الخلفية
    setTimeout(() => {
      const testSuite = new TestSuite();
      const results = testSuite.runAllTests(selectedMadhhab);
      setTestResults(results);
      setLoading(false);
    }, 100);
  };

  const toggleTestExpand = (testId) => {
    setExpandedTests((prev) => ({
      ...prev,
      [testId]: !prev[testId],
    }));
  };

  const getStatusColor = (success) => {
    return success ? '#10b981' : '#ef4444';
  };

  const getStatusText = (success) => {
    return success ? '✓ ناجح' : '✗ فاشل';
  };

  return (
    <ScrollView style={styles.container}>
      {/* اختيار المذهب */}
      <View style={styles.madhhabContainer}>
        <Text style={styles.sectionTitle}>اختر المذهب للاختبار:</Text>
        <View style={styles.madhhabButtons}>
          {MADHABS_LIST.map((madhhab) => (
            <TouchableOpacity
              key={madhhab.id}
              style={[
                styles.madhhabButton,
                selectedMadhhab === madhhab.id && {
                  backgroundColor: madhhab.color,
                },
              ]}
              onPress={() => setSelectedMadhhab(madhhab.id)}
            >
              <Text
                style={[
                  styles.madhhabButtonText,
                  selectedMadhhab === madhhab.id && styles.selectedMadhhabText,
                ]}
              >
                {madhhab.icon} {madhhab.name}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* زر تشغيل الاختبارات */}
      <TouchableOpacity
        style={[styles.runButton, loading && styles.disabledButton]}
        onPress={runAllTests}
        disabled={loading}
      >
        {loading ? (
          <ActivityIndicator color="#fff" />
        ) : (
          <Text style={styles.runButtonText}>تشغيل جميع الاختبارات</Text>
        )}
      </TouchableOpacity>

      {/* ملخص النتائج */}
      {testResults && (
        <View style={styles.summaryContainer}>
          <Text style={styles.summaryTitle}>ملخص النتائج:</Text>
          <View style={styles.statsRow}>
            <View style={styles.statBox}>
              <Text style={styles.statValue}>{testResults.total}</Text>
              <Text style={styles.statLabel}>إجمالي الاختبارات</Text>
            </View>
            <View style={[styles.statBox, styles.passedBox]}>
              <Text style={[styles.statValue, styles.passedValue]}>
                {testResults.passed}
              </Text>
              <Text style={styles.statLabel}>ناجح</Text>
            </View>
            <View style={[styles.statBox, styles.failedBox]}>
              <Text style={[styles.statValue, styles.failedValue]}>
                {testResults.failed}
              </Text>
              <Text style={styles.statLabel}>فاشل</Text>
            </View>
          </View>
          <View style={styles.passRateContainer}>
            <Text style={styles.passRateLabel}>نسبة النجاح:</Text>
            <Text
              style={[
                styles.passRateValue,
                parseFloat(testResults.passRate) >= 90
                  ? styles.excellentRate
                  : parseFloat(testResults.passRate) >= 70
                  ? styles.goodRate
                  : styles.poorRate,
              ]}
            >
              {testResults.passRate}
            </Text>
          </View>
        </View>
      )}

      {/* قائمة الاختبارات */}
      {testResults && (
        <View style={styles.testsContainer}>
          <Text style={styles.testsTitle}>تفاصيل الاختبارات:</Text>
          {testResults.results.map((test, index) => (
            <View key={test.id} style={styles.testCard}>
              <TouchableOpacity
                style={styles.testHeader}
                onPress={() => toggleTestExpand(test.id)}
              >
                <View style={styles.testInfo}>
                  <Text style={styles.testNumber}>#{index + 1}</Text>
                  <Text style={styles.testName}>{test.name}</Text>
                </View>
                <View
                  style={[
                    styles.statusBadge,
                    { backgroundColor: getStatusColor(test.success) },
                  ]}
                >
                  <Text style={styles.statusText}>
                    {getStatusText(test.success)}
                  </Text>
                </View>
              </TouchableOpacity>

              {expandedTests[test.id] && !test.success && (
                <View style={styles.testDetails}>
                  <Text style={styles.detailsTitle}>الورثة:</Text>
                  <Text style={styles.detailsText}>
                    {JSON.stringify(test.heirs, null, 2)}
                  </Text>
                  
                  <Text style={styles.detailsTitle}>المتوقع:</Text>
                  <Text style={styles.detailsText}>
                    {JSON.stringify(test.expected, null, 2)}
                  </Text>
                  
                  <Text style={styles.detailsTitle}>الفعلي:</Text>
                  <Text style={styles.detailsText}>
                    {JSON.stringify(test.actual, null, 2)}
                  </Text>
                  
                  {test.error && (
                    <>
                      <Text style={styles.detailsTitle}>خطأ:</Text>
                      <Text style={[styles.detailsText, styles.errorText]}>
                        {test.error}
                      </Text>
                    </>
                  )}
                </View>
              )}
            </View>
          ))}
        </View>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
    padding: 16,
  },
  madhhabContainer: {
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 12,
    textAlign: 'right',
  },
  madhhabButtons: {
    flexDirection: 'row-reverse',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  madhhabButton: {
    backgroundColor: '#f1f5f9',
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 8,
    marginBottom: 8,
    minWidth: '23%',
    alignItems: 'center',
  },
  madhhabButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#475569',
  },
  selectedMadhhabText: {
    color: '#fff',
  },
  runButton: {
    backgroundColor: '#4f46e5',
    paddingVertical: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginBottom: 16,
    elevation: 3,
  },
  disabledButton: {
    opacity: 0.6,
  },
  runButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
  summaryContainer: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    elevation: 2,
  },
  summaryTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 16,
    textAlign: 'right',
  },
  statsRow: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  statBox: {
    alignItems: 'center',
    backgroundColor: '#f8fafc',
    padding: 12,
    borderRadius: 8,
    minWidth: 80,
  },
  passedBox: {
    backgroundColor: '#f0fdf4',
  },
  failedBox: {
    backgroundColor: '#fef2f2',
  },
  statValue: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1e293b',
  },
  passedValue: {
    color: '#059669',
  },
  failedValue: {
    color: '#dc2626',
  },
  statLabel: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 4,
  },
  passRateContainer: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
  },
  passRateLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#475569',
  },
  passRateValue: {
    fontSize: 20,
    fontWeight: '700',
  },
  excellentRate: {
    color: '#059669',
  },
  goodRate: {
    color: '#f59e0b',
  },
  poorRate: {
    color: '#dc2626',
  },
  testsContainer: {
    marginBottom: 16,
  },
  testsTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 12,
    textAlign: 'right',
  },
  testCard: {
    backgroundColor: '#fff',
    borderRadius: 8,
    marginBottom: 8,
    elevation: 1,
    overflow: 'hidden',
  },
  testHeader: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 12,
  },
  testInfo: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    flex: 1,
  },
  testNumber: {
    fontSize: 12,
    color: '#94a3b8',
    marginLeft: 8,
  },
  testName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1e293b',
    flex: 1,
    textAlign: 'right',
  },
  statusBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    minWidth: 60,
    alignItems: 'center',
  },
  statusText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
  },
  testDetails: {
    padding: 12,
    backgroundColor: '#f8fafc',
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
  },
  detailsTitle: {
    fontSize: 12,
    fontWeight: '600',
    color: '#64748b',
    marginTop: 8,
    marginBottom: 4,
  },
  detailsText: {
    fontSize: 12,
    color: '#1e293b',
    fontFamily: Platform.OS === 'ios' ? 'Courier' : 'monospace',
  },
  errorText: {
    color: '#dc2626',
  },
});

export default TestsScreen;
