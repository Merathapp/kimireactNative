import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Alert,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { InheritanceEngine, FIQH_DATABASE } from '../core';
import MadhhabSelector from '../components/Common/MadhhabSelector';
import HeirSection from '../components/Calculator/HeirSection';
import ResultsCard from '../components/Common/ResultsCard';

const CalculatorScreen = () => {
  const [madhhab, setMadhhab] = useState('shafii');
  const [estate, setEstate] = useState('');
  const [heirs, setHeirs] = useState({});
  const [results, setResults] = useState(null);
  const [loading, setLoading] = useState(false);

  const heirCategories = {
    spouses: [
      { key: 'husband', name: 'زوج', color: '#8b5cf6', category: 'spouse' },
      { key: 'wife', name: 'زوجة', color: '#ec4899', category: 'spouse' },
    ],
    parents: [
      { key: 'father', name: 'أب', color: '#3b82f6', category: 'parent' },
      { key: 'mother', name: 'أم', color: '#06b6d4', category: 'parent' },
      { key: 'grandfather', name: 'جد', color: '#6366f1', category: 'parent' },
      { key: 'grandmother', name: 'جدة', color: '#a855f7', category: 'parent' },
    ],
    children: [
      { key: 'son', name: 'ابن', color: '#10b981', category: 'child' },
      { key: 'daughter', name: 'بنت', color: '#f59e0b', category: 'child' },
      { key: 'grandson', name: 'ابن الابن', color: '#14b8a6', category: 'child' },
      { key: 'granddaughter', name: 'بنت الابن', color: '#f97316', category: 'child' },
    ],
    siblings: [
      { key: 'full_brother', name: 'أخ شقيق', color: '#ef4444', category: 'sibling' },
      { key: 'full_sister', name: 'أخت شقيقة', color: '#f43f5e', category: 'sibling' },
      { key: 'paternal_brother', name: 'أخ لأب', color: '#dc2626', category: 'sibling' },
      { key: 'paternal_sister', name: 'أخت لأب', color: '#e11d48', category: 'sibling' },
      { key: 'maternal_brother', name: 'أخ لأم', color: '#b91c1c', category: 'sibling' },
      { key: 'maternal_sister', name: 'أخت لأم', color: '#be123c', category: 'sibling' },
    ],
  };

  const addHeir = useCallback((heirType) => {
    setHeirs((prev) => ({
      ...prev,
      [heirType]: (prev[heirType] || 0) + 1,
    }));
    setResults(null);
  }, []);

  const removeHeir = useCallback((heirType) => {
    setHeirs((prev) => {
      const newHeirs = { ...prev };
      if (newHeirs[heirType] > 1) {
        newHeirs[heirType]--;
      } else {
        delete newHeirs[heirType];
      }
      return newHeirs;
    });
    setResults(null);
  }, []);

  const clearAll = useCallback(() => {
    setHeirs({});
    setResults(null);
    setEstate('');
  }, []);

  const calculate = useCallback(() => {
    if (Object.keys(heirs).length === 0) {
      Alert.alert('تنبيه', 'الرجاء إضافة ورثة أولاً');
      return;
    }

    setLoading(true);
    
    try {
      const engine = new InheritanceEngine(madhhab);
      
      for (const [heirType, count] of Object.entries(heirs)) {
        engine.addHeir(heirType, count);
      }
      
      const result = engine.calculate();
      
      // حساب القيم المالية إذا كان هناك مبلغ
      if (estate && parseFloat(estate) > 0) {
        const estateValue = parseFloat(estate);
        result.results = result.results.map((r) => ({
          ...r,
          amount: (r.share.num / r.share.den * estateValue).toFixed(2),
        }));
      }
      
      setResults(result);
    } catch (error) {
      Alert.alert('خطأ', error.message);
    } finally {
      setLoading(false);
    }
  }, [heirs, madhhab, estate]);

  const getHeirsWithCount = (categoryHeirs) => {
    return categoryHeirs.map((heir) => ({
      ...heir,
      count: heirs[heir.key] || 0,
    }));
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
    >
      <ScrollView style={styles.scrollView}>
        {/* اختيار المذهب */}
        <MadhhabSelector selected={madhhab} onSelect={setMadhhab} />

        {/* بيانات التركة */}
        <View style={styles.estateContainer}>
          <Text style={styles.sectionTitle}>بيانات التركة:</Text>
          <TextInput
            style={styles.estateInput}
            placeholder="أدخل قيمة التركة (اختياري)"
            placeholderTextColor="#94a3b8"
            value={estate}
            onChangeText={setEstate}
            keyboardType="numeric"
            textAlign="right"
          />
        </View>

        {/* الورثة */}
        <View style={styles.heirsContainer}>
          <Text style={styles.sectionTitle}>بيانات الورثة:</Text>
          
          <HeirSection
            title="الزوج/الزوجة:"
            heirs={getHeirsWithCount(heirCategories.spouses)}
            onAdd={addHeir}
            onRemove={removeHeir}
          />
          
          <HeirSection
            title="الأب/الأم/الجد/الجدة:"
            heirs={getHeirsWithCount(heirCategories.parents)}
            onAdd={addHeir}
            onRemove={removeHeir}
          />
          
          <HeirSection
            title="الأبناء/البنات/الأحفاد:"
            heirs={getHeirsWithCount(heirCategories.children)}
            onAdd={addHeir}
            onRemove={removeHeir}
          />
          
          <HeirSection
            title="الإخوة/الأخوات:"
            heirs={getHeirsWithCount(heirCategories.siblings)}
            onAdd={addHeir}
            onRemove={removeHeir}
          />
        </View>

        {/* أزرار التحكم */}
        <View style={styles.buttonsContainer}>
          <TouchableOpacity
            style={[styles.calculateButton, loading && styles.disabledButton]}
            onPress={calculate}
            disabled={loading}
          >
            <Text style={styles.calculateButtonText}>
              {loading ? 'جاري الحساب...' : 'حساب المواريث'}
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.clearButton} onPress={clearAll}>
            <Text style={styles.clearButtonText}>مسح الكل</Text>
          </TouchableOpacity>
        </View>

        {/* النتائج */}
        {results && (
          <View style={styles.resultsContainer}>
            <ResultsCard
              results={results.results}
              blocked={results.blocked}
              specialCase={results.specialCase}
              awlFactor={results.awlFactor}
            />
          </View>
        )}
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  scrollView: {
    flex: 1,
    padding: 16,
  },
  estateContainer: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginVertical: 8,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 12,
    textAlign: 'right',
  },
  estateInput: {
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    color: '#1e293b',
    backgroundColor: '#f8fafc',
  },
  heirsContainer: {
    marginVertical: 8,
  },
  buttonsContainer: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    marginVertical: 16,
  },
  calculateButton: {
    flex: 1,
    backgroundColor: '#4f46e5',
    paddingVertical: 14,
    paddingHorizontal: 24,
    borderRadius: 10,
    marginLeft: 8,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  disabledButton: {
    opacity: 0.6,
  },
  calculateButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
    textAlign: 'center',
  },
  clearButton: {
    backgroundColor: '#f1f5f9',
    paddingVertical: 14,
    paddingHorizontal: 24,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  clearButtonText: {
    color: '#64748b',
    fontSize: 16,
    fontWeight: '600',
  },
  resultsContainer: {
    marginVertical: 16,
  },
});

export default CalculatorScreen;
