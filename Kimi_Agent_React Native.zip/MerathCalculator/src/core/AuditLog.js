// ============================================================================
// نظام سجل المراجعة - AuditLog
// ============================================================================

import AsyncStorage from '@react-native-async-storage/async-storage';

const AUDIT_LOG_KEY = '@merath_audit_log';
const MAX_LOG_ENTRIES = 1000;

export class AuditLog {
  constructor() {
    this.logs = [];
    this.isLoaded = false;
  }
  
  async load() {
    try {
      const stored = await AsyncStorage.getItem(AUDIT_LOG_KEY);
      if (stored) {
        this.logs = JSON.parse(stored);
      }
      this.isLoaded = true;
    } catch (error) {
      console.error('Error loading audit log:', error);
      this.logs = [];
      this.isLoaded = true;
    }
  }
  
  async save() {
    try {
      // الحفاظ على الحد الأقصى
      if (this.logs.length > MAX_LOG_ENTRIES) {
        this.logs = this.logs.slice(-MAX_LOG_ENTRIES);
      }
      await AsyncStorage.setItem(AUDIT_LOG_KEY, JSON.stringify(this.logs));
    } catch (error) {
      console.error('Error saving audit log:', error);
    }
  }
  
  async add(entry) {
    if (!this.isLoaded) {
      await this.load();
    }
    
    const logEntry = {
      id: Date.now().toString(36) + Math.random().toString(36).substr(2),
      timestamp: new Date().toISOString(),
      ...entry
    };
    
    this.logs.unshift(logEntry);
    await this.save();
    
    return logEntry;
  }
  
  async logCalculation(heirs, results, madhhab) {
    return this.add({
      type: 'calculation',
      madhhab,
      heirs,
      results,
      summary: this.summarizeResults(results)
    });
  }
  
  async logTestRun(testResults) {
    return this.add({
      type: 'test_run',
      summary: testResults.summary,
      failedCount: testResults.failed
    });
  }
  
  async logComparison(madhabs, results) {
    return this.add({
      type: 'comparison',
      madhabs,
      results
    });
  }
  
  async logExport(format, data) {
    return this.add({
      type: 'export',
      format,
      dataSize: JSON.stringify(data).length
    });
  }
  
  summarizeResults(results) {
    const totalShares = results.results.reduce((sum, r) => {
      return sum + (r.share ? r.share.num / r.share.den : 0);
    }, 0);
    
    return {
      heirsCount: results.results.length,
      totalShares: totalShares.toFixed(4),
      specialCase: results.specialCase,
      awlFactor: results.awlFactor
    };
  }
  
  getAll() {
    return [...this.logs];
  }
  
  getByType(type) {
    return this.logs.filter(log => log.type === type);
  }
  
  getByDateRange(startDate, endDate) {
    return this.logs.filter(log => {
      const logDate = new Date(log.timestamp);
      return logDate >= startDate && logDate <= endDate;
    });
  }
  
  getRecent(count = 10) {
    return this.logs.slice(0, count);
  }
  
  async clear() {
    this.logs = [];
    await this.save();
  }
  
  async deleteEntry(id) {
    this.logs = this.logs.filter(log => log.id !== id);
    await this.save();
  }
  
  exportToJSON() {
    return JSON.stringify({
      exportDate: new Date().toISOString(),
      totalEntries: this.logs.length,
      logs: this.logs
    }, null, 2);
  }
  
  exportToCSV() {
    const headers = ['ID', 'Timestamp', 'Type', 'Madhhab', 'Heirs Count', 'Details'];
    const rows = this.logs.map(log => [
      log.id,
      log.timestamp,
      log.type,
      log.madhhab || '',
      log.heirs ? Object.keys(log.heirs).length : '',
      JSON.stringify(log.summary || {})
    ]);
    
    return [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  }
  
  getStatistics() {
    const stats = {
      total: this.logs.length,
      byType: {},
      byMadhhab: {},
      byDate: {}
    };
    
    for (const log of this.logs) {
      // حسب النوع
      stats.byType[log.type] = (stats.byType[log.type] || 0) + 1;
      
      // حسب المذهب
      if (log.madhhab) {
        stats.byMadhhab[log.madhhab] = (stats.byMadhhab[log.madhhab] || 0) + 1;
      }
      
      // حسب التاريخ
      const date = log.timestamp.split('T')[0];
      stats.byDate[date] = (stats.byDate[date] || 0) + 1;
    }
    
    return stats;
  }
}

export default AuditLog;
