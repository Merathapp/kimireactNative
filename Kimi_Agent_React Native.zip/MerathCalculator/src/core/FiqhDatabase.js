// ============================================================================
// قاعدة البيانات الفقهية الشاملة - FIQH_DATABASE
// ============================================================================

export const FIQH_DATABASE = {
  // معلومات المذاهب
  madhabs: {
    shafii: {
      id: 'shafii',
      name: 'الشافعي',
      icon: '🟢',
      color: '#059669',
      lightColor: '#ecfdf5',
      borderColor: '#a7f3d0',
      textColor: '#065f46',
      description: 'الرد على أصحاب الفروض عدا الزوجين. الجد يحجب الإخوة مطلقاً. المشتركة معتبرة.',
      rules: {
        grandfatherWithSiblings: 'blocks',
        raddToSpouse: false,
        bloodRelativesEnabled: true,
        musharrakaEnabled: true,
        akdariyyaEnabled: true
      }
    },
    hanafi: {
      id: 'hanafi',
      name: 'الحنفي',
      icon: '🔴',
      color: '#dc2626',
      lightColor: '#fef2f2',
      borderColor: '#fecaca',
      textColor: '#991b1b',
      description: 'الرد على الزوجين عند عدم وجود غيرهم. الجد يحجب الإخوة. لا مشتركة.',
      rules: {
        grandfatherWithSiblings: 'blocks',
        raddToSpouse: true,
        bloodRelativesEnabled: true,
        musharrakaEnabled: false,
        akdariyyaEnabled: true
      }
    },
    maliki: {
      id: 'maliki',
      name: 'المالكي',
      icon: '🟣',
      color: '#7c3aed',
      lightColor: '#faf5ff',
      borderColor: '#e9d5ff',
      textColor: '#6b21a8',
      description: 'الجد يُقاسم الإخوة. لا رد على الزوجين. الباقي لبيت المال. المشتركة معتبرة.',
      rules: {
        grandfatherWithSiblings: 'shares',
        raddToSpouse: false,
        bloodRelativesEnabled: false,
        musharrakaEnabled: true,
        akdariyyaEnabled: true
      }
    },
    hanbali: {
      id: 'hanbali',
      name: 'الحنبلي',
      icon: '🔵',
      color: '#0284c7',
      lightColor: '#eff6ff',
      borderColor: '#bfdbfe',
      textColor: '#1e40af',
      description: 'الجد يُقاسم الإخوة. يُرد على الزوجين عند الحاجة. لا مشتركة.',
      rules: {
        grandfatherWithSiblings: 'shares',
        raddToSpouse: true,
        bloodRelativesEnabled: true,
        musharrakaEnabled: false,
        akdariyyaEnabled: true
      }
    }
  },
  
  // أسماء الورثة
  heirNames: {
    husband: 'الزوج',
    wife: 'الزوجة',
    wives: 'الزوجات',
    father: 'الأب',
    mother: 'الأم',
    grandfather: 'الجد',
    grandmother: 'الجدة',
    grandmother_mother: 'الجدة لأم',
    grandmother_father: 'الجدة لأب',
    grandmothers: 'الجدات',
    son: 'الابن',
    sons: 'الأبناء',
    daughter: 'البنت',
    daughters: 'البنات',
    grandson: 'ابن الابن',
    grandsons: 'أبناء الابن',
    granddaughter: 'بنت الابن',
    granddaughters: 'بنات الابن',
    full_brother: 'الأخ الشقيق',
    full_brothers: 'الإخوة الأشقاء',
    full_sister: 'الأخت الشقيقة',
    full_sisters: 'الأخوات الشقيقات',
    paternal_brother: 'الأخ لأب',
    paternal_brothers: 'الإخوة لأب',
    paternal_sister: 'الأخت لأب',
    paternal_sisters: 'الأخوات لأب',
    maternal_brother: 'الأخ لأم',
    maternal_sister: 'الأخت لأم',
    maternal_siblings: 'الإخوة لأم',
    full_nephew: 'ابن الأخ الشقيق',
    paternal_nephew: 'ابن الأخ لأب',
    full_uncle: 'العم الشقيق',
    paternal_uncle: 'العم لأب',
    full_cousin: 'ابن العم الشقيق',
    paternal_cousin: 'ابن العم لأب',
    maternal_uncle: 'الخال',
    maternal_aunt: 'الخالة',
    paternal_aunt: 'العمة',
    daughter_son: 'ابن البنت',
    daughter_daughter: 'بنت البنت',
    sister_children: 'أولاد الأخت',
    treasury: 'بيت المال'
  },
  
  // ترتيب ذوي الأرحام حسب الصنف
  bloodRelativesOrder: [
    { key: 'daughter_son', class: 1, name: 'ابن البنت' },
    { key: 'daughter_daughter', class: 1, name: 'بنت البنت' },
    { key: 'sister_children', class: 2, name: 'أولاد الأخت' },
    { key: 'maternal_uncle', class: 3, name: 'الخال' },
    { key: 'maternal_aunt', class: 3, name: 'الخالة' },
    { key: 'paternal_aunt', class: 4, name: 'العمة' }
  ]
};

// تصدير المذاهب كمصفوفة للاستخدام في القوائم
export const MADHABS_LIST = Object.values(FIQH_DATABASE.madhabs);

// الحالات الخاصة
export const SPECIAL_CASES = {
  umariyyah: {
    name: 'العُمَريَّة',
    description: 'زوج/زوجة + أب + أم بدون فرع وارث. الأم تأخذ ثلث الباقي.',
    examples: [
      { name: 'العُمَريَّة الأولى', heirs: { husband: 1, father: 1, mother: 1 } },
      { name: 'العُمَريَّة الثانية', heirs: { wife: 1, father: 1, mother: 1 } }
    ]
  },
  musharraka: {
    name: 'المسألة المشتركة (الحمارية)',
    description: 'زوج + أم/جدة + إخوة لأم (2+) + إخوة أشقاء. الإخوة الأشقاء يشتركون.',
    examples: [
      { name: 'المشتركة', heirs: { husband: 1, mother: 1, maternal_brother: 2, full_brother: 1 } }
    ]
  },
  akdariyya: {
    name: 'الأكدرية (الغرّاء)',
    description: 'زوج + أم + جد + أخت شقيقة. تُجمع وتُقسم بطريقة خاصة.',
    examples: [
      { name: 'الأكدرية', heirs: { husband: 1, mother: 1, grandfather: 1, full_sister: 1 } }
    ]
  },
  awl: {
    name: 'العَوْل',
    description: 'عندما يزيد مجموع الفروض عن أصل المسألة.',
    examples: [
      { name: 'عول من 6 إلى 8', heirs: { husband: 1, full_sister: 2, mother: 1 } }
    ]
  },
  radd: {
    name: 'الرَّد',
    description: 'توزيع الفائض على أصحاب الفروض بنسبة فروضهم.',
    examples: [
      { name: 'رد على الأم والبنت', heirs: { mother: 1, daughter: 1 } }
    ]
  }
};
