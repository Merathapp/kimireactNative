// ============================================================================
// نظام الاختبارات الشامل - TestSuite
// ============================================================================

import { Fraction } from './Fraction';
import { InheritanceEngine } from './InheritanceEngine';

export const TEST_CASES = [
  // اختبارات أساسية - الزوجين
  {
    id: 'husband_1',
    name: 'زوج فقط',
    heirs: { husband: 1 },
    expected: { husband: '1/2' }
  },
  {
    id: 'husband_2',
    name: 'زوج مع ابن',
    heirs: { husband: 1, son: 1 },
    expected: { husband: '1/4', son: '3/4' }
  },
  {
    id: 'husband_3',
    name: 'زوج مع بنت',
    heirs: { husband: 1, daughter: 1 },
    expected: { husband: '1/4', daughter: '1/2' }
  },
  {
    id: 'wife_1',
    name: 'زوجة فقط',
    heirs: { wife: 1 },
    expected: { wife: '1/4' }
  },
  {
    id: 'wife_2',
    name: 'زوجة مع ابن',
    heirs: { wife: 1, son: 1 },
    expected: { wife: '1/8', son: '7/8' }
  },
  
  // اختبارات الأبوين
  {
    id: 'parents_1',
    name: 'أب فقط',
    heirs: { father: 1 },
    expected: { father: '1' }
  },
  {
    id: 'parents_2',
    name: 'أم فقط',
    heirs: { mother: 1 },
    expected: { mother: '1/3' }
  },
  {
    id: 'parents_3',
    name: 'أب وأم',
    heirs: { father: 1, mother: 1 },
    expected: { father: '2/3', mother: '1/3' }
  },
  {
    id: 'parents_4',
    name: 'أب وأم مع ابن',
    heirs: { father: 1, mother: 1, son: 1 },
    expected: { father: '1/6', mother: '1/6', son: '2/3' }
  },
  
  // اختبارات البنات
  {
    id: 'daughter_1',
    name: 'بنت فقط',
    heirs: { daughter: 1 },
    expected: { daughter: '1/2' }
  },
  {
    id: 'daughter_2',
    name: 'بنتان',
    heirs: { daughter: 2 },
    expected: { daughter: '2/3' }
  },
  {
    id: 'daughter_3',
    name: 'بنت مع ابن',
    heirs: { daughter: 1, son: 1 },
    expected: { daughter: '1/3', son: '2/3' }
  },
  {
    id: 'daughter_4',
    name: 'بنتان مع ابن',
    heirs: { daughter: 2, son: 1 },
    expected: { daughter: '4/9', son: '5/9' }
  },
  
  // اختبارات الأبناء
  {
    id: 'son_1',
    name: 'ابن فقط',
    heirs: { son: 1 },
    expected: { son: '1' }
  },
  {
    id: 'son_2',
    name: 'ابنان',
    heirs: { son: 2 },
    expected: { son: '1' }
  },
  
  // اختبارات الجد والجدة
  {
    id: 'grandfather_1',
    name: 'جد فقط',
    heirs: { grandfather: 1 },
    expected: { grandfather: '1' }
  },
  {
    id: 'grandmother_1',
    name: 'جدة فقط',
    heirs: { grandmother: 1 },
    expected: { grandmother: '1/6' }
  },
  {
    id: 'grandmother_2',
    name: 'جدتان',
    heirs: { grandmother: 2 },
    expected: { grandmother: '1/6' }
  },
  
  // اختبارات الإخوة والأخوات
  {
    id: 'full_sister_1',
    name: 'أخت شقيقة فقط',
    heirs: { full_sister: 1 },
    expected: { full_sister: '1/2' }
  },
  {
    id: 'full_sister_2',
    name: 'أختان شقيقتان',
    heirs: { full_sister: 2 },
    expected: { full_sister: '2/3' }
  },
  {
    id: 'full_brother_1',
    name: 'أخ شقيق فقط',
    heirs: { full_brother: 1 },
    expected: { full_brother: '1' }
  },
  {
    id: 'maternal_sibling_1',
    name: 'أخ لأم فقط',
    heirs: { maternal_brother: 1 },
    expected: { maternal_brother: '1/6' }
  },
  {
    id: 'maternal_sibling_2',
    name: 'أختان لأم',
    heirs: { maternal_sister: 2 },
    expected: { maternal_sister: '1/3' }
  },
  
  // اختبارات العول
  {
    id: 'awl_1',
    name: 'عول من 6 إلى 8',
    heirs: { husband: 1, full_sister: 2, mother: 1 },
    expected: { husband: '3/8', full_sister: '4/8', mother: '1/8' }
  },
  {
    id: 'awl_2',
    name: 'عول من 24 إلى 27',
    heirs: { wife: 1, daughter: 2, full_sister: 1, mother: 1 },
    expected: { wife: '3/27', daughter: '16/27', full_sister: '4/27', mother: '4/27' }
  },
  
  // اختبارات الرد
  {
    id: 'radd_1',
    name: 'رد على الأم والبنت',
    heirs: { mother: 1, daughter: 1 },
    expected: { mother: '1/3', daughter: '2/3' }
  },
  {
    id: 'radd_2',
    name: 'رد على الزوجة والأم',
    heirs: { wife: 1, mother: 1 },
    expected: { wife: '1/4', mother: '3/4' }
  },
  
  // اختبارات العمرية
  {
    id: 'umariyyah_1',
    name: 'العمرية الأولى',
    heirs: { husband: 1, father: 1, mother: 1 },
    expected: { husband: '1/2', father: '1/3', mother: '1/6' }
  },
  {
    id: 'umariyyah_2',
    name: 'العمرية الثانية',
    heirs: { wife: 1, father: 1, mother: 1 },
    expected: { wife: '1/4', father: '4/12', mother: '1/6' }
  },
  
  // اختبارات معقدة
  {
    id: 'complex_1',
    name: 'زوج + أب + أم + بنت + أخت',
    heirs: { husband: 1, father: 1, mother: 1, daughter: 1, full_sister: 1 },
    expected: { husband: '3/13', father: '2/13', mother: '2/13', daughter: '6/13' }
  },
  {
    id: 'complex_2',
    name: 'زوجة + جد + جدة + بنتان',
    heirs: { wife: 1, grandfather: 1, grandmother: 1, daughter: 2 },
    expected: { wife: '1/8', grandfather: '1/6', grandmother: '1/6', daughter: '11/24' }
  },
  {
    id: 'complex_3',
    name: 'أب + أم + بنت + أخت شقيقة',
    heirs: { father: 1, mother: 1, daughter: 1, full_sister: 1 },
    expected: { father: '2/6', mother: '1/6', daughter: '3/6' }
  },
  
  // اختبارات حالات خاصة
  {
    id: 'special_1',
    name: 'زوج + بنت + جدة',
    heirs: { husband: 1, daughter: 1, grandmother: 1 },
    expected: { husband: '1/4', daughter: '1/2', grandmother: '1/6' }
  },
  {
    id: 'special_2',
    name: 'زوجة + أب + أم + ابن',
    heirs: { wife: 1, father: 1, mother: 1, son: 1 },
    expected: { wife: '1/8', father: '1/6', mother: '1/6', son: '13/24' }
  },
  {
    id: 'special_3',
    name: 'أم + أختان شقيقتان + أخ شقيق',
    heirs: { mother: 1, full_sister: 2, full_brother: 1 },
    expected: { mother: '1/6', full_sister: '2/6', full_brother: '3/6' }
  },
  
  // اختبارات حجب
  {
    id: 'block_1',
    name: 'حجب الجد بالأب',
    heirs: { father: 1, grandfather: 1 },
    expected: { father: '1' }
  },
  {
    id: 'block_2',
    name: 'حجب الجدة بالأم',
    heirs: { mother: 1, grandmother: 1 },
    expected: { mother: '1/3' }
  },
  {
    id: 'block_3',
    name: 'حجب ابن الابن بالابن',
    heirs: { son: 1, grandson: 1 },
    expected: { son: '1' }
  },
  {
    id: 'block_4',
    name: 'حجب الإخوة بالأب',
    heirs: { father: 1, full_brother: 1 },
    expected: { father: '1' }
  },
  {
    id: 'block_5',
    name: 'حجب الأخوات لأب بالأخوات الشقيقات',
    heirs: { full_sister: 2, paternal_sister: 1 },
    expected: { full_sister: '2/3' }
  },
  
  // اختبارات إضافية
  {
    id: 'extra_1',
    name: 'زوج + أب + أم + بنت + أخت شقيقة',
    heirs: { husband: 1, father: 1, mother: 1, daughter: 1, full_sister: 1 },
    expected: { husband: '3/13', father: '2/13', mother: '2/13', daughter: '6/13' }
  },
  {
    id: 'extra_2',
    name: 'زوجة + جد + جدة + بنتان',
    heirs: { wife: 1, grandfather: 1, grandmother: 1, daughter: 2 },
    expected: { wife: '1/8', grandfather: '1/6', grandmother: '1/6', daughter: '11/24' }
  },
  {
    id: 'extra_3',
    name: 'أب + أم + بنت + أخت شقيقة',
    heirs: { father: 1, mother: 1, daughter: 1, full_sister: 1 },
    expected: { father: '2/6', mother: '1/6', daughter: '3/6' }
  },
  {
    id: 'extra_4',
    name: 'زوج + بنت + جدة',
    heirs: { husband: 1, daughter: 1, grandmother: 1 },
    expected: { husband: '1/4', daughter: '1/2', grandmother: '1/6' }
  },
  {
    id: 'extra_5',
    name: 'زوجة + أب + أم + ابن',
    heirs: { wife: 1, father: 1, mother: 1, son: 1 },
    expected: { wife: '1/8', father: '1/6', mother: '1/6', son: '13/24' }
  }
];

export class TestSuite {
  constructor() {
    this.results = [];
    this.passed = 0;
    this.failed = 0;
  }
  
  runAllTests(madhhab = 'shafii') {
    this.results = [];
    this.passed = 0;
    this.failed = 0;
    
    for (const testCase of TEST_CASES) {
      this.runTest(testCase, madhhab);
    }
    
    return {
      total: TEST_CASES.length,
      passed: this.passed,
      failed: this.failed,
      passRate: ((this.passed / TEST_CASES.length) * 100).toFixed(1) + '%',
      results: this.results
    };
  }
  
  runTest(testCase, madhhab = 'shafii') {
    try {
      const engine = new InheritanceEngine(madhhab);
      
      for (const [heirType, count] of Object.entries(testCase.heirs)) {
        engine.addHeir(heirType, count);
      }
      
      const result = engine.calculate();
      const success = this.verifyResult(result, testCase.expected);
      
      const testResult = {
        id: testCase.id,
        name: testCase.name,
        heirs: testCase.heirs,
        expected: testCase.expected,
        actual: this.extractActualShares(result),
        success,
        result
      };
      
      this.results.push(testResult);
      
      if (success) {
        this.passed++;
      } else {
        this.failed++;
      }
      
      return testResult;
    } catch (error) {
      const testResult = {
        id: testCase.id,
        name: testCase.name,
        heirs: testCase.heirs,
        expected: testCase.expected,
        actual: null,
        success: false,
        error: error.message
      };
      
      this.results.push(testResult);
      this.failed++;
      
      return testResult;
    }
  }
  
  verifyResult(result, expected) {
    for (const [heirType, expectedShare] of Object.entries(expected)) {
      const actual = result.results.find(r => r.type === heirType);
      
      if (!actual) {
        return false;
      }
      
      const expectedFrac = this.parseFraction(expectedShare);
      const actualFrac = actual.share;
      
      if (!this.fractionsEqual(expectedFrac, actualFrac)) {
        return false;
      }
    }
    
    return true;
  }
  
  extractActualShares(result) {
    const shares = {};
    for (const r of result.results) {
      shares[r.type] = r.shareArabic;
    }
    return shares;
  }
  
  parseFraction(str) {
    const parts = str.split('/');
    if (parts.length === 2) {
      return new Fraction(parseInt(parts[0]), parseInt(parts[1]));
    }
    return new Fraction(parseInt(str));
  }
  
  fractionsEqual(frac1, frac2) {
    return frac1.num === frac2.num && frac1.den === frac2.den;
  }
  
  getSummary() {
    return {
      total: this.results.length,
      passed: this.passed,
      failed: this.failed,
      passRate: ((this.passed / this.results.length) * 100).toFixed(1) + '%'
    };
  }
  
  getFailedTests() {
    return this.results.filter(r => !r.success);
  }
  
  exportResults() {
    return {
      timestamp: new Date().toISOString(),
      summary: this.getSummary(),
      results: this.results
    };
  }
}

export default TestSuite;
