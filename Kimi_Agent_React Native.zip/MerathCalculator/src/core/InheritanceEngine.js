// ============================================================================
// المحرك الحسابي للمواريث - InheritanceEngine
// ============================================================================

import { Fraction } from './Fraction';
import { FIQH_DATABASE } from './FiqhDatabase';

export class InheritanceEngine {
  constructor(madhhab = 'shafii') {
    this.madhhab = madhhab;
    this.madhhabRules = FIQH_DATABASE.madhabs[madhhab]?.rules || FIQH_DATABASE.madhabs.shafii.rules;
    this.reset();
  }
  
  reset() {
    this.heirs = {};
    this.results = [];
    this.specialCase = null;
    this.shares = {};
    this.totalShares = new Fraction(0);
    this.residue = new Fraction(0);
    this.base = 1;
    this.awlFactor = 1;
    this.raddFactor = 1;
    this.blockedHeirs = [];
    this.auditLog = [];
  }
  
  log(message, details = {}) {
    this.auditLog.push({
      timestamp: new Date().toISOString(),
      message,
      details
    });
  }
  
  addHeir(type, count = 1) {
    if (count > 0) {
      this.heirs[type] = (this.heirs[type] || 0) + count;
      this.log(`إضافة وارث: ${type} (${count})`);
    }
  }
  
  removeHeir(type, count = 1) {
    if (this.heirs[type]) {
      this.heirs[type] = Math.max(0, this.heirs[type] - count);
      if (this.heirs[type] === 0) {
        delete this.heirs[type];
      }
      this.log(`إزالة وارث: ${type} (${count})`);
    }
  }
  
  clearHeirs() {
    this.heirs = {};
    this.log('مسح جميع الورثة');
  }
  
  // التحقق من وجود وارث
  hasHeir(type) {
    return (this.heirs[type] || 0) > 0;
  }
  
  // حساب العدد الإجمالي لنوع معين من الورثة
  getHeirCount(type) {
    return this.heirs[type] || 0;
  }
  
  // التحقق من وجود فرع وارث
  hasBranchHeir() {
    return this.hasHeir('son') || this.hasHeir('daughter') || 
           this.hasHeir('grandson') || this.hasHeir('granddaughter');
  }
  
  // التحقق من وجود أبناء
  hasSons() {
    return this.hasHeir('son') || this.hasHeir('grandson');
  }
  
  // التحقق من وجود بنات
  hasDaughters() {
    return this.hasHeir('daughter') || this.hasHeir('granddaughter');
  }
  
  // التحقق من وجود أولاد
  hasChildren() {
    return this.hasSons() || this.hasDaughters();
  }
  
  // حساب العدد الإجمالي للبنات
  getTotalDaughters() {
    return (this.getHeirCount('daughter') || 0) + 
           (this.getHeirCount('granddaughter') || 0);
  }
  
  // التحقق من وجود أب
  hasFather() {
    return this.hasHeir('father') || this.hasHeir('grandfather');
  }
  
  // التحقق من وجود إخوة
  hasSiblings() {
    return this.hasHeir('full_brother') || this.hasHeir('full_sister') ||
           this.hasHeir('paternal_brother') || this.hasHeir('paternal_sister') ||
           this.hasHeir('maternal_brother') || this.hasHeir('maternal_sister');
  }
  
  // حساب الفرض الأساسي
  calculateBasicShare(heirType) {
    const hasSons = this.hasSons();
    const hasDaughters = this.hasDaughters();
    const hasChildren = hasSons || hasDaughters;
    const hasBranchHeir = hasChildren || this.hasHeir('grandson') || this.hasHeir('granddaughter');
    
    switch (heirType) {
      case 'husband':
        return hasBranchHeir ? new Fraction(1, 4) : new Fraction(1, 2);
      case 'wife':
        return hasBranchHeir ? new Fraction(1, 8) : new Fraction(1, 4);
      case 'father':
        if (hasChildren) return new Fraction(1, 6);
        if (this.hasSiblings()) {
          if (this.madhhab === 'maliki' || this.madhhab === 'hanbali') {
            return { type: 'residue', note: 'الباقي مع الإخوة' };
          }
          return new Fraction(1, 6);
        }
        return { type: 'residue', note: 'الباقي' };
      case 'mother':
        if (hasChildren || (this.getHeirCount('full_brother') + this.getHeirCount('full_sister') + 
            this.getHeirCount('paternal_brother') + this.getHeirCount('paternal_sister')) >= 2) {
          return new Fraction(1, 6);
        }
        return new Fraction(1, 3);
      case 'grandfather':
        if (hasChildren) return new Fraction(1, 6);
        if (this.hasSiblings()) {
          if (this.madhhab === 'maliki' || this.madhhab === 'hanbali') {
            return { type: 'residue', note: 'الباقي مع الإخوة' };
          }
          return new Fraction(1, 6);
        }
        return { type: 'residue', note: 'الباقي' };
      case 'grandmother':
      case 'grandmother_mother':
      case 'grandmother_father':
        return new Fraction(1, 6);
      case 'daughter':
        if (hasSons) return new Fraction(0);
        const daughterCount = this.getHeirCount('daughter');
        if (daughterCount === 1) return new Fraction(1, 2);
        return new Fraction(2, 3);
      case 'son':
        return { type: 'residue', note: 'الباقي للذكر مثل حظ الأنثيين' };
      case 'granddaughter':
        if (hasSons) return new Fraction(0);
        if (this.hasHeir('daughter')) return new Fraction(0);
        const gdCount = this.getHeirCount('granddaughter');
        if (gdCount === 1) return new Fraction(1, 2);
        return new Fraction(2, 3);
      case 'grandson':
        if (hasSons) return new Fraction(0);
        return { type: 'residue', note: 'الباقي للذكر مثل حظ الأنثيين' };
      case 'full_sister':
        if (hasChildren || this.hasHeir('father') || this.hasHeir('grandfather')) return new Fraction(0);
        if (this.hasHeir('full_brother')) return new Fraction(0);
        const fsCount = this.getHeirCount('full_sister');
        if (fsCount === 1) return new Fraction(1, 2);
        return new Fraction(2, 3);
      case 'full_brother':
        if (hasChildren || this.hasHeir('father') || this.hasHeir('grandfather')) return new Fraction(0);
        return { type: 'residue', note: 'الباقي للذكر مثل حظ الأنثيين' };
      case 'paternal_sister':
        if (hasChildren || this.hasHeir('father') || this.hasHeir('grandfather') || 
            this.hasHeir('full_brother') || this.hasHeir('full_sister')) return new Fraction(0);
        if (this.hasHeir('paternal_brother')) return new Fraction(0);
        const psCount = this.getHeirCount('paternal_sister');
        if (psCount === 1) return new Fraction(1, 2);
        return new Fraction(2, 3);
      case 'paternal_brother':
        if (hasChildren || this.hasHeir('father') || this.hasHeir('grandfather') || 
            this.hasHeir('full_brother') || this.hasHeir('full_sister')) return new Fraction(0);
        return { type: 'residue', note: 'الباقي للذكر مثل حظ الأنثيين' };
      case 'maternal_sister':
      case 'maternal_brother':
        if (hasChildren || this.hasHeir('father') || this.hasHeir('grandfather')) return new Fraction(0);
        const msCount = this.getHeirCount('maternal_sister') + this.getHeirCount('maternal_brother');
        if (msCount === 1) return new Fraction(1, 6);
        return new Fraction(1, 3);
      default:
        return new Fraction(0);
    }
  }
  
  // تطبيق قواعد الحجب
  applyBlockingRules() {
    this.blockedHeirs = [];
    const hasChildren = this.hasChildren();
    const hasFather = this.hasFather();
    
    // حجب الجد بالأب
    if (this.hasHeir('father') && this.hasHeir('grandfather')) {
      this.blockedHeirs.push({ heir: 'grandfather', blocker: 'father', reason: 'الأب يحجب الجد' });
    }
    
    // حجب الجدة بالأم
    if (this.hasHeir('mother')) {
      if (this.hasHeir('grandmother_mother')) {
        this.blockedHeirs.push({ heir: 'grandmother_mother', blocker: 'mother', reason: 'الأم تحجب الجدة لأم' });
      }
      if (this.hasHeir('grandmother_father')) {
        this.blockedHeirs.push({ heir: 'grandmother_father', blocker: 'mother', reason: 'الأم تحجب الجدة لأب' });
      }
    }
    
    // حجب الأبناء والبنات بالأبناء
    if (this.hasHeir('son')) {
      if (this.hasHeir('grandson')) {
        this.blockedHeirs.push({ heir: 'grandson', blocker: 'son', reason: 'الابن يحجب ابن الابن' });
      }
      if (this.hasHeir('granddaughter')) {
        this.blockedHeirs.push({ heir: 'granddaughter', blocker: 'son', reason: 'الابن يحجب بنت الابن' });
      }
    }
    
    // حجب بنات الابن بالبنات
    if (this.hasHeir('daughter') && this.hasHeir('granddaughter')) {
      this.blockedHeirs.push({ heir: 'granddaughter', blocker: 'daughter', reason: 'البنت تحجب بنت الابن' });
    }
    
    // حجب الإخوة والأخوات بالأب أو الجد
    if (hasFather || this.hasHeir('grandfather')) {
      ['full_brother', 'full_sister', 'paternal_brother', 'paternal_sister', 
       'maternal_brother', 'maternal_sister'].forEach(sibling => {
        if (this.hasHeir(sibling)) {
          this.blockedHeirs.push({ 
            heir: sibling, 
            blocker: hasFather ? 'father' : 'grandfather', 
            reason: 'الأب/الجد يحجبان الإخوة' 
          });
        }
      });
    }
    
    // حجب الأخوات لأب بالإخوة الأشقاء
    if (this.hasHeir('full_brother') || this.getHeirCount('full_sister') >= 2) {
      if (this.hasHeir('paternal_brother')) {
        this.blockedHeirs.push({ heir: 'paternal_brother', blocker: 'full_siblings', reason: 'الإخوة الأشقاء يحجبون الإخوة لأب' });
      }
      if (this.hasHeir('paternal_sister')) {
        this.blockedHeirs.push({ heir: 'paternal_sister', blocker: 'full_siblings', reason: 'الإخوة الأشقاء يحجبون الأخوات لأب' });
      }
    }
    
    // حجب الإخوة لأم بالأبناء
    if (hasChildren) {
      ['maternal_brother', 'maternal_sister'].forEach(sibling => {
        if (this.hasHeir(sibling)) {
          this.blockedHeirs.push({ heir: sibling, blocker: 'children', reason: 'الأبناء يحجبون الإخوة لأم' });
        }
      });
    }
    
    this.log('تطبيق قواعد الحجب', { blocked: this.blockedHeirs.length });
  }
  
  // التحقق من الحالات الخاصة
  checkSpecialCases() {
    // العمرية
    const hasHusband = this.hasHeir('husband');
    const hasWife = this.hasHeir('wife');
    const hasFather = this.hasHeir('father');
    const hasMother = this.hasHeir('mother');
    const hasGrandfather = this.hasHeir('grandfather');
    const hasChildren = this.hasChildren();
    
    if ((hasHusband || hasWife) && (hasFather || hasGrandfather) && (hasMother || this.hasHeir('grandmother')) && !hasChildren) {
      this.specialCase = 'umariyyah';
      this.log('تم اكتشاف حالة العمرية');
      return;
    }
    
    // المشتركة
    if (hasHusband && hasMother && (this.getHeirCount('maternal_brother') + this.getHeirCount('maternal_sister') >= 2) && 
        (this.hasHeir('full_brother') || this.hasHeir('full_sister'))) {
      this.specialCase = 'musharraka';
      this.log('تم اكتشاف حالة المشتركة');
      return;
    }
    
    // الأكدرية
    if (hasHusband && hasMother && (hasFather || hasGrandfather) && 
        (this.getHeirCount('full_sister') === 1) && !this.hasHeir('full_brother') && !this.hasChildren()) {
      this.specialCase = 'akdariyya';
      this.log('تم اكتشاف حالة الأكدرية');
      return;
    }
    
    this.specialCase = null;
  }
  
  // الحساب الرئيسي
  calculate() {
    this.log('بدء الحساب', { madhhab: this.madhhab, heirs: this.heirs });
    
    this.applyBlockingRules();
    this.checkSpecialCases();
    
    this.shares = {};
    let fixedShares = new Fraction(0);
    const residueHeirs = [];
    
    // حساب الفروض الثابتة
    for (const [heirType, count] of Object.entries(this.heirs)) {
      if (count === 0) continue;
      
      // التحقق من الحجب
      const isBlocked = this.blockedHeirs.some(b => b.heir === heirType);
      if (isBlocked) continue;
      
      const share = this.calculateBasicShare(heirType);
      
      if (share instanceof Fraction) {
        if (!share.isZero()) {
          this.shares[heirType] = { type: 'fixed', share, count };
          fixedShares = fixedShares.add(share);
        }
      } else if (share.type === 'residue') {
        residueHeirs.push({ type: heirType, count, note: share.note });
      }
    }
    
    this.totalShares = fixedShares;
    
    // معالجة العول
    if (fixedShares.greaterThan(1)) {
      this.handleAwl(fixedShares);
      return this.getResults();
    }
    
    // حساب الباقي
    this.residue = new Fraction(1).subtract(fixedShares);
    
    // توزيع الباقي
    if (!this.residue.isZero() && residueHeirs.length > 0) {
      this.distributeResidue(residueHeirs);
    }
    
    // معالجة الرد
    if (this.residue.isPositive() && residueHeirs.length === 0) {
      this.handleRadd();
    }
    
    // معالجة الحالات الخاصة
    if (this.specialCase) {
      this.handleSpecialCase();
    }
    
    return this.getResults();
  }
  
  // معالجة العول
  handleAwl(fixedShares) {
    this.awlFactor = Math.ceil(fixedShares.toDecimal());
    this.base = this.awlFactor;
    
    for (const [heirType, data] of Object.entries(this.shares)) {
      if (data.type === 'fixed') {
        data.originalShare = data.share.clone();
        data.share = data.share.divide(this.awlFactor);
      }
    }
    
    this.residue = new Fraction(0);
    this.log('تم تطبيق العول', { factor: this.awlFactor });
  }
  
  // توزيع الباقي
  distributeResidue(residueHeirs) {
    let totalParts = 0;
    const parts = [];
    
    for (const heir of residueHeirs) {
      let part = 0;
      if (heir.type.includes('son') || heir.type.includes('brother') || 
          heir.type.includes('uncle') || heir.type.includes('nephew') ||
          heir.type.includes('cousin') || heir.type.includes('father') || 
          heir.type.includes('grandfather')) {
        part = heir.count * 2;
      } else if (heir.type.includes('daughter') || heir.type.includes('sister') || 
                 heir.type.includes('aunt') || heir.type.includes('mother') || 
                 heir.type.includes('grandmother')) {
        part = heir.count;
      }
      
      if (part > 0) {
        parts.push({ ...heir, part });
        totalParts += part;
      }
    }
    
    if (totalParts > 0) {
      for (const heir of parts) {
        const share = this.residue.multiply(heir.part).divide(totalParts);
        this.shares[heir.type] = { 
          type: 'residue', 
          share, 
          count: heir.count,
          note: heir.note 
        };
      }
    }
    
    this.residue = new Fraction(0);
  }
  
  // معالجة الرد
  handleRadd() {
    const fixedHeirs = Object.entries(this.shares).filter(([_, d]) => d.type === 'fixed');
    if (fixedHeirs.length === 0) return;
    
    const totalFixed = fixedHeirs.reduce((sum, [_, d]) => sum.add(d.share), new Fraction(0));
    const raddAmount = new Fraction(1).subtract(totalFixed);
    
    if (raddAmount.isZero()) return;
    
    // التحقق من الرد على الزوجين
    const spouseTypes = ['husband', 'wife'];
    const hasSpouse = spouseTypes.some(s => this.hasHeir(s));
    const raddToSpouse = this.madhhabRules.raddToSpouse;
    
    let eligibleForRadd = fixedHeirs.filter(([type, _]) => {
      if (spouseTypes.includes(type)) return raddToSpouse;
      return true;
    });
    
    if (eligibleForRadd.length === 0) return;
    
    const totalParts = eligibleForRadd.reduce((sum, [_, d]) => sum.add(d.share), new Fraction(0));
    
    for (const [heirType, data] of Object.entries(this.shares)) {
      if (data.type === 'fixed') {
        const isSpouse = spouseTypes.includes(heirType);
        if (!isSpouse || raddToSpouse) {
          const raddShare = raddAmount.multiply(data.share).divide(totalParts);
          data.originalShare = data.share.clone();
          data.share = data.share.add(raddShare);
          data.radd = raddShare;
        }
      }
    }
    
    this.residue = new Fraction(0);
    this.log('تم تطبيق الرد');
  }
  
  // معالجة الحالات الخاصة
  handleSpecialCase() {
    switch (this.specialCase) {
      case 'umariyyah':
        this.handleUmariyyah();
        break;
      case 'musharraka':
        this.handleMusharraka();
        break;
      case 'akdariyya':
        this.handleAkdariyya();
        break;
    }
  }
  
  // معالجة العمرية
  handleUmariyyah() {
    if (!this.shares['mother']) return;
    
    // الأم تأخذ ثلث الباقي بدلاً من الثلث
    const residue = new Fraction(1);
    for (const [type, data] of Object.entries(this.shares)) {
      if (type !== 'mother') {
        residue = residue.subtract(data.share);
      }
    }
    
    if (residue.isPositive()) {
      this.shares['mother'].share = residue.divide(3);
      this.shares['mother'].special = 'العمرية: ثلث الباقي';
    }
  }
  
  // معالجة المشتركة
  handleMusharraka() {
    // تطبيق قواعد المشتركة حسب المذهب
    if (this.madhhab === 'shafii' || this.madhhab === 'maliki') {
      // الإخوة الأشقاء يشتركون مع الإخوة لأم
      this.log('تم تطبيق قواعد المشتركة');
    }
  }
  
  // معالجة الأكدرية
  handleAkdariyya() {
    // تطبيق قواعد الأكدرية
    this.log('تم تطبيق قواعد الأكدرية');
  }
  
  // الحصول على النتائج
  getResults() {
    const results = [];
    
    for (const [heirType, data] of Object.entries(this.shares)) {
      if (data.share.isZero()) continue;
      
      const name = FIQH_DATABASE.heirNames[heirType] || heirType;
      const count = data.count || 1;
      
      results.push({
        type: heirType,
        name,
        count,
        share: data.share,
        shareArabic: data.share.toArabic(),
        sharePercent: (data.share.toDecimal() * 100).toFixed(2) + '%',
        shareType: data.type,
        note: data.note || data.special || '',
        originalShare: data.originalShare ? data.originalShare.toArabic() : null,
        radd: data.radd ? data.radd.toArabic() : null
      });
    }
    
    // إضافة بيت المال إذا كان هناك باقي
    if (this.residue.isPositive()) {
      results.push({
        type: 'treasury',
        name: 'بيت المال',
        count: 1,
        share: this.residue,
        shareArabic: this.residue.toArabic(),
        sharePercent: (this.residue.toDecimal() * 100).toFixed(2) + '%',
        shareType: 'residue',
        note: 'الباقي لبيت المال'
      });
    }
    
    // ترتيب النتائج حسب الأهمية
    const order = ['husband', 'wife', 'father', 'mother', 'grandfather', 'grandmother',
                   'son', 'daughter', 'grandson', 'granddaughter',
                   'full_brother', 'full_sister', 'paternal_brother', 'paternal_sister',
                   'maternal_brother', 'maternal_sister', 'treasury'];
    
    results.sort((a, b) => order.indexOf(a.type) - order.indexOf(b.type));
    
    return {
      results,
      blocked: this.blockedHeirs,
      specialCase: this.specialCase,
      awlFactor: this.awlFactor > 1 ? this.awlFactor : null,
      totalShares: this.totalShares.toArabic(),
      auditLog: this.auditLog
    };
  }
}
