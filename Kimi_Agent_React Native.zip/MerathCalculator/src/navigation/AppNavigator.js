import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Text, View, StyleSheet } from 'react-native';

// Screens
import CalculatorScreen from '../screens/CalculatorScreen';
import ComparisonScreen from '../screens/ComparisonScreen';
import TestsScreen from '../screens/TestsScreen';
import RulesScreen from '../screens/RulesScreen';
import AuditScreen from '../screens/AuditScreen';
import AboutScreen from '../screens/AboutScreen';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

// Custom Tab Bar Icon
const TabIcon = ({ icon, label, focused }) => (
  <View style={styles.tabIconContainer}>
    <Text style={[styles.tabIcon, focused && styles.tabIconFocused]}>
      {icon}
    </Text>
    <Text style={[styles.tabLabel, focused && styles.tabLabelFocused]}>
      {label}
    </Text>
  </View>
);

// Main Tab Navigator
const MainTabs = () => {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: true,
        tabBarStyle: styles.tabBar,
        tabBarActiveTintColor: '#4f46e5',
        tabBarInactiveTintColor: '#94a3b8',
        headerStyle: styles.header,
        headerTitleStyle: styles.headerTitle,
        headerTitleAlign: 'center',
      }}
    >
      <Tab.Screen
        name="Calculator"
        component={CalculatorScreen}
        options={{
          title: 'الحاسبة',
          tabBarIcon: ({ focused }) => (
            <TabIcon icon="⚖️" label="الحاسبة" focused={focused} />
          ),
        }}
      />
      <Tab.Screen
        name="Comparison"
        component={ComparisonScreen}
        options={{
          title: 'مقارنة',
          tabBarIcon: ({ focused }) => (
            <TabIcon icon="📊" label="مقارنة" focused={focused} />
          ),
        }}
      />
      <Tab.Screen
        name="Tests"
        component={TestsScreen}
        options={{
          title: 'اختبارات',
          tabBarIcon: ({ focused }) => (
            <TabIcon icon="✅" label="اختبارات" focused={focused} />
          ),
        }}
      />
      <Tab.Screen
        name="Rules"
        component={RulesScreen}
        options={{
          title: 'القواعد',
          tabBarIcon: ({ focused }) => (
            <TabIcon icon="📜" label="القواعد" focused={focused} />
          ),
        }}
      />
      <Tab.Screen
        name="Audit"
        component={AuditScreen}
        options={{
          title: 'السجل',
          tabBarIcon: ({ focused }) => (
            <TabIcon icon="📋" label="السجل" focused={focused} />
          ),
        }}
      />
      <Tab.Screen
        name="About"
        component={AboutScreen}
        options={{
          title: 'حول',
          tabBarIcon: ({ focused }) => (
            <TabIcon icon="ℹ️" label="حول" focused={focused} />
          ),
        }}
      />
    </Tab.Navigator>
  );
};

// Root Navigator
const AppNavigator = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Main" component={MainTabs} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

const styles = StyleSheet.create({
  tabBar: {
    height: 70,
    paddingBottom: 8,
    paddingTop: 8,
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  header: {
    backgroundColor: '#4f46e5',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  headerTitle: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '700',
  },
  tabIconContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  tabIcon: {
    fontSize: 22,
    marginBottom: 2,
  },
  tabIconFocused: {
    transform: [{ scale: 1.1 }],
  },
  tabLabel: {
    fontSize: 11,
    color: '#94a3b8',
  },
  tabLabelFocused: {
    color: '#4f46e5',
    fontWeight: '600',
  },
});

export default AppNavigator;
