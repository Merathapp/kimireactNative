import React from 'react';
import { View, TouchableOpacity, Text, StyleSheet } from 'react-native';
import { MADHABS_LIST } from '../../core/FiqhDatabase';

const MadhhabSelector = ({ selected, onSelect }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.label}>اختر المذهب:</Text>
      <View style={styles.buttonsContainer}>
        {MADHABS_LIST.map((madhhab) => (
          <TouchableOpacity
            key={madhhab.id}
            style={[
              styles.button,
              { 
                backgroundColor: selected === madhhab.id ? madhhab.color : '#f1f5f9',
                borderColor: madhhab.color 
              },
              selected === madhhab.id && styles.selectedButton
            ]}
            onPress={() => onSelect(madhhab.id)}
            activeOpacity={0.7}
          >
            <Text style={[
              styles.icon,
              selected === madhhab.id && styles.selectedText
            ]}>
              {madhhab.icon}
            </Text>
            <Text style={[
              styles.name,
              { color: selected === madhhab.id ? '#fff' : madhhab.color }
            ]}>
              {madhhab.name}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginVertical: 8,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1e293b',
    marginBottom: 8,
    textAlign: 'right',
  },
  buttonsContainer: {
    flexDirection: 'row-reverse',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  button: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 8,
    marginBottom: 8,
    borderWidth: 2,
    minWidth: '23%',
    justifyContent: 'center',
  },
  selectedButton: {
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 3,
  },
  icon: {
    fontSize: 16,
    marginLeft: 6,
  },
  name: {
    fontSize: 14,
    fontWeight: '600',
  },
  selectedText: {
    color: '#fff',
  },
});

export default MadhhabSelector;
