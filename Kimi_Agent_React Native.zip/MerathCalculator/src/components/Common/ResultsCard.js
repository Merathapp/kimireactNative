import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';

const ResultsCard = ({ results, blocked, specialCase, awlFactor }) => {
  if (!results || results.length === 0) {
    return (
      <View style={styles.emptyContainer}>
        <Text style={styles.emptyText}>اضغط على "حساب المواريث" لعرض النتائج</Text>
      </View>
    );
  }

  const totalShares = results.reduce((sum, r) => {
    return sum + (r.share ? r.share.num / r.share.den : 0);
  }, 0);

  return (
    <ScrollView style={styles.container}>
      {/* حالة خاصة */}
      {specialCase && (
        <View style={styles.specialCaseBanner}>
          <Text style={styles.specialCaseText}>
            حالة خاصة: {specialCase === 'umariyyah' ? 'العمرية' : 
                        specialCase === 'musharraka' ? 'المشتركة' : 
                        specialCase === 'akdariyya' ? 'الأكدرية' : specialCase}
          </Text>
        </View>
      )}

      {/* عول */}
      {awlFactor && awlFactor > 1 && (
        <View style={styles.awlBanner}>
          <Text style={styles.awlText}>
            حالة العول: المسألة من {awlFactor}
          </Text>
        </View>
      )}

      {/* النتائج */}
      <View style={styles.resultsContainer}>
        <Text style={styles.sectionTitle}>نتائج التوزيع:</Text>
        {results.map((result, index) => (
          <View key={index} style={styles.resultRow}>
            <View style={styles.heirInfo}>
              <Text style={styles.heirName}>{result.name}</Text>
              {result.count > 1 && (
                <Text style={styles.heirCount}>({result.count})</Text>
              )}
            </View>
            <View style={styles.shareInfo}>
              <Text style={styles.shareArabic}>{result.shareArabic}</Text>
              <Text style={styles.sharePercent}>{result.sharePercent}</Text>
            </View>
            {result.note && (
              <Text style={styles.note}>{result.note}</Text>
            )}
          </View>
        ))}
      </View>

      {/* المجموع */}
      <View style={styles.totalRow}>
        <Text style={styles.totalLabel}>المجموع:</Text>
        <Text style={styles.totalValue}>
          {(totalShares * 100).toFixed(1)}%
        </Text>
      </View>

      {/* المحجوبون */}
      {blocked && blocked.length > 0 && (
        <View style={styles.blockedContainer}>
          <Text style={styles.blockedTitle}>المحجوبون:</Text>
          {blocked.map((item, index) => (
            <View key={index} style={styles.blockedRow}>
              <Text style={styles.blockedHeir}>
                {item.heir}
              </Text>
              <Text style={styles.blockedReason}>
                {item.reason}
              </Text>
            </View>
          ))}
        </View>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  emptyContainer: {
    padding: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyText: {
    fontSize: 14,
    color: '#94a3b8',
    textAlign: 'center',
  },
  specialCaseBanner: {
    backgroundColor: '#fef3c7',
    padding: 12,
    borderRadius: 8,
    marginBottom: 12,
    borderRightWidth: 4,
    borderRightColor: '#f59e0b',
  },
  specialCaseText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#92400e',
    textAlign: 'right',
  },
  awlBanner: {
    backgroundColor: '#fee2e2',
    padding: 12,
    borderRadius: 8,
    marginBottom: 12,
    borderRightWidth: 4,
    borderRightColor: '#ef4444',
  },
  awlText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#991b1b',
    textAlign: 'right',
  },
  resultsContainer: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 12,
    textAlign: 'right',
  },
  resultRow: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  heirInfo: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    flex: 1,
  },
  heirName: {
    fontSize: 15,
    fontWeight: '600',
    color: '#1e293b',
  },
  heirCount: {
    fontSize: 13,
    color: '#64748b',
    marginRight: 4,
  },
  shareInfo: {
    alignItems: 'flex-end',
  },
  shareArabic: {
    fontSize: 16,
    fontWeight: '700',
    color: '#059669',
  },
  sharePercent: {
    fontSize: 12,
    color: '#64748b',
    marginTop: 2,
  },
  note: {
    fontSize: 11,
    color: '#f59e0b',
    marginTop: 4,
    textAlign: 'right',
  },
  totalRow: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#f0fdf4',
    padding: 12,
    borderRadius: 8,
    marginBottom: 12,
  },
  totalLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#166534',
  },
  totalValue: {
    fontSize: 16,
    fontWeight: '700',
    color: '#166534',
  },
  blockedContainer: {
    backgroundColor: '#fef2f2',
    borderRadius: 8,
    padding: 12,
  },
  blockedTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#991b1b',
    marginBottom: 8,
    textAlign: 'right',
  },
  blockedRow: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    paddingVertical: 4,
  },
  blockedHeir: {
    fontSize: 13,
    color: '#7f1d1d',
  },
  blockedReason: {
    fontSize: 11,
    color: '#b91c1c',
  },
});

export default ResultsCard;
