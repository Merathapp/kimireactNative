import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import HeirButton from '../Common/HeirButton';

const HeirSection = ({ title, heirs, onAdd, onRemove, colors = {} }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>{title}</Text>
      <View style={styles.buttonsContainer}>
        {heirs.map((heir) => (
          <HeirButton
            key={heir.key}
            title={heir.name}
            count={heir.count}
            onPress={() => onAdd(heir.key)}
            onLongPress={() => onRemove(heir.key)}
            color={heir.color || colors[heir.category] || '#4f46e5'}
          />
        ))}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: 16,
  },
  title: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1e293b',
    marginBottom: 10,
    textAlign: 'right',
    paddingRight: 4,
  },
  buttonsContainer: {
    flexDirection: 'row-reverse',
    flexWrap: 'wrap',
    justifyContent: 'flex-start',
  },
});

export default HeirSection;
