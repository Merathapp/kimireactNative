/**
 * @fileoverview شاشة مقارنة المذاهب
 * @module screens/ComparisonScreen
 */

import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { useTheme } from '../contexts';
import { InheritanceEngine, MADHABS_LIST, FIQH_DATABASE } from '../core';

// تصنيفات الورثة
const HEIR_CATEGORIES = {
  spouses: [
    { key: 'husband', name: 'زوج', color: '#8b5cf6', icon: '👨' },
    { key: 'wife', name: 'زوجة', color: '#ec4899', icon: '👩' },
  ],
  parents: [
    { key: 'father', name: 'أب', color: '#3b82f6', icon: '👴' },
    { key: 'mother', name: 'أم', color: '#06b6d4', icon: '👵' },
    { key: 'grandfather', name: 'جد', color: '#6366f1', icon: '🧓' },
    { key: 'grandmother', name: 'جدة', color: '#a855f7', icon: '👵' },
  ],
  children: [
    { key: 'son', name: 'ابن', color: '#10b981', icon: '👦' },
    { key: 'daughter', name: 'بنت', color: '#f59e0b', icon: '👧' },
    { key: 'grandson', name: 'ابن الابن', color: '#14b8a6', icon: '👶' },
    { key: 'granddaughter', name: 'بنت الابن', color: '#f97316', icon: '👶' },
  ],
  siblings: [
    { key: 'full_brother', name: 'أخ شقيق', color: '#ef4444', icon: '👨' },
    { key: 'full_sister', name: 'أخت شقيقة', color: '#f43f5e', icon: '👩' },
    { key: 'paternal_brother', name: 'أخ لأب', color: '#dc2626', icon: '👨' },
    { key: 'paternal_sister', name: 'أخت لأب', color: '#e11d48', icon: '👩' },
    { key: 'maternal_brother', name: 'أخ لأم', color: '#b91c1c', icon: '👨' },
    { key: 'maternal_sister', name: 'أخت لأم', color: '#be123c', icon: '👩' },
  ],
};

// مكون زر الورثة
const HeirButton = ({ heir, count, onPress, theme }) => (
  <TouchableOpacity
    style={[
      styles.heirButton,
      { 
        backgroundColor: count > 0 
          ? heir.color + '20' 
          : theme.colors.surface,
        borderColor: count > 0 ? heir.color : theme.colors.border
      }
    ]}
    onPress={() => onPress(heir.key)}
    activeOpacity={0.7}
  >
    <Text style={styles.heirIcon}>{heir.icon}</Text>
    <Text style={[
      styles.heirName,
      { color: count > 0 ? heir.color : theme.colors.text }
    ]}>
      {heir.name}
    </Text>
    {count > 0 && (
      <View style={[styles.countBadge, { backgroundColor: heir.color }]}>
        <Text style={styles.countText}>{count}</Text>
      </View>
    )}
  </TouchableOpacity>
);

// مكون جدول المقارنة
const ComparisonTable = ({ results, theme }) => {
  if (!results) return null;
  
  // جمع جميع أنواع الورثة
  const allHeirTypes = new Set();
  for (const madhhab of MADHABS_LIST) {
    const result = results[madhhab.id];
    if (result?.results) {
      result.results.forEach(r => allHeirTypes.add(r.type));
    }
  }
  
  const heirTypesArray = Array.from(allHeirTypes);
  
  return (
    <View style={[styles.tableCard, { backgroundColor: theme.colors.surface }]}>
      <Text style={[styles.tableTitle, { color: theme.colors.text }]}>
        جدول المقارنة
      </Text>
      
      {/* رأس الجدول */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        <View>
          {/* صف المذاهب */}
          <View style={[styles.tableRow, styles.headerRow, { borderBottomColor: theme.colors.border }]}>
            <View style={[styles.heirCell, styles.headerCell]}>
              <Text style={[styles.headerText, { color: theme.colors.textSecondary }]}>
                الوارث
              </Text>
            </View>
            {MADHABS_LIST.map(madhhab => (
              <View key={madhhab.id} style={[styles.madhhabCell, { backgroundColor: madhhab.lightColor }]}>
                <Text style={[styles.madhhabHeaderText, { color: madhhab.color }]}>
                  {madhhab.icon} {madhhab.name}
                </Text>
              </View>
            ))}
          </View>
          
          {/* صفوف الورثة */}
          {heirTypesArray.map(heirType => (
            <View 
              key={heirType} 
              style={[styles.tableRow, { borderBottomColor: theme.colors.borderLight }]}
            >
              <View style={styles.heirCell}>
                <Text style={[styles.heirText, { color: theme.colors.text }]}>
                  {FIQH_DATABASE.heirNames[heirType] || heirType}
                </Text>
              </View>
              {MADHABS_LIST.map(madhhab => {
                const result = results[madhhab.id];
                const heirResult = result?.results?.find(r => r.type === heirType);
                
                return (
                  <View key={madhhab.id} style={styles.madhhabCell}>
                    <Text style={[
                      styles.shareText,
                      { color: heirResult ? theme.colors.success : theme.colors.textTertiary }
                    ]}>
                      {heirResult ? heirResult.shareArabic : '-'}
                    </Text>
                  </View>
                );
              })}
            </View>
          ))}
          
          {/* صف الحالات الخاصة */}
          <View style={[styles.tableRow, { borderTopWidth: 2, borderTopColor: theme.colors.border }]}>
            <View style={styles.heirCell}>
              <Text style={[styles.specialLabel, { color: theme.colors.warning }]}>
                الحالة الخاصة
              </Text>
            </View>
            {MADHABS_LIST.map(madhhab => {
              const result = results[madhhab.id];
              const specialCase = result?.specialCase;
              
              return (
                <View key={madhhab.id} style={styles.madhhabCell}>
                  <Text style={[
                    styles.specialText,
                    { color: specialCase ? theme.colors.warning : theme.colors.textTertiary }
                  ]}>
                    {specialCase 
                      ? specialCase === 'umariyyah' ? 'العمرية'
                        : specialCase === 'musharraka' ? 'المشتركة'
                        : specialCase === 'akdariyya' ? 'الأكدرية'
                        : specialCase
                      : '-'}
                  </Text>
                </View>
              );
            })}
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

const ComparisonScreen = () => {
  const { theme } = useTheme();
  const [heirs, setHeirs] = useState({});
  const [comparisonResults, setComparisonResults] = useState(null);
  
  const addHeir = (heirType) => {
    setHeirs(prev => ({
      ...prev,
      [heirType]: (prev[heirType] || 0) + 1
    }));
    setComparisonResults(null);
  };
  
  const removeHeir = (heirType) => {
    setHeirs(prev => {
      const newHeirs = { ...prev };
      if (newHeirs[heirType] > 1) {
        newHeirs[heirType]--;
      } else {
        delete newHeirs[heirType];
      }
      return newHeirs;
    });
    setComparisonResults(null);
  };
  
  const clearAll = () => {
    setHeirs({});
    setComparisonResults(null);
  };
  
  const compare = () => {
    if (Object.keys(heirs).length === 0) {
      Alert.alert('تنبيه', 'الرجاء إضافة ورثة أولاً');
      return;
    }
    
    const results = {};
    
    for (const madhhab of MADHABS_LIST) {
      try {
        const engine = new InheritanceEngine(madhhab.id);
        
        for (const [heirType, count] of Object.entries(heirs)) {
          engine.addHeir(heirType, count);
        }
        
        const result = engine.calculate();
        results[madhhab.id] = result;
      } catch (error) {
        results[madhhab.id] = { error: error.message };
      }
    }
    
    setComparisonResults(results);
  };
  
  const getHeirsWithCount = (categoryHeirs) => {
    return categoryHeirs.map(heir => ({
      ...heir,
      count: heirs[heir.key] || 0
    }));
  };
  
  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* قسم اختيار الورثة */}
        <View style={styles.heirsSection}>
          <Text style={[styles.sectionTitle, { color: theme.colors.text }]}>
            اختر الورثة للمقارنة:
          </Text>
          
          {Object.entries(HEIR_CATEGORIES).map(([category, categoryHeirs]) => (
            <View key={category} style={styles.categoryContainer}>
              <View style={styles.heirsGrid}>
                {getHeirsWithCount(categoryHeirs).map(heir => (
                  <HeirButton
                    key={heir.key}
                    heir={heir}
                    count={heir.count}
                    onPress={(key) => heir.count > 0 ? removeHeir(key) : addHeir(key)}
                    theme={theme}
                  />
                ))}
              </View>
            </View>
          ))}
        </View>
        
        {/* أزرار التحكم */}
        <View style={styles.buttonsContainer}>
          <TouchableOpacity
            style={[styles.compareButton, { backgroundColor: theme.colors.primary }]}
            onPress={compare}
            activeOpacity={0.8}
          >
            <Text style={styles.compareButtonText}>مقارنة المذاهب</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.clearButton, { 
              backgroundColor: theme.colors.surfaceVariant,
              borderColor: theme.colors.border
            }]}
            onPress={clearAll}
            activeOpacity={0.8}
          >
            <Text style={[styles.clearButtonText, { color: theme.colors.textSecondary }]}>
              مسح الكل
            </Text>
          </TouchableOpacity>
        </View>
        
        {/* جدول المقارنة */}
        {comparisonResults && (
          <ComparisonTable results={comparisonResults} theme={theme} />
        )}
        
        <View style={styles.bottomSpace} />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  heirsSection: {
    padding: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 16,
    textAlign: 'right',
  },
  categoryContainer: {
    marginBottom: 12,
  },
  heirsGrid: {
    flexDirection: 'row-reverse',
    flexWrap: 'wrap',
    gap: 8,
  },
  heirButton: {
    width: '23%',
    borderRadius: 12,
    padding: 10,
    alignItems: 'center',
    borderWidth: 1.5,
    position: 'relative',
  },
  heirIcon: {
    fontSize: 22,
    marginBottom: 2,
  },
  heirName: {
    fontSize: 11,
    fontWeight: '600',
    textAlign: 'center',
  },
  countBadge: {
    position: 'absolute',
    top: -5,
    right: -5,
    minWidth: 20,
    height: 20,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  countText: {
    color: '#fff',
    fontSize: 11,
    fontWeight: '700',
  },
  buttonsContainer: {
    flexDirection: 'row-reverse',
    paddingHorizontal: 16,
    marginBottom: 20,
    gap: 12,
  },
  compareButton: {
    flex: 1,
    paddingVertical: 16,
    borderRadius: 14,
    elevation: 4,
  },
  compareButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
    textAlign: 'center',
  },
  clearButton: {
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 14,
    borderWidth: 1,
  },
  clearButtonText: {
    fontSize: 16,
    fontWeight: '600',
  },
  tableCard: {
    margin: 16,
    marginTop: 0,
    borderRadius: 20,
    padding: 16,
    elevation: 4,
  },
  tableTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 16,
    textAlign: 'center',
  },
  tableRow: {
    flexDirection: 'row-reverse',
    borderBottomWidth: 1,
  },
  headerRow: {
    borderBottomWidth: 2,
  },
  heirCell: {
    width: 100,
    padding: 12,
    justifyContent: 'center',
  },
  headerCell: {
    backgroundColor: '#f8fafc',
  },
  headerText: {
    fontSize: 12,
    fontWeight: '700',
    textAlign: 'center',
  },
  madhhabCell: {
    width: 90,
    padding: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  madhhabHeaderText: {
    fontSize: 11,
    fontWeight: '700',
    textAlign: 'center',
  },
  heirText: {
    fontSize: 13,
    fontWeight: '600',
    textAlign: 'right',
  },
  shareText: {
    fontSize: 13,
    fontWeight: '700',
    textAlign: 'center',
  },
  specialLabel: {
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'right',
  },
  specialText: {
    fontSize: 11,
    fontWeight: '600',
    textAlign: 'center',
  },
  bottomSpace: {
    height: 40,
  },
});

export default ComparisonScreen;
