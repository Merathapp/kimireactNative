/**
 * @fileoverview شاشة المفضلة
 * @module screens/FavoritesScreen
 */

import React from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { useTheme } from '../contexts';
import { useFavorites } from '../hooks/useStorage';
import { FIQH_DATABASE } from '../core';

// مكون بطاقة المفضلة
const FavoriteCard = ({ favorite, onPress, onDelete, theme }) => {
  const madhhab = FIQH_DATABASE.madhabs[favorite.madhhab];
  
  return (
    <TouchableOpacity
      style={[styles.card, { backgroundColor: theme.colors.surface }]}
      onPress={() => onPress(favorite)}
      activeOpacity={0.7}
    >
      <View style={styles.cardHeader}>
        <View style={[styles.madhhabBadge, { backgroundColor: madhhab?.lightColor }]}>
          <Text style={[styles.madhhabText, { color: madhhab?.color }]}>
            {madhhab?.icon} {madhhab?.name}
          </Text>
        </View>
        <TouchableOpacity
          style={styles.deleteButton}
          onPress={() => onDelete(favorite.id)}
        >
          <Text style={styles.deleteIcon}>🗑️</Text>
        </TouchableOpacity>
      </View>
      
      <View style={styles.heirsContainer}>
        <Text style={[styles.heirsLabel, { color: theme.colors.textSecondary }]}>
          الورثة:
        </Text>
        <Text style={[styles.heirsText, { color: theme.colors.text }]}>
          {Object.entries(favorite.heirs)
            .map(([key, count]) => `${FIQH_DATABASE.heirNames[key] || key} (${count})`)
            .join('، ')}
        </Text>
      </View>
      
      <View style={styles.resultsPreview}>
        {favorite.results?.slice(0, 3).map((result, index) => (
          <View key={index} style={styles.resultItem}>
            <Text style={[styles.resultName, { color: theme.colors.text }]}>
              {result.name}:
            </Text>
            <Text style={[styles.resultShare, { color: theme.colors.success }]}>
              {result.shareArabic}
            </Text>
          </View>
        ))}
        {favorite.results?.length > 3 && (
          <Text style={[styles.moreText, { color: theme.colors.textTertiary }]}>
            +{favorite.results.length - 3} أكثر
          </Text>
        )}
      </View>
      
      <Text style={[styles.dateText, { color: theme.colors.textTertiary }]}>
        {new Date(favorite.timestamp).toLocaleDateString('ar-SA')}
      </Text>
    </TouchableOpacity>
  );
};

// الشاشة الفارغة
const EmptyState = ({ theme }) => (
  <View style={styles.emptyContainer}>
    <Text style={styles.emptyIcon}>⭐</Text>
    <Text style={[styles.emptyTitle, { color: theme.colors.text }]}>
      لا توجد مفضلات
    </Text>
    <Text style={[styles.emptyDescription, { color: theme.colors.textSecondary }]}>
      احفظ حساباتك المهمة هنا للوصول إليها بسهولة
    </Text>
  </View>
);

const FavoritesScreen = ({ navigation }) => {
  const { theme } = useTheme();
  const { favorites, removeFavorite } = useFavorites();
  
  const handleDelete = (id) => {
    Alert.alert(
      'تأكيد الحذف',
      'هل أنت متأكد من حذف هذه المفضلة؟',
      [
        { text: 'إلغاء', style: 'cancel' },
        { text: 'حذف', style: 'destructive', onPress: () => removeFavorite(id) }
      ]
    );
  };
  
  const handlePress = (favorite) => {
    // يمكن التنقل إلى شاشة التفاصيل أو تحميل الحساب
    Alert.alert(
      'خيارات',
      'ماذا تريد أن تفعل؟',
      [
        { text: 'إلغاء', style: 'cancel' },
        { 
          text: 'تحميل الحساب', 
          onPress: () => {
            // تحميل الحساب في الحاسبة
            navigation.navigate('Calculator', { loadFavorite: favorite });
          }
        }
      ]
    );
  };
  
  if (favorites.length === 0) {
    return (
      <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
        <EmptyState theme={theme} />
      </View>
    );
  }
  
  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <FlatList
        data={favorites}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <FavoriteCard
            favorite={item}
            onPress={handlePress}
            onDelete={handleDelete}
            theme={theme}
          />
        )}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  listContent: {
    padding: 16,
  },
  card: {
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  cardHeader: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  madhhabBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
  },
  madhhabText: {
    fontSize: 12,
    fontWeight: '600',
  },
  deleteButton: {
    padding: 4,
  },
  deleteIcon: {
    fontSize: 18,
  },
  heirsContainer: {
    marginBottom: 12,
  },
  heirsLabel: {
    fontSize: 12,
    marginBottom: 4,
  },
  heirsText: {
    fontSize: 14,
    lineHeight: 20,
    textAlign: 'right',
  },
  resultsPreview: {
    backgroundColor: '#f8fafc',
    borderRadius: 10,
    padding: 12,
    marginBottom: 12,
  },
  resultItem: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  resultName: {
    fontSize: 13,
  },
  resultShare: {
    fontSize: 13,
    fontWeight: '600',
  },
  moreText: {
    fontSize: 12,
    textAlign: 'center',
    marginTop: 4,
  },
  dateText: {
    fontSize: 12,
    textAlign: 'left',
  },
  emptyContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 40,
  },
  emptyIcon: {
    fontSize: 60,
    marginBottom: 16,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: '700',
    marginBottom: 8,
  },
  emptyDescription: {
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 22,
  },
});

export default FavoritesScreen;
