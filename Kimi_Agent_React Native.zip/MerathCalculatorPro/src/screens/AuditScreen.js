/**
 * @fileoverview شاشة السجل والمراجعة
 * @module screens/AuditScreen
 */

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Alert,
  Share,
} from 'react-native';
import { useTheme } from '../contexts';
import { AuditLog, MADHABS_LIST, FIQH_DATABASE } from '../core';

const AuditScreen = () => {
  const { theme } = useTheme();
  const [logs, setLogs] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  
  const auditLog = new AuditLog();
  
  useEffect(() => {
    loadLogs();
  }, []);
  
  const loadLogs = async () => {
    setLoading(true);
    await auditLog.load();
    setLogs(auditLog.getAll());
    setStats(auditLog.getStatistics());
    setLoading(false);
  };
  
  const clearLogs = () => {
    Alert.alert(
      'تأكيد',
      'هل أنت متأكد من مسح جميع السجلات؟',
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'مسح',
          style: 'destructive',
          onPress: async () => {
            await auditLog.clear();
            loadLogs();
          },
        },
      ]
    );
  };
  
  const exportLogs = async () => {
    try {
      const json = auditLog.exportToJSON();
      await Share.share({
        message: json,
        title: 'سجل مراجعة حاسبة المواريث',
      });
    } catch (error) {
      Alert.alert('خطأ', 'فشل في تصدير السجلات');
    }
  };
  
  const formatDate = (timestamp) => {
    const date = new Date(timestamp);
    return date.toLocaleDateString('ar-SA', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };
  
  const getLogTypeLabel = (type) => {
    const labels = {
      calculation: 'حساب',
      test_run: 'اختبار',
      comparison: 'مقارنة',
      export: 'تصدير',
    };
    return labels[type] || type;
  };
  
  const getLogTypeColor = (type) => {
    const colors = {
      calculation: theme.colors.primary,
      test_run: theme.colors.success,
      comparison: theme.colors.warning,
      export: '#8b5cf6',
    };
    return colors[type] || theme.colors.textSecondary;
  };
  
  const getMadhhabName = (id) => {
    const madhhab = MADHABS_LIST.find((m) => m.id === id);
    return madhhab ? madhhab.name : id;
  };
  
  const filteredLogs = filter === 'all' 
    ? logs 
    : logs.filter(log => log.type === filter);
  
  const renderStats = () => {
    if (!stats) return null;
    
    return (
      <View style={[styles.statsCard, { backgroundColor: theme.colors.surface }]}>
        <Text style={[styles.statsTitle, { color: theme.colors.text }]}>
          إحصائيات السجل
        </Text>
        
        <View style={styles.statsGrid}>
          <View style={[styles.statBox, { backgroundColor: theme.colors.surfaceVariant }]}>
            <Text style={[styles.statValue, { color: theme.colors.text }]}>
              {stats.total}
            </Text>
            <Text style={[styles.statLabel, { color: theme.colors.textSecondary }]}>
              إجمالي السجلات
            </Text>
          </View>
          
          {Object.entries(stats.byType).map(([type, count]) => (
            <View key={type} style={[styles.statBox, { backgroundColor: getLogTypeColor(type) + '20' }]}>
              <Text style={[styles.statValue, { color: getLogTypeColor(type) }]}>
                {count}
              </Text>
              <Text style={[styles.statLabel, { color: getLogTypeColor(type) }]}>
                {getLogTypeLabel(type)}
              </Text>
            </View>
          ))}
        </View>
        
        {stats.byMadhhab && Object.keys(stats.byMadhhab).length > 0 && (
          <View style={[styles.madhhabStats, { borderTopColor: theme.colors.border }]}>
            <Text style={[styles.madhhabStatsTitle, { color: theme.colors.textSecondary }]}>
              حسب المذهب:
            </Text>
            {Object.entries(stats.byMadhhab).map(([madhhab, count]) => (
              <View key={madhhab} style={styles.madhhabStatRow}>
                <Text style={[styles.madhhabStatName, { color: theme.colors.text }]}>
                  {getMadhhabName(madhhab)}
                </Text>
                <Text style={[styles.madhhabStatCount, { color: theme.colors.primary }]}>
                  {count}
                </Text>
              </View>
            ))}
          </View>
        )}
      </View>
    );
  };
  
  const renderLogs = () => {
    if (logs.length === 0) {
      return (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyIcon}>📋</Text>
          <Text style={[styles.emptyText, { color: theme.colors.textSecondary }]}>
            لا توجد سجلات حتى الآن
          </Text>
        </View>
      );
    }
    
    return (
      <View>
        {/* مرشحات */}
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          style={styles.filtersContainer}
        >
          {[
            { id: 'all', label: 'الكل' },
            { id: 'calculation', label: 'حسابات' },
            { id: 'test_run', label: 'اختبارات' },
            { id: 'comparison', label: 'مقارنات' },
          ].map(f => (
            <TouchableOpacity
              key={f.id}
              style={[
                styles.filterButton,
                { 
                  backgroundColor: filter === f.id 
                    ? theme.colors.primary 
                    : theme.colors.surfaceVariant 
                }
              ]}
              onPress={() => setFilter(f.id)}
            >
              <Text style={[
                styles.filterText,
                { color: filter === f.id ? '#fff' : theme.colors.textSecondary }
              ]}>
                {f.label}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
        
        <Text style={[styles.logsTitle, { color: theme.colors.text }]}>
          السجلات ({filteredLogs.length})
        </Text>
        
        {filteredLogs.map((log) => (
          <View 
            key={log.id} 
            style={[styles.logCard, { backgroundColor: theme.colors.surface }]}
          >
            <View style={styles.logHeader}>
              <View style={[
                styles.logTypeBadge,
                { backgroundColor: getLogTypeColor(log.type) }
              ]}>
                <Text style={styles.logTypeText}>
                  {getLogTypeLabel(log.type)}
                </Text>
              </View>
              <Text style={[styles.logDate, { color: theme.colors.textTertiary }]}>
                {formatDate(log.timestamp)}
              </Text>
            </View>
            
            {log.data?.madhhab && (
              <View style={styles.logDetail}>
                <Text style={[styles.logDetailLabel, { color: theme.colors.textSecondary }]}>
                  المذهب:
                </Text>
                <Text style={[styles.logDetailValue, { color: theme.colors.text }]}>
                  {getMadhhabName(log.data.madhhab)}
                </Text>
              </View>
            )}
            
            {log.data?.heirs && (
              <View style={styles.logDetail}>
                <Text style={[styles.logDetailLabel, { color: theme.colors.textSecondary }]}>
                  الورثة:
                </Text>
                <Text style={[styles.logDetailValue, { color: theme.colors.text }]}>
                  {Object.entries(log.data.heirs)
                    .map(([k, v]) => `${FIQH_DATABASE.heirNames[k] || k}: ${v}`)
                    .join('، ')}
                </Text>
              </View>
            )}
            
            {log.data?.summary && (
              <View style={[styles.logSummary, { backgroundColor: theme.colors.surfaceVariant }]}>
                {log.data.summary.heirsCount && (
                  <Text style={[styles.summaryText, { color: theme.colors.textSecondary }]}>
                    عدد الورثة: {log.data.summary.heirsCount}
                  </Text>
                )}
                {log.data.summary.specialCase && (
                  <Text style={[styles.summaryText, { color: theme.colors.warning }]}>
                    حالة خاصة: {log.data.summary.specialCase}
                  </Text>
                )}
              </View>
            )}
          </View>
        ))}
      </View>
    );
  };
  
  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* أزرار التحكم */}
        <View style={styles.buttonsContainer}>
          <TouchableOpacity 
            style={[styles.exportButton, { backgroundColor: theme.colors.primary }]} 
            onPress={exportLogs}
          >
            <Text style={styles.exportButtonText}>📤 تصدير السجلات</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={[styles.clearButton, { 
              backgroundColor: theme.colors.error + '20',
              borderColor: theme.colors.error
            }]} 
            onPress={clearLogs}
          >
            <Text style={[styles.clearButtonText, { color: theme.colors.error }]}>
              🗑️ مسح الكل
            </Text>
          </TouchableOpacity>
        </View>
        
        {/* الإحصائيات */}
        {renderStats()}
        
        {/* السجلات */}
        {renderLogs()}
        
        <View style={styles.bottomSpace} />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  buttonsContainer: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    marginBottom: 16,
    gap: 12,
  },
  exportButton: {
    flex: 1,
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  exportButtonText: {
    color: '#fff',
    fontSize: 15,
    fontWeight: '600',
  },
  clearButton: {
    paddingVertical: 14,
    paddingHorizontal: 20,
    borderRadius: 12,
    borderWidth: 1,
  },
  clearButtonText: {
    fontSize: 15,
    fontWeight: '600',
  },
  statsCard: {
    borderRadius: 20,
    padding: 20,
    marginBottom: 20,
    elevation: 4,
  },
  statsTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 16,
    textAlign: 'center',
  },
  statsGrid: {
    flexDirection: 'row-reverse',
    flexWrap: 'wrap',
    gap: 10,
  },
  statBox: {
    alignItems: 'center',
    padding: 14,
    borderRadius: 12,
    minWidth: '30%',
    flex: 1,
  },
  statValue: {
    fontSize: 24,
    fontWeight: '800',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    fontWeight: '600',
  },
  madhhabStats: {
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 1,
  },
  madhhabStatsTitle: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 10,
  },
  madhhabStatRow: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    paddingVertical: 6,
  },
  madhhabStatName: {
    fontSize: 14,
  },
  madhhabStatCount: {
    fontSize: 14,
    fontWeight: '700',
  },
  filtersContainer: {
    marginBottom: 16,
  },
  filterButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginHorizontal: 4,
  },
  filterText: {
    fontSize: 13,
    fontWeight: '600',
  },
  logsTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 12,
  },
  logCard: {
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
  },
  logHeader: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  logTypeBadge: {
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderRadius: 12,
  },
  logTypeText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '700',
  },
  logDate: {
    fontSize: 12,
  },
  logDetail: {
    flexDirection: 'row-reverse',
    marginBottom: 6,
  },
  logDetailLabel: {
    fontSize: 13,
    marginLeft: 6,
  },
  logDetailValue: {
    fontSize: 13,
    flex: 1,
    textAlign: 'right',
  },
  logSummary: {
    borderRadius: 10,
    padding: 12,
    marginTop: 10,
  },
  summaryText: {
    fontSize: 12,
    marginBottom: 4,
  },
  emptyContainer: {
    alignItems: 'center',
    padding: 40,
  },
  emptyIcon: {
    fontSize: 50,
    marginBottom: 12,
  },
  emptyText: {
    fontSize: 16,
  },
  bottomSpace: {
    height: 40,
  },
});

export default AuditScreen;
