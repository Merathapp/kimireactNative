/**
 * @fileoverview شاشة الحاسبة الرئيسية
 * @module screens/CalculatorScreen
 */

import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from 'react-native';
import { useTheme, useCalculator } from '../contexts';
import { MADHABS_LIST, FIQH_DATABASE } from '../core';

// مكون اختيار المذهب
const MadhhabSelector = ({ selected, onSelect, theme }) => (
  <View style={styles.madhhabContainer}>
    <Text style={[styles.sectionTitle, { color: theme.colors.text }]}>
      اختر المذهب:
    </Text>
    <ScrollView 
      horizontal 
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={styles.madhhabScroll}
    >
      {MADHABS_LIST.map((madhhab) => (
        <TouchableOpacity
          key={madhhab.id}
          style={[
            styles.madhhabButton,
            { 
              backgroundColor: selected === madhhab.id 
                ? madhhab.lightColor 
                : theme.colors.surfaceVariant,
              borderColor: selected === madhhab.id 
                ? madhhab.color 
                : theme.colors.border
            }
          ]}
          onPress={() => onSelect(madhhab.id)}
          activeOpacity={0.7}
        >
          <Text style={styles.madhhabIcon}>{madhhab.icon}</Text>
          <Text style={[
            styles.madhhabName,
            { 
              color: selected === madhhab.id 
                ? madhhab.color 
                : theme.colors.textSecondary 
            }
          ]}>
            {madhhab.name}
          </Text>
        </TouchableOpacity>
      ))}
    </ScrollView>
  </View>
);

// مكون زر الورثة
const HeirButton = ({ heir, count, onAdd, onRemove, theme }) => (
  <View style={styles.heirButtonContainer}>
    <TouchableOpacity
      style={[
        styles.heirButton,
        { 
          backgroundColor: count > 0 
            ? heir.color + '20' 
            : theme.colors.surface,
          borderColor: count > 0 ? heir.color : theme.colors.border
        }
      ]}
      onPress={() => onAdd(heir.key)}
      onLongPress={() => count > 0 && onRemove(heir.key)}
      activeOpacity={0.7}
    >
      <Text style={styles.heirIcon}>{heir.icon}</Text>
      <Text style={[
        styles.heirName,
        { color: count > 0 ? heir.color : theme.colors.text }
      ]}>
        {heir.name}
      </Text>
      {count > 0 && (
        <View style={[styles.countBadge, { backgroundColor: heir.color }]}>
          <Text style={styles.countText}>{count}</Text>
        </View>
      )}
    </TouchableOpacity>
    {count > 0 && (
      <View style={styles.heirControls}>
        <TouchableOpacity
          style={[styles.controlButton, { backgroundColor: heir.color }]}
          onPress={() => onRemove(heir.key)}
        >
          <Text style={styles.controlText}>-</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.controlButton, { backgroundColor: heir.color }]}
          onPress={() => onAdd(heir.key)}
        >
          <Text style={styles.controlText}>+</Text>
        </TouchableOpacity>
      </View>
    )}
  </View>
);

// مكون قسم الورثة
const HeirSection = ({ title, heirs, onAdd, onRemove, theme }) => (
  <View style={styles.sectionContainer}>
    <Text style={[styles.sectionTitle, { color: theme.colors.text }]}>
      {title}
    </Text>
    <View style={styles.heirsGrid}>
      {heirs.map((heir) => (
        <HeirButton
          key={heir.key}
          heir={heir}
          count={heir.count}
          onAdd={onAdd}
          onRemove={onRemove}
          theme={theme}
        />
      ))}
    </View>
  </View>
);

// مكون عرض النتائج
const ResultsCard = ({ results, blocked, specialCase, awlFactor, theme }) => {
  if (!results) return null;
  
  return (
    <View style={[styles.resultsCard, { backgroundColor: theme.colors.surface }]}>
      <Text style={[styles.resultsTitle, { color: theme.colors.text }]}>
        نتائج التوزيع:
      </Text>
      
      {/* الحالة الخاصة */}
      {specialCase && (
        <View style={[styles.specialCaseBanner, { backgroundColor: theme.colors.warning + '20' }]}>
          <Text style={[styles.specialCaseText, { color: theme.colors.warning }]}>
            ⚠️ حالة خاصة: {specialCase === 'umariyyah' ? 'العمرية' : 
                          specialCase === 'musharraka' ? 'المشتركة' : 
                          specialCase === 'akdariyya' ? 'الأكدرية' : specialCase}
          </Text>
        </View>
      )}
      
      {/* العول */}
      {awlFactor && (
        <View style={[styles.awlBanner, { backgroundColor: theme.colors.error + '20' }]}>
          <Text style={[styles.awlText, { color: theme.colors.error }]}>
            📊 عول من {awlFactor}
          </Text>
        </View>
      )}
      
      {/* جدول النتائج */}
      <View style={styles.resultsTable}>
        <View style={[styles.tableHeader, { borderBottomColor: theme.colors.border }]}>
          <Text style={[styles.headerCell, { color: theme.colors.textSecondary }]}>الوارث</Text>
          <Text style={[styles.headerCell, { color: theme.colors.textSecondary }]}>العدد</Text>
          <Text style={[styles.headerCell, { color: theme.colors.textSecondary }]}>الحصة</Text>
          <Text style={[styles.headerCell, { color: theme.colors.textSecondary }]}>النسبة</Text>
        </View>
        
        {results.map((result, index) => (
          <View 
            key={index} 
            style={[
              styles.tableRow,
              { borderBottomColor: theme.colors.borderLight }
            ]}
          >
            <Text style={[styles.cell, { color: theme.colors.text }]}>
              {result.name}
            </Text>
            <Text style={[styles.cell, { color: theme.colors.textSecondary }]}>
              {result.count}
            </Text>
            <Text style={[styles.cell, styles.shareCell, { color: theme.colors.success }]}>
              {result.shareArabic}
            </Text>
            <Text style={[styles.cell, { color: theme.colors.textSecondary }]}>
              {result.sharePercent}
            </Text>
          </View>
        ))}
      </View>
      
      {/* المحجوبون */}
      {blocked && blocked.length > 0 && (
        <View style={styles.blockedSection}>
          <Text style={[styles.blockedTitle, { color: theme.colors.textSecondary }]}>
            المحجوبون:
          </Text>
          {blocked.map((b, index) => (
            <Text key={index} style={[styles.blockedText, { color: theme.colors.textTertiary }]}>
              • {FIQH_DATABASE.heirNames[b.heir] || b.heir}: {b.reason}
            </Text>
          ))}
        </View>
      )}
    </View>
  );
};

// الشاشة الرئيسية
const CalculatorScreen = () => {
  const { theme } = useTheme();
  const { state, setMadhhab, addHeir, removeHeir, clearHeirs, setEstate, calculate } = useCalculator();
  const { madhhab, heirs, estate, results, loading, error } = state;
  
  // تصنيفات الورثة
  const heirCategories = {
    spouses: [
      { key: 'husband', name: 'زوج', color: '#8b5cf6', icon: '👨' },
      { key: 'wife', name: 'زوجة', color: '#ec4899', icon: '👩' },
    ],
    parents: [
      { key: 'father', name: 'أب', color: '#3b82f6', icon: '👴' },
      { key: 'mother', name: 'أم', color: '#06b6d4', icon: '👵' },
      { key: 'grandfather', name: 'جد', color: '#6366f1', icon: '🧓' },
      { key: 'grandmother', name: 'جدة', color: '#a855f7', icon: '👵' },
    ],
    children: [
      { key: 'son', name: 'ابن', color: '#10b981', icon: '👦' },
      { key: 'daughter', name: 'بنت', color: '#f59e0b', icon: '👧' },
      { key: 'grandson', name: 'ابن الابن', color: '#14b8a6', icon: '👶' },
      { key: 'granddaughter', name: 'بنت الابن', color: '#f97316', icon: '👶' },
    ],
    siblings: [
      { key: 'full_brother', name: 'أخ شقيق', color: '#ef4444', icon: '👨' },
      { key: 'full_sister', name: 'أخت شقيقة', color: '#f43f5e', icon: '👩' },
      { key: 'paternal_brother', name: 'أخ لأب', color: '#dc2626', icon: '👨' },
      { key: 'paternal_sister', name: 'أخت لأب', color: '#e11d48', icon: '👩' },
      { key: 'maternal_brother', name: 'أخ لأم', color: '#b91c1c', icon: '👨' },
      { key: 'maternal_sister', name: 'أخت لأم', color: '#be123c', icon: '👩' },
    ],
  };
  
  const getHeirsWithCount = (categoryHeirs) => {
    return categoryHeirs.map((heir) => ({
      ...heir,
      count: heirs[heir.key] || 0,
    }));
  };
  
  const handleCalculate = () => {
    if (Object.keys(heirs).length === 0) {
      Alert.alert('تنبيه', 'الرجاء إضافة ورثة أولاً');
      return;
    }
    calculate();
  };
  
  const handleClear = () => {
    Alert.alert(
      'تأكيد',
      'هل أنت متأكد من مسح جميع الورثة؟',
      [
        { text: 'إلغاء', style: 'cancel' },
        { text: 'مسح', style: 'destructive', onPress: clearHeirs }
      ]
    );
  };
  
  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={[styles.container, { backgroundColor: theme.colors.background }]}
    >
      <ScrollView 
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
      >
        {/* اختيار المذهب */}
        <MadhhabSelector 
          selected={madhhab} 
          onSelect={setMadhhab} 
          theme={theme} 
        />
        
        {/* بيانات التركة */}
        <View style={[styles.estateContainer, { backgroundColor: theme.colors.surface }]}>
          <Text style={[styles.sectionTitle, { color: theme.colors.text }]}>
            قيمة التركة (اختياري):
          </Text>
          <TextInput
            style={[
              styles.estateInput,
              { 
                color: theme.colors.text,
                backgroundColor: theme.colors.surfaceVariant,
                borderColor: theme.colors.border
              }
            ]}
            placeholder="أدخل المبلغ (ريال سعودي)"
            placeholderTextColor={theme.colors.textTertiary}
            value={estate}
            onChangeText={setEstate}
            keyboardType="numeric"
            textAlign="right"
          />
        </View>
        
        {/* الورثة */}
        <HeirSection
          title="الزوج/الزوجة:"
          heirs={getHeirsWithCount(heirCategories.spouses)}
          onAdd={addHeir}
          onRemove={removeHeir}
          theme={theme}
        />
        
        <HeirSection
          title="الأب/الأم/الجد/الجدة:"
          heirs={getHeirsWithCount(heirCategories.parents)}
          onAdd={addHeir}
          onRemove={removeHeir}
          theme={theme}
        />
        
        <HeirSection
          title="الأبناء/البنات/الأحفاد:"
          heirs={getHeirsWithCount(heirCategories.children)}
          onAdd={addHeir}
          onRemove={removeHeir}
          theme={theme}
        />
        
        <HeirSection
          title="الإخوة/الأخوات:"
          heirs={getHeirsWithCount(heirCategories.siblings)}
          onAdd={addHeir}
          onRemove={removeHeir}
          theme={theme}
        />
        
        {/* أزرار التحكم */}
        <View style={styles.buttonsContainer}>
          <TouchableOpacity
            style={[
              styles.calculateButton,
              { backgroundColor: theme.colors.primary },
              loading && styles.disabledButton
            ]}
            onPress={handleCalculate}
            disabled={loading}
            activeOpacity={0.8}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.calculateButtonText}>حساب المواريث</Text>
            )}
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={[
              styles.clearButton,
              { 
                backgroundColor: theme.colors.surfaceVariant,
                borderColor: theme.colors.border
              }
            ]} 
            onPress={handleClear}
            activeOpacity={0.8}
          >
            <Text style={[styles.clearButtonText, { color: theme.colors.textSecondary }]}>
              مسح الكل
            </Text>
          </TouchableOpacity>
        </View>
        
        {/* خطأ */}
        {error && (
          <View style={[styles.errorContainer, { backgroundColor: theme.colors.error + '20' }]}>
            <Text style={[styles.errorText, { color: theme.colors.error }]}>
              ⚠️ {error}
            </Text>
          </View>
        )}
        
        {/* النتائج */}
        {results && (
          <ResultsCard
            results={results.results}
            blocked={results.blocked}
            specialCase={results.specialCase}
            awlFactor={results.awlFactor}
            theme={theme}
          />
        )}
        
        {/* مساحة فارغة في الأسفل */}
        <View style={styles.bottomSpace} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
    padding: 16,
  },
  
  // المذهب
  madhhabContainer: {
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 12,
    textAlign: 'right',
  },
  madhhabScroll: {
    paddingHorizontal: 4,
    gap: 8,
  },
  madhhabButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 12,
    borderWidth: 1,
    marginHorizontal: 4,
  },
  madhhabIcon: {
    fontSize: 16,
    marginLeft: 8,
  },
  madhhabName: {
    fontSize: 14,
    fontWeight: '600',
  },
  
  // التركة
  estateContainer: {
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  estateInput: {
    borderWidth: 1,
    borderRadius: 12,
    padding: 14,
    fontSize: 16,
    textAlign: 'right',
  },
  
  // قسم الورثة
  sectionContainer: {
    marginBottom: 16,
  },
  heirsGrid: {
    flexDirection: 'row-reverse',
    flexWrap: 'wrap',
    gap: 10,
  },
  
  // زر الورثة
  heirButtonContainer: {
    width: '23%',
    marginBottom: 8,
  },
  heirButton: {
    borderRadius: 12,
    padding: 12,
    alignItems: 'center',
    borderWidth: 1.5,
    position: 'relative',
  },
  heirIcon: {
    fontSize: 24,
    marginBottom: 4,
  },
  heirName: {
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'center',
  },
  countBadge: {
    position: 'absolute',
    top: -6,
    right: -6,
    minWidth: 22,
    height: 22,
    borderRadius: 11,
    alignItems: 'center',
    justifyContent: 'center',
  },
  countText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '700',
  },
  heirControls: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 6,
    gap: 8,
  },
  controlButton: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  controlText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
    lineHeight: 20,
  },
  
  // الأزرار
  buttonsContainer: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    marginVertical: 20,
    gap: 12,
  },
  calculateButton: {
    flex: 1,
    paddingVertical: 16,
    borderRadius: 14,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  disabledButton: {
    opacity: 0.6,
  },
  calculateButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
    textAlign: 'center',
  },
  clearButton: {
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 14,
    borderWidth: 1,
  },
  clearButtonText: {
    fontSize: 16,
    fontWeight: '600',
  },
  
  // الخطأ
  errorContainer: {
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
  },
  errorText: {
    fontSize: 14,
    textAlign: 'center',
  },
  
  // النتائج
  resultsCard: {
    borderRadius: 20,
    padding: 20,
    marginBottom: 20,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
  },
  resultsTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 16,
    textAlign: 'center',
  },
  specialCaseBanner: {
    padding: 12,
    borderRadius: 10,
    marginBottom: 12,
  },
  specialCaseText: {
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
  },
  awlBanner: {
    padding: 12,
    borderRadius: 10,
    marginBottom: 12,
  },
  awlText: {
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
  },
  resultsTable: {
    marginTop: 8,
  },
  tableHeader: {
    flexDirection: 'row-reverse',
    paddingVertical: 10,
    borderBottomWidth: 2,
  },
  headerCell: {
    flex: 1,
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'center',
  },
  tableRow: {
    flexDirection: 'row-reverse',
    paddingVertical: 12,
    borderBottomWidth: 1,
  },
  cell: {
    flex: 1,
    fontSize: 14,
    textAlign: 'center',
  },
  shareCell: {
    fontWeight: '700',
  },
  blockedSection: {
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: '#e2e8f0',
  },
  blockedTitle: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 8,
    textAlign: 'right',
  },
  blockedText: {
    fontSize: 12,
    marginBottom: 4,
    textAlign: 'right',
  },
  
  bottomSpace: {
    height: 40,
  },
});

export default CalculatorScreen;
