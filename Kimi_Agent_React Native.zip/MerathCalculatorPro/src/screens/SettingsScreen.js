/**
 * @fileoverview شاشة الإعدادات
 * @module screens/SettingsScreen
 */

import React from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Switch,
  Alert,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useTheme } from '../contexts';

const SettingsScreen = () => {
  const { theme, isDark, themeMode, toggleTheme, setTheme } = useTheme();
  
  const clearAllData = async () => {
    Alert.alert(
      'تأكيد',
      'هل أنت متأكد من مسح جميع البيانات؟ لا يمكن التراجع عن هذا الإجراء.',
      [
        { text: 'إلغاء', style: 'cancel' },
        { 
          text: 'مسح', 
          style: 'destructive',
          onPress: async () => {
            try {
              await AsyncStorage.clear();
              Alert.alert('تم', 'تم مسح جميع البيانات بنجاح');
            } catch (error) {
              Alert.alert('خطأ', 'فشل في مسح البيانات');
            }
          }
        }
      ]
    );
  };
  
  const settingsGroups = [
    {
      title: 'المظهر',
      items: [
        {
          type: 'select',
          title: 'الوضع الليلي',
          value: themeMode === 'dark',
          onValueChange: toggleTheme,
          description: isDark ? 'مفعل' : 'معطل'
        },
        {
          type: 'radio',
          title: 'نمط السمة',
          options: [
            { label: 'تلقائي (حسب النظام)', value: 'system' },
            { label: 'فاتح', value: 'light' },
            { label: 'مظلم', value: 'dark' }
          ],
          selected: themeMode,
          onSelect: setTheme
        }
      ]
    },
    {
      title: 'البيانات',
      items: [
        {
          type: 'button',
          title: 'مسح جميع البيانات',
          icon: '🗑️',
          danger: true,
          onPress: clearAllData
        }
      ]
    },
    {
      title: 'عن التطبيق',
      items: [
        {
          type: 'info',
          title: 'الإصدار',
          value: '6.0.0'
        },
        {
          type: 'info',
          title: 'المطور',
          value: 'Merath Pro Team'
        }
      ]
    }
  ];
  
  return (
    <ScrollView 
      style={[styles.container, { backgroundColor: theme.colors.background }]}
      showsVerticalScrollIndicator={false}
    >
      {settingsGroups.map((group, groupIndex) => (
        <View key={groupIndex} style={styles.group}>
          <Text style={[styles.groupTitle, { color: theme.colors.textSecondary }]}>
            {group.title}
          </Text>
          
          <View style={[styles.groupContent, { backgroundColor: theme.colors.surface }]}>
            {group.items.map((item, itemIndex) => (
              <View 
                key={itemIndex}
                style={[
                  styles.item,
                  itemIndex < group.items.length - 1 && {
                    borderBottomWidth: 1,
                    borderBottomColor: theme.colors.borderLight
                  }
                ]}
              >
                {item.type === 'select' && (
                  <View style={styles.selectItem}>
                    <View style={styles.selectInfo}>
                      <Text style={[styles.itemTitle, { color: theme.colors.text }]}>
                        {item.title}
                      </Text>
                      <Text style={[styles.itemDescription, { color: theme.colors.textTertiary }]}>
                        {item.description}
                      </Text>
                    </View>
                    <Switch
                      value={item.value}
                      onValueChange={item.onValueChange}
                      trackColor={{ false: '#cbd5e1', true: theme.colors.primary }}
                    />
                  </View>
                )}
                
                {item.type === 'radio' && (
                  <View>
                    <Text style={[styles.itemTitle, { color: theme.colors.text, marginBottom: 12 }]}>
                      {item.title}
                    </Text>
                    {item.options.map((option, optIndex) => (
                      <TouchableOpacity
                        key={optIndex}
                        style={styles.radioOption}
                        onPress={() => item.onSelect(option.value)}
                      >
                        <View style={[
                          styles.radioCircle,
                          { borderColor: theme.colors.border },
                          item.selected === option.value && {
                            borderColor: theme.colors.primary,
                            backgroundColor: theme.colors.primary
                          }
                        ]}>
                          {item.selected === option.value && (
                            <View style={styles.radioInner} />
                          )}
                        </View>
                        <Text style={[
                          styles.radioLabel,
                          { color: item.selected === option.value ? theme.colors.primary : theme.colors.text }
                        ]}>
                          {option.label}
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                )}
                
                {item.type === 'button' && (
                  <TouchableOpacity
                    style={styles.buttonItem}
                    onPress={item.onPress}
                  >
                    <Text style={styles.buttonIcon}>{item.icon}</Text>
                    <Text style={[
                      styles.buttonTitle,
                      item.danger && { color: theme.colors.error }
                    ]}>
                      {item.title}
                    </Text>
                  </TouchableOpacity>
                )}
                
                {item.type === 'info' && (
                  <View style={styles.infoItem}>
                    <Text style={[styles.infoTitle, { color: theme.colors.text }]}>
                      {item.title}
                    </Text>
                    <Text style={[styles.infoValue, { color: theme.colors.textSecondary }]}>
                      {item.value}
                    </Text>
                  </View>
                )}
              </View>
            ))}
          </View>
        </View>
      ))}
      
      <View style={styles.footer}>
        <Text style={[styles.footerText, { color: theme.colors.textTertiary }]}>
          حاسبة المواريث Pro v6.0.0
        </Text>
        <Text style={[styles.footerText, { color: theme.colors.textTertiary }]}>
          جميع الحقوق محفوظة © 2024
        </Text>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  group: {
    marginBottom: 24,
  },
  groupTitle: {
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 8,
    marginHorizontal: 8,
    textTransform: 'uppercase',
  },
  groupContent: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  item: {
    padding: 16,
  },
  selectItem: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  selectInfo: {
    flex: 1,
  },
  itemTitle: {
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'right',
  },
  itemDescription: {
    fontSize: 13,
    marginTop: 4,
    textAlign: 'right',
  },
  radioOption: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    paddingVertical: 10,
  },
  radioCircle: {
    width: 22,
    height: 22,
    borderRadius: 11,
    borderWidth: 2,
    marginLeft: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  radioInner: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#fff',
  },
  radioLabel: {
    fontSize: 15,
    flex: 1,
    textAlign: 'right',
  },
  buttonItem: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
  },
  buttonIcon: {
    fontSize: 20,
    marginLeft: 12,
  },
  buttonTitle: {
    fontSize: 16,
    fontWeight: '600',
    flex: 1,
    textAlign: 'right',
  },
  infoItem: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  infoTitle: {
    fontSize: 16,
    textAlign: 'right',
  },
  infoValue: {
    fontSize: 16,
    fontWeight: '500',
  },
  footer: {
    alignItems: 'center',
    paddingVertical: 24,
  },
  footerText: {
    fontSize: 12,
    marginBottom: 4,
  },
});

export default SettingsScreen;
