/**
 * @fileoverview شاشة حول التطبيق
 * @module screens/AboutScreen
 */

import React from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Linking,
} from 'react-native';
import { useTheme } from '../contexts';

const AboutScreen = () => {
  const { theme } = useTheme();
  
  const appFeatures = [
    { icon: '⚖️', title: 'حساب دقيق', description: 'حسابات فقهية دقيقة لجميع المذاهب' },
    { icon: '📊', title: 'مقارنة المذاهب', description: 'قارن بين نتائج المذاهب الأربعة' },
    { icon: '📚', title: 'تعلم المواريث', description: 'دروس تفاعلية لإتقان علم الفرائض' },
    { icon: '🌙', title: 'وضع مظلم', description: 'واجهة مريحة للعين في الليل' },
    { icon: '📱', title: 'سهل الاستخدام', description: 'تصميم بسيط وبديهي' },
    { icon: '🔒', title: 'خصوصية تامة', description: 'لا يتم جمع أي بيانات شخصية' },
  ];
  
  const contactLinks = [
    { icon: '📧', title: 'البريد الإلكتروني', url: 'mailto:support@merathpro.com' },
    { icon: '🌐', title: 'الموقع الإلكتروني', url: 'https://merathpro.com' },
    { icon: '💬', title: 'تواصل معنا', url: 'https://twitter.com/merathpro' },
  ];
  
  const handleLinkPress = async (url) => {
    try {
      await Linking.openURL(url);
    } catch (error) {
      console.error('Error opening URL:', error);
    }
  };
  
  return (
    <ScrollView 
      style={[styles.container, { backgroundColor: theme.colors.background }]}
      showsVerticalScrollIndicator={false}
    >
      {/* الشعار */}
      <View style={styles.logoSection}>
        <View style={[styles.logoContainer, { backgroundColor: theme.colors.primary }]}>
          <Text style={styles.logoText}>⚖️</Text>
        </View>
        <Text style={[styles.appName, { color: theme.colors.text }]}>
          حاسبة المواريث Pro
        </Text>
        <Text style={[styles.appVersion, { color: theme.colors.textSecondary }]}>
          الإصدار 6.0.0
        </Text>
      </View>
      
      {/* الوصف */}
      <View style={[styles.descriptionCard, { backgroundColor: theme.colors.surface }]}>
        <Text style={[styles.descriptionText, { color: theme.colors.text }]}>
          تطبيق احترافي لحساب المواريث الإسلامية وفق المذاهب الأربعة (الشافعي، 
          الحنفي، المالكي، الحنبلي). يوفر حسابات دقيقة مع دعم جميع الحالات 
          الخاصة والفروض والحجب.
        </Text>
      </View>
      
      {/* المميزات */}
      <View style={styles.section}>
        <Text style={[styles.sectionTitle, { color: theme.colors.text }]}>
          مميزات التطبيق
        </Text>
        <View style={styles.featuresGrid}>
          {appFeatures.map((feature, index) => (
            <View 
              key={index} 
              style={[styles.featureCard, { backgroundColor: theme.colors.surface }]}
            >
              <Text style={styles.featureIcon}>{feature.icon}</Text>
              <Text style={[styles.featureTitle, { color: theme.colors.text }]}>
                {feature.title}
              </Text>
              <Text style={[styles.featureDescription, { color: theme.colors.textSecondary }]}>
                {feature.description}
              </Text>
            </View>
          ))}
        </View>
      </View>
      
      {/* روابط التواصل */}
      <View style={styles.section}>
        <Text style={[styles.sectionTitle, { color: theme.colors.text }]}>
          تواصل معنا
        </Text>
        <View style={[styles.linksCard, { backgroundColor: theme.colors.surface }]}>
          {contactLinks.map((link, index) => (
            <TouchableOpacity
              key={index}
              style={[
                styles.linkItem,
                index < contactLinks.length - 1 && {
                  borderBottomWidth: 1,
                  borderBottomColor: theme.colors.borderLight
                }
              ]}
              onPress={() => handleLinkPress(link.url)}
            >
              <Text style={styles.linkIcon}>{link.icon}</Text>
              <Text style={[styles.linkTitle, { color: theme.colors.text }]}>
                {link.title}
              </Text>
              <Text style={[styles.linkArrow, { color: theme.colors.textSecondary }]}>
                ←
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>
      
      {/* التقييم */}
      <View style={styles.section}>
        <TouchableOpacity
          style={[styles.rateButton, { backgroundColor: theme.colors.primary }]}
          onPress={() => handleLinkPress('market://details?id=com.merathpro.calculator')}
        >
          <Text style={styles.rateButtonText}>⭐ قيّم التطبيق</Text>
        </TouchableOpacity>
      </View>
      
      {/* حقوق النشر */}
      <View style={styles.footer}>
        <Text style={[styles.footerText, { color: theme.colors.textTertiary }]}>
          جميع الحقوق محفوظة © 2024
        </Text>
        <Text style={[styles.footerText, { color: theme.colors.textTertiary }]}>
          Merath Pro Team
        </Text>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  logoSection: {
    alignItems: 'center',
    paddingVertical: 24,
  },
  logoContainer: {
    width: 100,
    height: 100,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
  },
  logoText: {
    fontSize: 50,
  },
  appName: {
    fontSize: 24,
    fontWeight: '800',
    marginBottom: 4,
  },
  appVersion: {
    fontSize: 14,
  },
  descriptionCard: {
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  descriptionText: {
    fontSize: 15,
    lineHeight: 24,
    textAlign: 'center',
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 16,
    textAlign: 'right',
  },
  featuresGrid: {
    flexDirection: 'row-reverse',
    flexWrap: 'wrap',
    gap: 12,
  },
  featureCard: {
    width: '47%',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  featureIcon: {
    fontSize: 32,
    marginBottom: 8,
  },
  featureTitle: {
    fontSize: 14,
    fontWeight: '700',
    marginBottom: 4,
    textAlign: 'center',
  },
  featureDescription: {
    fontSize: 12,
    textAlign: 'center',
    lineHeight: 18,
  },
  linksCard: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  linkItem: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    padding: 16,
  },
  linkIcon: {
    fontSize: 20,
    marginLeft: 12,
  },
  linkTitle: {
    flex: 1,
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'right',
  },
  linkArrow: {
    fontSize: 18,
  },
  rateButton: {
    borderRadius: 14,
    paddingVertical: 16,
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  rateButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
  footer: {
    alignItems: 'center',
    paddingVertical: 24,
  },
  footerText: {
    fontSize: 13,
    marginBottom: 4,
  },
});

export default AboutScreen;
