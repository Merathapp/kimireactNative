/**
 * @fileoverview شاشة التعلم والتدريب
 * @module screens/LearningScreen
 */

import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  FlatList,
} from 'react-native';
import { useTheme } from '../contexts';

// بيانات الدروس
const LESSONS = [
  {
    id: '1',
    title: 'مقدمة في علم المواريث',
    description: 'تعرف على أساسيات علم الفرائض وأهميته',
    icon: '📖',
    level: 'مبتدئ',
    duration: '5 دقائق',
    content: `
      علم المواريث (الفرائض) هو أحد العلوم الإسلامية المهمة التي تتناول توزيع التركة على الورثة.
      
      أهمية علم المواريث:
      • تحقيق العدالة في توزيع الميراث
      • صيانة حقوق الورثة
      • منع النزاعات العائلية
      • الوفاء بوصية الله تعالى
      
      الآية الكريمة: {يُوصِيكُمُ اللَّهُ فِي أَوْلَادِكُمْ}
    `
  },
  {
    id: '2',
    title: 'الفرائض الستة',
    description: 'تعرف على الفروض الستة الأساسية في الميراث',
    icon: '🔢',
    level: 'مبتدئ',
    duration: '10 دقائق',
    content: `
      الفرائض الستة هي:
      
      1. النصف (1/2)
         - للزوجة إذا لم يكن للمتوفى فرع وارث
         - للبنت إذا كانت وحيدة
         - للأخت الشقيقة إذا كانت وحيدة
      
      2. الربع (1/4)
         - للزوجة إذا وجد فرع وارث
         - للزوج إذا لم يكن للمتوفى فرع وارث
      
      3. الثمن (1/8)
         - للزوجة إذا وجد فرع وارث
      
      4. الثلث (1/3)
         - للأم إذا لم يكن فرع وارث ولا إخوة
         - للأخوات لأم إذا كن اثنتين أو أكثر
      
      5. ثلثا (2/3)
         - للبنتين فأكثر
         - للأختين الشقيقتين فأكثر
         - لبنات الابن إذا كن اثنتين فأكثر
      
      6. السدس (1/6)
         - للأب مع الفرع الوارث
         - للأم مع الفرع الوارث أو الإخوة
         - للجد مع الفرع الوارث
         - للجدة
         - للأخوة لأم
    `
  },
  {
    id: '3',
    title: 'أصحاب الفروض',
    description: 'تعرف على الورثة أصحاب الفروض الثابتة',
    icon: '👥',
    level: 'متوسط',
    duration: '15 دقائق',
    content: `
      أصحاب الفروض هم الورثة الذين لهم نصيب ثابت في التركة:
      
      1. الزوجان:
         - الزوج: 1/2 بدون فرع وارث، 1/4 مع فرع وارث
         - الزوجة: 1/4 بدون فرع وارث، 1/8 مع فرع وارث
      
      2. الآباء:
         - الأب: 1/6 مع فرع وارث، الباقي بدونه
         - الأم: 1/3 بدون فرع وارث أو إخوة، 1/6 معهما
         - الجد: مثل الأب
         - الجدة: 1/6
      
      3. الأبناء:
         - البنت: 1/2 وحيدة، 2/3 اثنتان فأكثر
         - بنت الابن: مثل البنت
      
      4. الإخوة:
         - الأخوات الشقيقات: 1/2 وحيدة، 2/3 اثنتان فأكثر
         - الأخوات لأب: مثل الشقيقات
         - الأخوة لأم: 1/6 واحد، 1/3 اثنان فأكثر
    `
  },
  {
    id: '4',
    title: 'العصبات',
    description: 'تعرف على العصبات وأنواعهم',
    icon: '⚔️',
    level: 'متوسط',
    duration: '12 دقائق',
    content: `
      العصبة هو من يأخذ الباقي بعد أصحاب الفروض.
      
      أنواع العصبة:
      
      1. العصبة بالنفس:
         - الابن: يأخذ الباقي للذكر مثل حظ الأنثيين
         - الأب: يأخذ الباقي إذا لم يكن فرع وارث
         - الجد: مثل الأب
         - الإخوة: يأخذون الباقي إذا لم يكن أب أو جد أو فرع وارث
      
      2. العصبة بغيرها:
         - ابن الابن: يعصب مع ابن
         - أخوات مع إخوة
      
      3. العصبة مع الغير:
         - الأخت الشقيقة مع الأخ الشقيق
         - الأخت لأب مع الأخ لأب
    `
  },
  {
    id: '5',
    title: 'الحالات الخاصة',
    description: 'تعرف على الحالات الخاصة في المواريث',
    icon: '⭐',
    level: 'متقدم',
    duration: '20 دقائق',
    content: `
      الحالات الخاصة في المواريث:
      
      1. العول:
         - تعريف: زيادة مجموع الفروض عن أصل المسألة
         - الحل: زيادة المقام لتصحيح التوزيع
         - مثال: زوج + أم + أختين = 1/2 + 1/6 + 2/3 = 8/6 > 1
         - يصبح: 3/8 + 1/8 + 4/8
      
      2. الرد:
         - تعريف: توزيع الباقي على أصحاب الفروض
         - الشرط: عدم وجود عصبة ولا ذوي أرحام
         - مثال: أم + بنت، الباقي يرد عليهما
      
      3. العمرية:
         - تعريف: زوج + أب/جد + أم/جدة بدون فرع وارث
         - الأم تأخذ ثلث الباقي بدلاً من الثلث
      
      4. المشتركة:
         - زوج + أم + إخوة لأم (2+) + إخوة أشقاء
         - الإخوة الأشقاء يشتركون مع الإخوة لأم
      
      5. الأكدرية:
         - زوج + أم + جد + أخت شقيقة
         - توزيع خاص بأصل 12
    `
  },
  {
    id: '6',
    title: 'أصول المسائل',
    description: 'تعرف على أصول المسائل وكيفية حسابها',
    icon: '📐',
    level: 'متقدم',
    duration: '15 دقائق',
    content: `
      أصول المسائل هي الأعداد التي يتم توزيع التركة على أساسها.
      
      أصول المسائل الأساسية:
      - 2: للنصف
      - 3: للثلث وثلثا
      - 4: للربع والنصف
      - 6: للسدس والنصف والثلث
      - 8: للثمن والربع والنصف
      - 12: للثلث والربع والسدس
      - 24: لمجموعات متعددة
      
      كيفية حساب أصل المسألة:
      1. حدد جميع الفروض الموجودة
      2. احسب المضاعف المشترك الأصغر للمقامات
      3. هذا هو أصل المسألة
      
      مثال:
      - زوج: 1/2
      - أم: 1/6
      - أخت: 1/2
      الأصل: 6 (مضاعف 2 و6)
    `
  }
];

// مكون بطاقة الدرس
const LessonCard = ({ lesson, onPress, theme }) => (
  <TouchableOpacity
    style={[styles.lessonCard, { backgroundColor: theme.colors.surface }]}
    onPress={() => onPress(lesson)}
    activeOpacity={0.7}
  >
    <View style={styles.lessonHeader}>
      <Text style={styles.lessonIcon}>{lesson.icon}</Text>
      <View style={styles.lessonInfo}>
        <Text style={[styles.lessonTitle, { color: theme.colors.text }]}>
          {lesson.title}
        </Text>
        <Text style={[styles.lessonDescription, { color: theme.colors.textSecondary }]}>
          {lesson.description}
        </Text>
      </View>
    </View>
    <View style={styles.lessonMeta}>
      <View style={[styles.levelBadge, { 
        backgroundColor: lesson.level === 'مبتدئ' ? '#10b98120' : 
                        lesson.level === 'متوسط' ? '#f59e0b20' : '#ef444420'
      }]}>
        <Text style={[styles.levelText, { 
          color: lesson.level === 'مبتدئ' ? '#059669' : 
                 lesson.level === 'متوسط' ? '#d97706' : '#dc2626'
        }]}>
          {lesson.level}
        </Text>
      </View>
      <Text style={[styles.duration, { color: theme.colors.textTertiary }]}>
        ⏱️ {lesson.duration}
      </Text>
    </View>
  </TouchableOpacity>
);

// مكون عرض محتوى الدرس
const LessonContent = ({ lesson, onBack, theme }) => (
  <ScrollView style={styles.contentContainer}>
    <TouchableOpacity style={styles.backButton} onPress={onBack}>
      <Text style={[styles.backText, { color: theme.colors.primary }]}>
        ← العودة للدروس
      </Text>
    </TouchableOpacity>
    
    <View style={[styles.contentCard, { backgroundColor: theme.colors.surface }]}>
      <Text style={styles.contentIcon}>{lesson.icon}</Text>
      <Text style={[styles.contentTitle, { color: theme.colors.text }]}>
        {lesson.title}
      </Text>
      <Text style={[styles.contentBody, { color: theme.colors.text }]}>
        {lesson.content}
      </Text>
    </View>
  </ScrollView>
);

const LearningScreen = () => {
  const { theme } = useTheme();
  const [selectedLesson, setSelectedLesson] = useState(null);
  
  if (selectedLesson) {
    return (
      <LessonContent
        lesson={selectedLesson}
        onBack={() => setSelectedLesson(null)}
        theme={theme}
      />
    );
  }
  
  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <View style={styles.header}>
        <Text style={[styles.headerTitle, { color: theme.colors.text }]}>
          تعلم المواريث
        </Text>
        <Text style={[styles.headerSubtitle, { color: theme.colors.textSecondary }]}>
          دروس تفاعلية لإتقان علم الفرائض
        </Text>
      </View>
      
      <FlatList
        data={LESSONS}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <LessonCard
            lesson={item}
            onPress={setSelectedLesson}
            theme={theme}
          />
        )}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    padding: 20,
    paddingTop: 16,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: '800',
    textAlign: 'center',
    marginBottom: 8,
  },
  headerSubtitle: {
    fontSize: 16,
    textAlign: 'center',
  },
  listContent: {
    padding: 16,
    paddingTop: 0,
  },
  lessonCard: {
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  lessonHeader: {
    flexDirection: 'row-reverse',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  lessonIcon: {
    fontSize: 40,
    marginLeft: 12,
  },
  lessonInfo: {
    flex: 1,
  },
  lessonTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 6,
    textAlign: 'right',
  },
  lessonDescription: {
    fontSize: 14,
    lineHeight: 20,
    textAlign: 'right',
  },
  lessonMeta: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
  },
  levelBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
    marginLeft: 12,
  },
  levelText: {
    fontSize: 12,
    fontWeight: '600',
  },
  duration: {
    fontSize: 13,
  },
  
  // محتوى الدرس
  contentContainer: {
    flex: 1,
    padding: 16,
  },
  backButton: {
    marginBottom: 16,
  },
  backText: {
    fontSize: 16,
    fontWeight: '600',
  },
  contentCard: {
    borderRadius: 20,
    padding: 24,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
  },
  contentIcon: {
    fontSize: 60,
    textAlign: 'center',
    marginBottom: 16,
  },
  contentTitle: {
    fontSize: 24,
    fontWeight: '800',
    textAlign: 'center',
    marginBottom: 20,
  },
  contentBody: {
    fontSize: 16,
    lineHeight: 28,
    textAlign: 'right',
  },
});

export default LearningScreen;
