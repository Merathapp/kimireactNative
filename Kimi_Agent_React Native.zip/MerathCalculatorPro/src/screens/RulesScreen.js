/**
 * @fileoverview شاشة القواعد الفقهية
 * @module screens/RulesScreen
 */

import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';
import { useTheme } from '../contexts';
import { FIQH_DATABASE, SPECIAL_CASES } from '../core';

// جدول الفروض
const SHARES_TABLE = [
  { share: '1/2', heirs: 'الزوج (بدون فرع)، البنت (وحيدة)، الأخت الشقيقة (وحيدة)' },
  { share: '1/4', heirs: 'الزوج (مع فرع)، الزوجة (بدون فرع)' },
  { share: '1/8', heirs: 'الزوجة (مع فرع)' },
  { share: '2/3', heirs: 'البنتان فأكثر، الأختان الشقيقتان فأكثر' },
  { share: '1/3', heirs: 'الأم (بدون فرع أو إخوة)، الأخوات لأم (اثنتان فأكثر)' },
  { share: '1/6', heirs: 'الأب (مع فرع)، الأم (مع فرع أو إخوة)، الجدة، الجد (مع فرع)، الأخوة لأم' },
];

// قواعد الحجب
const BLOCKING_RULES = [
  { blocked: 'الجد', blocker: 'الأب', reason: 'الأب أقرب من الجد' },
  { blocked: 'الجدة', blocker: 'الأم', reason: 'الأم أقرب من الجدة' },
  { blocked: 'ابن الابن', blocker: 'الابن', reason: 'الابن أقرب' },
  { blocked: 'بنت الابن', blocker: 'الابن أو البنت', reason: 'الأقرب يحجب الأبعد' },
  { blocked: 'الإخوة', blocker: 'الأب أو الجد', reason: 'الأب/الجد يحجبان الإخوة' },
  { blocked: 'الإخوة لأم', blocker: 'الأبناء', reason: 'الأبناء يحجبون الإخوة لأم' },
  { blocked: 'الإخوة لأب', blocker: 'الإخوة الأشقاء', reason: 'الأشقاء أقرب' },
];

const RulesScreen = () => {
  const { theme } = useTheme();
  const [activeTab, setActiveTab] = useState('shares');
  
  const tabs = [
    { id: 'shares', title: 'الفروض', icon: '📊' },
    { id: 'blocking', title: 'الحجب', icon: '🚫' },
    { id: 'special', title: 'حالات خاصة', icon: '⭐' },
    { id: 'madhabs', title: 'المذاهب', icon: '🕌' },
  ];
  
  const renderSharesTable = () => (
    <View style={[styles.tableCard, { backgroundColor: theme.colors.surface }]}>
      <Text style={[styles.tableTitle, { color: theme.colors.text }]}>
        جدول الفروض الأساسية
      </Text>
      
      <View style={styles.table}>
        <View style={[styles.tableHeader, { borderBottomColor: theme.colors.border }]}>
          <Text style={[styles.headerCell, { color: theme.colors.textSecondary }]}>الفرض</Text>
          <Text style={[styles.headerCellLarge, { color: theme.colors.textSecondary }]}>الورثة</Text>
        </View>
        
        {SHARES_TABLE.map((row, index) => (
          <View 
            key={index} 
            style={[styles.tableRow, { borderBottomColor: theme.colors.borderLight }]}
          >
            <View style={styles.shareCell}>
              <Text style={[styles.shareText, { color: theme.colors.success }]}>
                {row.share}
              </Text>
            </View>
            <View style={styles.heirsCell}>
              <Text style={[styles.heirsText, { color: theme.colors.text }]}>
                {row.heirs}
              </Text>
            </View>
          </View>
        ))}
      </View>
    </View>
  );
  
  const renderBlockingRules = () => (
    <View style={[styles.tableCard, { backgroundColor: theme.colors.surface }]}>
      <Text style={[styles.tableTitle, { color: theme.colors.text }]}>
        قواعد الحجب
      </Text>
      
      <View style={styles.table}>
        <View style={[styles.tableHeader, { borderBottomColor: theme.colors.border }]}>
          <Text style={[styles.headerCell, { color: theme.colors.textSecondary }]}>المحجوب</Text>
          <Text style={[styles.headerCell, { color: theme.colors.textSecondary }]}>الحاجب</Text>
          <Text style={[styles.headerCellLarge, { color: theme.colors.textSecondary }]}>السبب</Text>
        </View>
        
        {BLOCKING_RULES.map((rule, index) => (
          <View 
            key={index} 
            style={[styles.tableRow, { borderBottomColor: theme.colors.borderLight }]}
          >
            <View style={styles.cell}>
              <Text style={[styles.cellText, { color: theme.colors.error }]}>
                {rule.blocked}
              </Text>
            </View>
            <View style={styles.cell}>
              <Text style={[styles.cellText, { color: theme.colors.success }]}>
                {rule.blocker}
              </Text>
            </View>
            <View style={styles.heirsCell}>
              <Text style={[styles.heirsText, { color: theme.colors.textSecondary }]}>
                {rule.reason}
              </Text>
            </View>
          </View>
        ))}
      </View>
    </View>
  );
  
  const renderSpecialCases = () => (
    <View>
      {Object.values(SPECIAL_CASES).map((caseItem, index) => (
        <View 
          key={index} 
          style={[styles.caseCard, { backgroundColor: theme.colors.surface }]}
        >
          <View style={styles.caseHeader}>
            <Text style={styles.caseIcon}>⭐</Text>
            <Text style={[styles.caseName, { color: theme.colors.text }]}>
              {caseItem.name}
            </Text>
          </View>
          <Text style={[styles.caseDescription, { color: theme.colors.textSecondary }]}>
            {caseItem.description}
          </Text>
          <View style={[styles.madhabsContainer, { borderTopColor: theme.colors.borderLight }]}>
            <Text style={[styles.madhabsLabel, { color: theme.colors.textTertiary }]}>
              المذاهب:
            </Text>
            <Text style={[styles.madhabsText, { color: theme.colors.textSecondary }]}>
              {caseItem.madhabs.map(m => FIQH_DATABASE.madhabs[m]?.name || m).join('، ')}
            </Text>
          </View>
        </View>
      ))}
    </View>
  );
  
  const renderMadhhabs = () => (
    <View>
      {Object.values(FIQH_DATABASE.madhabs).map((madhhab, index) => (
        <View 
          key={index} 
          style={[styles.madhhabCard, { backgroundColor: theme.colors.surface }]}
        >
          <View style={styles.madhhabHeader}>
            <View style={[styles.madhhabIconContainer, { backgroundColor: madhhab.lightColor }]}>
              <Text style={styles.madhhabIcon}>{madhhab.icon}</Text>
            </View>
            <View style={styles.madhhabInfo}>
              <Text style={[styles.madhhabName, { color: madhhab.color }]}>
                {madhhab.name}
              </Text>
              <Text style={[styles.madhhabScholar, { color: theme.colors.textSecondary }]}>
                {madhhab.scholar}
              </Text>
            </View>
          </View>
          <Text style={[styles.madhhabDescription, { color: theme.colors.text }]}>
            {madhhab.description}
          </Text>
          <View style={[styles.featuresContainer, { borderTopColor: theme.colors.borderLight }]}>
            <Text style={[styles.featuresLabel, { color: theme.colors.textTertiary }]}>
              المميزات:
            </Text>
            <Text style={[styles.featuresText, { color: theme.colors.textSecondary }]}>
              {madhhab.features.join(' • ')}
            </Text>
          </View>
        </View>
      ))}
    </View>
  );
  
  const renderContent = () => {
    switch (activeTab) {
      case 'shares':
        return renderSharesTable();
      case 'blocking':
        return renderBlockingRules();
      case 'special':
        return renderSpecialCases();
      case 'madhabs':
        return renderMadhhabs();
      default:
        return null;
    }
  };
  
  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      {/* شريط التبويبات */}
      <View style={[styles.tabsContainer, { backgroundColor: theme.colors.surface }]}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          {tabs.map(tab => (
            <TouchableOpacity
              key={tab.id}
              style={[
                styles.tab,
                activeTab === tab.id && [styles.activeTab, { borderBottomColor: theme.colors.primary }]
              ]}
              onPress={() => setActiveTab(tab.id)}
            >
              <Text style={styles.tabIcon}>{tab.icon}</Text>
              <Text style={[
                styles.tabText,
                { color: activeTab === tab.id ? theme.colors.primary : theme.colors.textSecondary }
              ]}>
                {tab.title}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>
      
      {/* المحتوى */}
      <ScrollView 
        style={styles.content}
        showsVerticalScrollIndicator={false}
      >
        {renderContent()}
        <View style={styles.bottomSpace} />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  tabsContainer: {
    paddingVertical: 8,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  tab: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    alignItems: 'center',
    marginHorizontal: 4,
  },
  activeTab: {
    borderBottomWidth: 2,
  },
  tabIcon: {
    fontSize: 20,
    marginBottom: 4,
  },
  tabText: {
    fontSize: 13,
    fontWeight: '600',
  },
  content: {
    flex: 1,
    padding: 16,
  },
  tableCard: {
    borderRadius: 20,
    padding: 16,
    elevation: 4,
  },
  tableTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 16,
    textAlign: 'center',
  },
  table: {
    marginTop: 8,
  },
  tableHeader: {
    flexDirection: 'row-reverse',
    paddingVertical: 10,
    borderBottomWidth: 2,
  },
  headerCell: {
    flex: 1,
    fontSize: 12,
    fontWeight: '700',
    textAlign: 'center',
  },
  headerCellLarge: {
    flex: 2,
    fontSize: 12,
    fontWeight: '700',
    textAlign: 'center',
  },
  tableRow: {
    flexDirection: 'row-reverse',
    paddingVertical: 12,
    borderBottomWidth: 1,
  },
  shareCell: {
    flex: 1,
    alignItems: 'center',
  },
  shareText: {
    fontSize: 16,
    fontWeight: '700',
  },
  heirsCell: {
    flex: 2,
    paddingHorizontal: 8,
  },
  heirsText: {
    fontSize: 13,
    lineHeight: 20,
    textAlign: 'right',
  },
  cell: {
    flex: 1,
    alignItems: 'center',
  },
  cellText: {
    fontSize: 13,
    fontWeight: '600',
  },
  caseCard: {
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
  },
  caseHeader: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    marginBottom: 10,
  },
  caseIcon: {
    fontSize: 24,
    marginLeft: 10,
  },
  caseName: {
    fontSize: 17,
    fontWeight: '700',
  },
  caseDescription: {
    fontSize: 14,
    lineHeight: 22,
    textAlign: 'right',
    marginBottom: 12,
  },
  madhabsContainer: {
    flexDirection: 'row-reverse',
    paddingTop: 12,
    borderTopWidth: 1,
  },
  madhabsLabel: {
    fontSize: 12,
    marginLeft: 8,
  },
  madhabsText: {
    fontSize: 12,
    flex: 1,
    textAlign: 'right',
  },
  madhhabCard: {
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    elevation: 2,
  },
  madhhabHeader: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    marginBottom: 12,
  },
  madhhabIconContainer: {
    width: 50,
    height: 50,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 12,
  },
  madhhabIcon: {
    fontSize: 24,
  },
  madhhabInfo: {
    flex: 1,
  },
  madhhabName: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 2,
  },
  madhhabScholar: {
    fontSize: 13,
  },
  madhhabDescription: {
    fontSize: 14,
    lineHeight: 22,
    textAlign: 'right',
    marginBottom: 12,
  },
  featuresContainer: {
    flexDirection: 'row-reverse',
    paddingTop: 12,
    borderTopWidth: 1,
  },
  featuresLabel: {
    fontSize: 12,
    marginLeft: 8,
  },
  featuresText: {
    fontSize: 12,
    flex: 1,
    textAlign: 'right',
  },
  bottomSpace: {
    height: 40,
  },
});

export default RulesScreen;
