/**
 * @fileoverview شاشة الاختبارات
 * @module screens/TestsScreen
 */

import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { useTheme } from '../contexts';
import { TestSuite, MADHABS_LIST } from '../core';

const TestsScreen = () => {
  const { theme } = useTheme();
  const [selectedMadhhab, setSelectedMadhhab] = useState('shafii');
  const [testResults, setTestResults] = useState(null);
  const [loading, setLoading] = useState(false);
  const [expandedTests, setExpandedTests] = useState({});
  
  const runAllTests = () => {
    setLoading(true);
    
    setTimeout(() => {
      const testSuite = new TestSuite();
      const results = testSuite.runAllTests(selectedMadhhab);
      setTestResults(results);
      setLoading(false);
    }, 100);
  };
  
  const toggleTestExpand = (testId) => {
    setExpandedTests(prev => ({
      ...prev,
      [testId]: !prev[testId]
    }));
  };
  
  const getStatusColor = (success) => {
    return success ? theme.colors.success : theme.colors.error;
  };
  
  const getStatusText = (success) => {
    return success ? '✓ ناجح' : '✗ فاشل';
  };
  
  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* اختيار المذهب */}
        <View style={styles.madhhabContainer}>
          <Text style={[styles.sectionTitle, { color: theme.colors.text }]}>
            اختر المذهب للاختبار:
          </Text>
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.madhhabScroll}
          >
            {MADHABS_LIST.map((madhhab) => (
              <TouchableOpacity
                key={madhhab.id}
                style={[
                  styles.madhhabButton,
                  { 
                    backgroundColor: selectedMadhhab === madhhab.id 
                      ? madhhab.color 
                      : theme.colors.surface,
                    borderColor: madhhab.color
                  }
                ]}
                onPress={() => setSelectedMadhhab(madhhab.id)}
              >
                <Text style={[
                  styles.madhhabButtonText,
                  { color: selectedMadhhab === madhhab.id ? '#fff' : madhhab.color }
                ]}>
                  {madhhab.icon} {madhhab.name}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
        
        {/* زر تشغيل الاختبارات */}
        <TouchableOpacity
          style={[
            styles.runButton,
            { backgroundColor: theme.colors.primary },
            loading && styles.disabledButton
          ]}
          onPress={runAllTests}
          disabled={loading}
        >
          {loading ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.runButtonText}>تشغيل جميع الاختبارات</Text>
          )}
        </TouchableOpacity>
        
        {/* ملخص النتائج */}
        {testResults && (
          <View style={[styles.summaryCard, { backgroundColor: theme.colors.surface }]}>
            <Text style={[styles.summaryTitle, { color: theme.colors.text }]}>
              ملخص النتائج
            </Text>
            
            <View style={styles.statsRow}>
              <View style={[styles.statBox, { backgroundColor: theme.colors.surfaceVariant }]}>
                <Text style={[styles.statValue, { color: theme.colors.text }]}>
                  {testResults.total}
                </Text>
                <Text style={[styles.statLabel, { color: theme.colors.textSecondary }]}>
                  إجمالي
                </Text>
              </View>
              
              <View style={[styles.statBox, { backgroundColor: theme.colors.success + '20' }]}>
                <Text style={[styles.statValue, { color: theme.colors.success }]}>
                  {testResults.passed}
                </Text>
                <Text style={[styles.statLabel, { color: theme.colors.success }]}>
                  ناجح
                </Text>
              </View>
              
              <View style={[styles.statBox, { backgroundColor: theme.colors.error + '20' }]}>
                <Text style={[styles.statValue, { color: theme.colors.error }]}>
                  {testResults.failed}
                </Text>
                <Text style={[styles.statLabel, { color: theme.colors.error }]}>
                  فاشل
                </Text>
              </View>
            </View>
            
            <View style={[styles.passRateContainer, { borderTopColor: theme.colors.border }]}>
              <Text style={[styles.passRateLabel, { color: theme.colors.textSecondary }]}>
                نسبة النجاح:
              </Text>
              <Text style={[
                styles.passRateValue,
                { 
                  color: parseFloat(testResults.passRate) >= 90 
                    ? theme.colors.success 
                    : parseFloat(testResults.passRate) >= 70 
                      ? theme.colors.warning 
                      : theme.colors.error 
                }
              ]}>
                {testResults.passRate}
              </Text>
            </View>
          </View>
        )}
        
        {/* قائمة الاختبارات */}
        {testResults && (
          <View style={styles.testsContainer}>
            <Text style={[styles.testsTitle, { color: theme.colors.text }]}>
              تفاصيل الاختبارات:
            </Text>
            
            {testResults.results.map((test, index) => (
              <TouchableOpacity
                key={test.id}
                style={[styles.testCard, { backgroundColor: theme.colors.surface }]}
                onPress={() => toggleTestExpand(test.id)}
                activeOpacity={0.7}
              >
                <View style={styles.testHeader}>
                  <View style={styles.testInfo}>
                    <Text style={[styles.testNumber, { color: theme.colors.textTertiary }]}>
                      #{index + 1}
                    </Text>
                    <Text style={[styles.testName, { color: theme.colors.text }]}>
                      {test.name}
                    </Text>
                  </View>
                  
                  <View style={[
                    styles.statusBadge,
                    { backgroundColor: getStatusColor(test.success) }
                  ]}>
                    <Text style={styles.statusText}>
                      {getStatusText(test.success)}
                    </Text>
                  </View>
                </View>
                
                {expandedTests[test.id] && !test.success && (
                  <View style={[styles.testDetails, { 
                    backgroundColor: theme.colors.surfaceVariant,
                    borderTopColor: theme.colors.border 
                  }]}>
                    {test.failures && test.failures.map((failure, fIndex) => (
                      <Text 
                        key={fIndex} 
                        style={[styles.failureText, { color: theme.colors.error }]}
                      >
                        ⚠️ {failure}
                      </Text>
                    ))}
                    {test.error && (
                      <Text style={[styles.errorText, { color: theme.colors.error }]}>
                        ❌ {test.error}
                      </Text>
                    )}
                  </View>
                )}
              </TouchableOpacity>
            ))}
          </View>
        )}
        
        <View style={styles.bottomSpace} />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  madhhabContainer: {
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 12,
    textAlign: 'right',
  },
  madhhabScroll: {
    gap: 8,
  },
  madhhabButton: {
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 12,
    borderWidth: 1.5,
  },
  madhhabButtonText: {
    fontSize: 14,
    fontWeight: '600',
  },
  runButton: {
    paddingVertical: 16,
    borderRadius: 14,
    alignItems: 'center',
    marginBottom: 20,
    elevation: 4,
  },
  disabledButton: {
    opacity: 0.6,
  },
  runButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
  summaryCard: {
    borderRadius: 20,
    padding: 20,
    marginBottom: 20,
    elevation: 4,
  },
  summaryTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 16,
    textAlign: 'center',
  },
  statsRow: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  statBox: {
    alignItems: 'center',
    padding: 16,
    borderRadius: 12,
    minWidth: 80,
  },
  statValue: {
    fontSize: 28,
    fontWeight: '800',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 13,
    fontWeight: '600',
  },
  passRateContainer: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 16,
    borderTopWidth: 1,
  },
  passRateLabel: {
    fontSize: 15,
    fontWeight: '600',
  },
  passRateValue: {
    fontSize: 24,
    fontWeight: '800',
  },
  testsContainer: {
    marginBottom: 16,
  },
  testsTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 12,
    textAlign: 'right',
  },
  testCard: {
    borderRadius: 12,
    marginBottom: 8,
    overflow: 'hidden',
    elevation: 2,
  },
  testHeader: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 14,
  },
  testInfo: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    flex: 1,
  },
  testNumber: {
    fontSize: 12,
    marginLeft: 8,
  },
  testName: {
    fontSize: 14,
    fontWeight: '600',
    flex: 1,
    textAlign: 'right',
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderRadius: 12,
    minWidth: 60,
    alignItems: 'center',
  },
  statusText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '700',
  },
  testDetails: {
    padding: 14,
    borderTopWidth: 1,
  },
  failureText: {
    fontSize: 13,
    marginBottom: 6,
    textAlign: 'right',
  },
  errorText: {
    fontSize: 13,
    textAlign: 'right',
  },
  bottomSpace: {
    height: 40,
  },
});

export default TestsScreen;
