/**
 * @fileoverview سياق إدارة السمة والألوان
 * @module contexts/ThemeContext
 */

import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useColorScheme } from 'react-native';

// الألوان الأساسية للتطبيق
export const COLORS = {
  primary: {
    main: '#4f46e5',
    light: '#818cf8',
    dark: '#3730a3',
    gradient: ['#4f46e5', '#7c3aed']
  },
  secondary: {
    main: '#06b6d4',
    light: '#67e8f9',
    dark: '#0891b2'
  },
  success: '#10b981',
  warning: '#f59e0b',
  error: '#ef4444',
  info: '#3b82f6',
  
  // ألوان المذاهب
  madhabs: {
    shafii: { main: '#059669', light: '#ecfdf5', gradient: ['#059669', '#047857'] },
    hanafi: { main: '#dc2626', light: '#fef2f2', gradient: ['#dc2626', '#b91c1c'] },
    maliki: { main: '#7c3aed', light: '#faf5ff', gradient: ['#7c3aed', '#6d28d9'] },
    hanbali: { main: '#0284c7', light: '#eff6ff', gradient: ['#0284c7', '#0369a1'] }
  },
  
  // ألوان الورثة
  heirs: {
    husband: '#8b5cf6',
    wife: '#ec4899',
    father: '#3b82f6',
    mother: '#06b6d4',
    grandfather: '#6366f1',
    grandmother: '#a855f7',
    son: '#10b981',
    daughter: '#f59e0b',
    grandson: '#14b8a6',
    granddaughter: '#f97316',
    full_brother: '#ef4444',
    full_sister: '#f43f5e',
    paternal_brother: '#dc2626',
    paternal_sister: '#e11d48',
    maternal_brother: '#b91c1c',
    maternal_sister: '#be123c'
  }
};

// السمة الفاتحة
const lightTheme = {
  mode: 'light',
  colors: {
    background: '#f8fafc',
    surface: '#ffffff',
    surfaceVariant: '#f1f5f9',
    primary: COLORS.primary.main,
    primaryLight: COLORS.primary.light,
    primaryDark: COLORS.primary.dark,
    secondary: COLORS.secondary.main,
    text: '#1e293b',
    textSecondary: '#64748b',
    textTertiary: '#94a3b8',
    border: '#e2e8f0',
    borderLight: '#f1f5f9',
    error: COLORS.error,
    warning: COLORS.warning,
    success: COLORS.success,
    info: COLORS.info,
    disabled: '#cbd5e1',
    overlay: 'rgba(0, 0, 0, 0.5)',
    shadow: '#000000'
  }
};

// السمة المظلمة
const darkTheme = {
  mode: 'dark',
  colors: {
    background: '#0f172a',
    surface: '#1e293b',
    surfaceVariant: '#334155',
    primary: COLORS.primary.light,
    primaryLight: '#a5b4fc',
    primaryDark: COLORS.primary.main,
    secondary: COLORS.secondary.light,
    text: '#f8fafc',
    textSecondary: '#94a3b8',
    textTertiary: '#64748b',
    border: '#334155',
    borderLight: '#475569',
    error: '#f87171',
    warning: '#fbbf24',
    success: '#34d399',
    info: '#60a5fa',
    disabled: '#475569',
    overlay: 'rgba(0, 0, 0, 0.7)',
    shadow: '#000000'
  }
};

// إنشاء السياق
const ThemeContext = createContext({
  theme: lightTheme,
  isDark: false,
  toggleTheme: () => {},
  setTheme: () => {},
  colors: COLORS
});

// موفر السياق
export const ThemeProvider = ({ children }) => {
  const systemColorScheme = useColorScheme();
  const [themeMode, setThemeMode] = useState('system');
  const [isDark, setIsDark] = useState(systemColorScheme === 'dark');
  
  // تحميل الإعدادات المحفوظة
  useEffect(() => {
    loadThemeSettings();
  }, []);
  
  // تحديث عند تغيير نظام الألوان
  useEffect(() => {
    if (themeMode === 'system') {
      setIsDark(systemColorScheme === 'dark');
    }
  }, [systemColorScheme, themeMode]);
  
  const loadThemeSettings = async () => {
    try {
      const savedMode = await AsyncStorage.getItem('@theme_mode');
      if (savedMode) {
        setThemeMode(savedMode);
        if (savedMode !== 'system') {
          setIsDark(savedMode === 'dark');
        }
      }
    } catch (error) {
      console.error('Error loading theme settings:', error);
    }
  };
  
  const saveThemeSettings = async (mode) => {
    try {
      await AsyncStorage.setItem('@theme_mode', mode);
    } catch (error) {
      console.error('Error saving theme settings:', error);
    }
  };
  
  const toggleTheme = () => {
    const newIsDark = !isDark;
    setIsDark(newIsDark);
    setThemeMode(newIsDark ? 'dark' : 'light');
    saveThemeSettings(newIsDark ? 'dark' : 'light');
  };
  
  const setTheme = (mode) => {
    setThemeMode(mode);
    if (mode === 'system') {
      setIsDark(systemColorScheme === 'dark');
    } else {
      setIsDark(mode === 'dark');
    }
    saveThemeSettings(mode);
  };
  
  const theme = isDark ? darkTheme : lightTheme;
  
  const value = {
    theme,
    isDark,
    themeMode,
    toggleTheme,
    setTheme,
    colors: COLORS
  };
  
  return (
    <ThemeContext.Provider value={value}>
      {children}
    </ThemeContext.Provider>
  );
};

// Hook لاستخدام السياق
export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};

export default ThemeContext;
