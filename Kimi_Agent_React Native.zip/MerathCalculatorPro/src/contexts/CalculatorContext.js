/**
 * @fileoverview سياق إدارة حالة الحاسبة
 * @module contexts/CalculatorContext
 */

import React, { createContext, useContext, useReducer, useCallback } from 'react';
import { InheritanceEngine, AuditLog } from '../core';

// الإجراءات
const ACTIONS = {
  SET_MADHHAB: 'SET_MADHHAB',
  ADD_HEIR: 'ADD_HEIR',
  REMOVE_HEIR: 'REMOVE_HEIR',
  CLEAR_HEIRS: 'CLEAR_HEIRS',
  SET_ESTATE: 'SET_ESTATE',
  CALCULATE: 'CALCULATE',
  CALCULATE_SUCCESS: 'CALCULATE_SUCCESS',
  CALCULATE_ERROR: 'CALCULATE_ERROR',
  CLEAR_RESULTS: 'CLEAR_RESULTS',
  SAVE_TO_HISTORY: 'SAVE_TO_HISTORY',
  LOAD_FROM_HISTORY: 'LOAD_FROM_HISTORY',
  SET_LOADING: 'SET_LOADING'
};

// الحالة الأولية
const initialState = {
  madhhab: 'shafii',
  heirs: {},
  estate: '',
  results: null,
  loading: false,
  error: null,
  history: [],
  lastCalculation: null
};

// Reducer
const calculatorReducer = (state, action) => {
  switch (action.type) {
    case ACTIONS.SET_MADHHAB:
      return {
        ...state,
        madhhab: action.payload,
        results: null
      };
      
    case ACTIONS.ADD_HEIR: {
      const { heirType, count = 1 } = action.payload;
      return {
        ...state,
        heirs: {
          ...state.heirs,
          [heirType]: (state.heirs[heirType] || 0) + count
        },
        results: null
      };
    }
    
    case ACTIONS.REMOVE_HEIR: {
      const { heirType, count = 1 } = action.payload;
      const newHeirs = { ...state.heirs };
      if (newHeirs[heirType] > count) {
        newHeirs[heirType] -= count;
      } else {
        delete newHeirs[heirType];
      }
      return {
        ...state,
        heirs: newHeirs,
        results: null
      };
    }
    
    case ACTIONS.CLEAR_HEIRS:
      return {
        ...state,
        heirs: {},
        results: null,
        error: null
      };
      
    case ACTIONS.SET_ESTATE:
      return {
        ...state,
        estate: action.payload
      };
      
    case ACTIONS.SET_LOADING:
      return {
        ...state,
        loading: action.payload
      };
      
    case ACTIONS.CALCULATE_SUCCESS:
      return {
        ...state,
        results: action.payload,
        loading: false,
        error: null,
        lastCalculation: new Date().toISOString()
      };
      
    case ACTIONS.CALCULATE_ERROR:
      return {
        ...state,
        results: null,
        loading: false,
        error: action.payload
      };
      
    case ACTIONS.CLEAR_RESULTS:
      return {
        ...state,
        results: null,
        error: null
      };
      
    case ACTIONS.SAVE_TO_HISTORY:
      return {
        ...state,
        history: [action.payload, ...state.history].slice(0, 50)
      };
      
    case ACTIONS.LOAD_FROM_HISTORY:
      return {
        ...state,
        heirs: action.payload.heirs,
        madhhab: action.payload.madhhab,
        estate: action.payload.estate || '',
        results: null
      };
      
    default:
      return state;
  }
};

// إنشاء السياق
const CalculatorContext = createContext({
  state: initialState,
  dispatch: () => {},
  setMadhhab: () => {},
  addHeir: () => {},
  removeHeir: () => {},
  clearHeirs: () => {},
  setEstate: () => {},
  calculate: () => {},
  clearResults: () => {},
  saveToHistory: () => {},
  loadFromHistory: () => {}
});

// موفر السياق
export const CalculatorProvider = ({ children }) => {
  const [state, dispatch] = useReducer(calculatorReducer, initialState);
  const auditLog = new AuditLog();
  
  const setMadhhab = useCallback((madhhab) => {
    dispatch({ type: ACTIONS.SET_MADHHAB, payload: madhhab });
  }, []);
  
  const addHeir = useCallback((heirType, count = 1) => {
    dispatch({ type: ACTIONS.ADD_HEIR, payload: { heirType, count } });
  }, []);
  
  const removeHeir = useCallback((heirType, count = 1) => {
    dispatch({ type: ACTIONS.REMOVE_HEIR, payload: { heirType, count } });
  }, []);
  
  const clearHeirs = useCallback(() => {
    dispatch({ type: ACTIONS.CLEAR_HEIRS });
  }, []);
  
  const setEstate = useCallback((estate) => {
    dispatch({ type: ACTIONS.SET_ESTATE, payload: estate });
  }, []);
  
  const calculate = useCallback(async () => {
    if (Object.keys(state.heirs).length === 0) {
      dispatch({ 
        type: ACTIONS.CALCULATE_ERROR, 
        payload: 'الرجاء إضافة ورثة أولاً' 
      });
      return;
    }
    
    dispatch({ type: ACTIONS.SET_LOADING, payload: true });
    
    try {
      const engine = new InheritanceEngine(state.madhhab);
      
      for (const [heirType, count] of Object.entries(state.heirs)) {
        engine.addHeir(heirType, count);
      }
      
      const result = engine.calculate();
      
      if (result.error) {
        dispatch({ 
          type: ACTIONS.CALCULATE_ERROR, 
          payload: result.errors.join(', ') 
        });
        return;
      }
      
      // حساب القيم المالية
      if (state.estate && parseFloat(state.estate) > 0) {
        const estateValue = parseFloat(state.estate);
        result.results = result.results.map((r) => ({
          ...r,
          amount: (r.share.num / r.share.den * estateValue).toFixed(2),
          amountFormatted: new Intl.NumberFormat('ar-SA', {
            style: 'currency',
            currency: 'SAR'
          }).format(r.share.num / r.share.den * estateValue)
        }));
      }
      
      dispatch({ type: ACTIONS.CALCULATE_SUCCESS, payload: result });
      
      // حفظ في السجل
      await auditLog.addCalculation({
        madhhab: state.madhhab,
        heirs: state.heirs,
        results: result.results,
        estateValue: state.estate,
        summary: engine.getSummary()
      });
      
    } catch (error) {
      dispatch({ 
        type: ACTIONS.CALCULATE_ERROR, 
        payload: error.message 
      });
    }
  }, [state.heirs, state.madhhab, state.estate]);
  
  const clearResults = useCallback(() => {
    dispatch({ type: ACTIONS.CLEAR_RESULTS });
  }, []);
  
  const saveToHistory = useCallback((calculation) => {
    dispatch({ 
      type: ACTIONS.SAVE_TO_HISTORY, 
      payload: {
        ...calculation,
        timestamp: new Date().toISOString(),
        id: Date.now().toString()
      }
    });
  }, []);
  
  const loadFromHistory = useCallback((calculation) => {
    dispatch({ 
      type: ACTIONS.LOAD_FROM_HISTORY, 
      payload: calculation 
    });
  }, []);
  
  const value = {
    state,
    dispatch,
    setMadhhab,
    addHeir,
    removeHeir,
    clearHeirs,
    setEstate,
    calculate,
    clearResults,
    saveToHistory,
    loadFromHistory
  };
  
  return (
    <CalculatorContext.Provider value={value}>
      {children}
    </CalculatorContext.Provider>
  );
};

// Hook لاستخدام السياق
export const useCalculator = () => {
  const context = useContext(CalculatorContext);
  if (!context) {
    throw new Error('useCalculator must be used within a CalculatorProvider');
  }
  return context;
};

export default CalculatorContext;
