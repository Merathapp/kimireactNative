/**
 * @fileoverview المحرك الحسابي المتقدم للمواريث
 * @module core/InheritanceEngine
 * @description المحرك الرئيسي لحساب المواريث مع دعم جميع الحالات الفقهية
 */

import { Fraction } from './Fraction';
import { FIQH_DATABASE, SPECIAL_CASES, BLOCKING_RULES, MESSAGES } from './FiqhDatabase';

/**
 * فئة المحرك الحسابي للمواريث
 * @class
 */
export class InheritanceEngine {
  /**
   * إنشاء محرك حسابي جديد
   * @param {string} madhhab - المذهب (shafii, hanafi, maliki, hanbali)
   */
  constructor(madhhab = 'shafii') {
    this.madhhab = madhhab;
    this.madhhabRules = FIQH_DATABASE.madhabs[madhhab]?.rules || FIQH_DATABASE.madhabs.shafii.rules;
    this.reset();
  }
  
  /**
   * إعادة تعيين المحرك
   */
  reset() {
    this.heirs = {};
    this.results = [];
    this.specialCase = null;
    this.specialCaseData = null;
    this.shares = {};
    this.totalShares = new Fraction(0);
    this.residue = new Fraction(0);
    this.base = 1;
    this.awlFactor = 1;
    this.raddFactor = 1;
    this.blockedHeirs = [];
    this.auditLog = [];
    this.validationErrors = [];
    this.warnings = [];
    this.calculationSteps = [];
  }
  
  /**
   * تسجيل عملية في سجل المراجعة
   * @private
   * @param {string} message - الرسالة
   * @param {Object} details - التفاصيل
   */
  log(message, details = {}) {
    this.auditLog.push({
      timestamp: new Date().toISOString(),
      message,
      details
    });
  }
  
  /**
   * إضافة خطوة حساب
   * @private
   * @param {string} step - الخطوة
   * @param {string} description - الوصف
   * @param {Object} data - البيانات
   */
  addCalculationStep(step, description, data = {}) {
    this.calculationSteps.push({
      step,
      description,
      data,
      timestamp: new Date().toISOString()
    });
  }
  
  /**
   * إضافة وارث
   * @param {string} type - نوع الورثة
   * @param {number} count - العدد
   * @returns {boolean} نجاح العملية
   */
  addHeir(type, count = 1) {
    if (count <= 0) {
      this.validationErrors.push(MESSAGES.errors.INVALID_COUNT);
      return false;
    }
    
    if (!FIQH_DATABASE.heirNames[type]) {
      this.validationErrors.push(`${MESSAGES.errors.INVALID_HEIR}: ${type}`);
      return false;
    }
    
    this.heirs[type] = (this.heirs[type] || 0) + count;
    this.log(`إضافة وارث: ${type} (${count})`);
    return true;
  }
  
  /**
   * إزالة وارث
   * @param {string} type - نوع الورثة
   * @param {number} count - العدد
   */
  removeHeir(type, count = 1) {
    if (this.heirs[type]) {
      this.heirs[type] = Math.max(0, this.heirs[type] - count);
      if (this.heirs[type] === 0) {
        delete this.heirs[type];
      }
      this.log(`إزالة وارث: ${type} (${count})`);
    }
  }
  
  /**
   * مسح جميع الورثة
   */
  clearHeirs() {
    this.heirs = {};
    this.log('مسح جميع الورثة');
  }
  
  /**
   * التحقق من وجود وارث
   * @param {string} type - نوع الورثة
   * @returns {boolean}
   */
  hasHeir(type) {
    return (this.heirs[type] || 0) > 0;
  }
  
  /**
   * الحصول على عدد الورثة من نوع معين
   * @param {string} type - نوع الورثة
   * @returns {number}
   */
  getHeirCount(type) {
    return this.heirs[type] || 0;
  }
  
  /**
   * التحقق من وجود فرع وارث
   * @returns {boolean}
   */
  hasBranchHeir() {
    return this.hasHeir('son') || this.hasHeir('daughter') || 
           this.hasHeir('grandson') || this.hasHeir('granddaughter');
  }
  
  /**
   * التحقق من وجود أبناء
   * @returns {boolean}
   */
  hasSons() {
    return this.hasHeir('son') || this.hasHeir('grandson');
  }
  
  /**
   * التحقق من وجود بنات
   * @returns {boolean}
   */
  hasDaughters() {
    return this.hasHeir('daughter') || this.hasHeir('granddaughter');
  }
  
  /**
   * التحقق من وجود أولاد
   * @returns {boolean}
   */
  hasChildren() {
    return this.hasSons() || this.hasDaughters();
  }
  
  /**
   * الحصول على العدد الإجمالي للبنات
   * @returns {number}
   */
  getTotalDaughters() {
    return (this.getHeirCount('daughter') || 0) + 
           (this.getHeirCount('granddaughter') || 0);
  }
  
  /**
   * التحقق من وجود أب
   * @returns {boolean}
   */
  hasFather() {
    return this.hasHeir('father') || this.hasHeir('grandfather');
  }
  
  /**
   * التحقق من وجود إخوة
   * @returns {boolean}
   */
  hasSiblings() {
    return this.hasHeir('full_brother') || this.hasHeir('full_sister') ||
           this.hasHeir('paternal_brother') || this.hasHeir('paternal_sister') ||
           this.hasHeir('maternal_brother') || this.hasHeir('maternal_sister');
  }
  
  /**
   * الحصول على العدد الإجمالي للإخوة لأم
   * @returns {number}
   */
  getMaternalSiblingsCount() {
    return this.getHeirCount('maternal_brother') + this.getHeirCount('maternal_sister');
  }
  
  /**
   * حساب الفرض الأساسي للوارث
   * @param {string} heirType - نوع الورثة
   * @returns {Fraction|Object} الفرض
   */
  calculateBasicShare(heirType) {
    const hasSons = this.hasSons();
    const hasDaughters = this.hasDaughters();
    const hasChildren = hasSons || hasDaughters;
    const hasBranchHeir = hasChildren || this.hasHeir('grandson') || this.hasHeir('granddaughter');
    const daughterCount = this.getHeirCount('daughter');
    const granddaughterCount = this.getHeirCount('granddaughter');
    
    switch (heirType) {
      // الزوجين
      case 'husband':
        return hasBranchHeir ? new Fraction(1, 4) : new Fraction(1, 2);
        
      case 'wife':
        return hasBranchHeir ? new Fraction(1, 8) : new Fraction(1, 4);
      
      // الآباء
      case 'father':
        if (hasChildren) return new Fraction(1, 6);
        if (this.hasSiblings()) {
          if (this.madhhab === 'maliki' || this.madhhab === 'hanbali') {
            return { type: 'residue', note: 'الباقي مع الإخوة (مقاسمة)' };
          }
          return new Fraction(1, 6);
        }
        return { type: 'residue', note: 'الباقي' };
        
      case 'mother':
        if (hasChildren || (this.getHeirCount('full_brother') + this.getHeirCount('full_sister') + 
            this.getHeirCount('paternal_brother') + this.getHeirCount('paternal_sister')) >= 2) {
          return new Fraction(1, 6);
        }
        return new Fraction(1, 3);
        
      case 'grandfather':
        if (hasChildren) return new Fraction(1, 6);
        if (this.hasSiblings()) {
          if (this.madhhab === 'maliki' || this.madhhab === 'hanbali') {
            return { type: 'residue', note: 'الباقي مع الإخوة (مقاسمة)' };
          }
          return new Fraction(1, 6);
        }
        return { type: 'residue', note: 'الباقي' };
        
      case 'grandmother':
      case 'grandmother_mother':
      case 'grandmother_father':
        return new Fraction(1, 6);
      
      // الأبناء
      case 'daughter':
        if (hasSons) return new Fraction(0);
        if (daughterCount === 1) return new Fraction(1, 2);
        return new Fraction(2, 3);
        
      case 'son':
        return { type: 'residue', note: 'الباقي للذكر مثل حظ الأنثيين' };
      
      // الأحفاد
      case 'granddaughter':
        if (hasSons) return new Fraction(0);
        if (this.hasHeir('daughter')) return new Fraction(0);
        if (granddaughterCount === 1) return new Fraction(1, 2);
        return new Fraction(2, 3);
        
      case 'grandson':
        if (hasSons) return new Fraction(0);
        return { type: 'residue', note: 'الباقي للذكر مثل حظ الأنثيين' };
      
      // الإخوة الأشقاء
      case 'full_sister':
        if (hasChildren || this.hasHeir('father') || this.hasHeir('grandfather')) return new Fraction(0);
        if (this.hasHeir('full_brother')) return new Fraction(0);
        const fsCount = this.getHeirCount('full_sister');
        if (fsCount === 1) return new Fraction(1, 2);
        return new Fraction(2, 3);
        
      case 'full_brother':
        if (hasChildren || this.hasHeir('father') || this.hasHeir('grandfather')) return new Fraction(0);
        return { type: 'residue', note: 'الباقي للذكر مثل حظ الأنثيين' };
      
      // الإخوة لأب
      case 'paternal_sister':
        if (hasChildren || this.hasHeir('father') || this.hasHeir('grandfather') || 
            this.hasHeir('full_brother') || this.getHeirCount('full_sister') >= 2) return new Fraction(0);
        if (this.hasHeir('paternal_brother')) return new Fraction(0);
        const psCount = this.getHeirCount('paternal_sister');
        if (psCount === 1) return new Fraction(1, 2);
        return new Fraction(2, 3);
        
      case 'paternal_brother':
        if (hasChildren || this.hasHeir('father') || this.hasHeir('grandfather') || 
            this.hasHeir('full_brother') || this.getHeirCount('full_sister') >= 2) return new Fraction(0);
        return { type: 'residue', note: 'الباقي للذكر مثل حظ الأنثيين' };
      
      // الإخوة لأم
      case 'maternal_sister':
      case 'maternal_brother':
        if (hasChildren || this.hasHeir('father') || this.hasHeir('grandfather')) return new Fraction(0);
        const msCount = this.getMaternalSiblingsCount();
        if (msCount === 1) return new Fraction(1, 6);
        return new Fraction(1, 3);
      
      default:
        return new Fraction(0);
    }
  }
  
  /**
   * تطبيق قواعد الحجب
   */
  applyBlockingRules() {
    this.blockedHeirs = [];
    const hasChildren = this.hasChildren();
    const hasFather = this.hasFather();
    
    // حجب الجد بالأب
    if (this.hasHeir('father') && this.hasHeir('grandfather')) {
      this.blockedHeirs.push({ 
        heir: 'grandfather', 
        blocker: 'father', 
        reason: 'الأب يحجب الجد',
        type: 'total'
      });
    }
    
    // حجب الجدات بالأم
    if (this.hasHeir('mother')) {
      if (this.hasHeir('grandmother_mother')) {
        this.blockedHeirs.push({ 
          heir: 'grandmother_mother', 
          blocker: 'mother', 
          reason: 'الأم تحجب الجدة لأم',
          type: 'total'
        });
      }
      if (this.hasHeir('grandmother_father')) {
        this.blockedHeirs.push({ 
          heir: 'grandmother_father', 
          blocker: 'mother', 
          reason: 'الأم تحجب الجدة لأب',
          type: 'total'
        });
      }
    }
    
    // حجب الأحفاد بالأبناء
    if (this.hasHeir('son')) {
      if (this.hasHeir('grandson')) {
        this.blockedHeirs.push({ 
          heir: 'grandson', 
          blocker: 'son', 
          reason: 'الابن يحجب ابن الابن',
          type: 'total'
        });
      }
      if (this.hasHeir('granddaughter')) {
        this.blockedHeirs.push({ 
          heir: 'granddaughter', 
          blocker: 'son', 
          reason: 'الابن يحجب بنت الابن',
          type: 'total'
        });
      }
    }
    
    // حجب بنات الابن بالبنات
    if (this.hasHeir('daughter') && this.hasHeir('granddaughter')) {
      this.blockedHeirs.push({ 
        heir: 'granddaughter', 
        blocker: 'daughter', 
        reason: 'البنت تحجب بنت الابن',
        type: 'total'
      });
    }
    
    // حجب الإخوة والأخوات بالأب أو الجد
    if (hasFather || this.hasHeir('grandfather')) {
      const siblings = ['full_brother', 'full_sister', 'paternal_brother', 'paternal_sister', 
                       'maternal_brother', 'maternal_sister'];
      siblings.forEach(sibling => {
        if (this.hasHeir(sibling)) {
          this.blockedHeirs.push({ 
            heir: sibling, 
            blocker: hasFather ? 'father' : 'grandfather', 
            reason: 'الأب/الجد يحجبان الإخوة',
            type: 'total'
          });
        }
      });
    }
    
    // حجب الأخوات لأب بالإخوة الأشقاء
    if (this.hasHeir('full_brother') || this.getHeirCount('full_sister') >= 2) {
      if (this.hasHeir('paternal_brother')) {
        this.blockedHeirs.push({ 
          heir: 'paternal_brother', 
          blocker: 'full_siblings', 
          reason: 'الإخوة الأشقاء يحجبون الإخوة لأب',
          type: 'total'
        });
      }
      if (this.hasHeir('paternal_sister')) {
        this.blockedHeirs.push({ 
          heir: 'paternal_sister', 
          blocker: 'full_siblings', 
          reason: 'الإخوة الأشقاء يحجبون الأخوات لأب',
          type: 'total'
        });
      }
    }
    
    // حجب الإخوة لأم بالأبناء
    if (hasChildren) {
      ['maternal_brother', 'maternal_sister'].forEach(sibling => {
        if (this.hasHeir(sibling)) {
          this.blockedHeirs.push({ 
            heir: sibling, 
            blocker: 'children', 
            reason: 'الأبناء يحجبون الإخوة لأم',
            type: 'total'
          });
        }
      });
    }
    
    this.log('تطبيق قواعد الحجب', { blocked: this.blockedHeirs.length });
    this.addCalculationStep('blocking', 'تطبيق قواعد الحجب', { 
      blockedCount: this.blockedHeirs.length,
      blocked: this.blockedHeirs 
    });
  }
  
  /**
   * التحقق من الحالات الخاصة
   */
  checkSpecialCases() {
    const hasHusband = this.hasHeir('husband');
    const hasWife = this.hasHeir('wife');
    const hasFather = this.hasHeir('father');
    const hasMother = this.hasHeir('mother');
    const hasGrandfather = this.hasHeir('grandfather');
    const hasGrandmother = this.hasHeir('grandmother') || this.hasHeir('grandmother_mother') || this.hasHeir('grandmother_father');
    const hasChildren = this.hasChildren();
    
    // العمرية
    if ((hasHusband || hasWife) && (hasFather || hasGrandfather) && (hasMother || hasGrandmother) && !hasChildren) {
      this.specialCase = 'umariyyah';
      this.specialCaseData = SPECIAL_CASES.umariyyah;
      this.log('تم اكتشاف حالة العمرية');
      this.addCalculationStep('special_case', 'اكتشاف حالة العمرية');
      return;
    }
    
    // المشتركة
    if (hasHusband && hasMother && this.getMaternalSiblingsCount() >= 2 && 
        (this.hasHeir('full_brother') || this.hasHeir('full_sister'))) {
      if (this.madhhabRules.musharrakaEnabled) {
        this.specialCase = 'musharraka';
        this.specialCaseData = SPECIAL_CASES.musharraka;
        this.log('تم اكتشاف حالة المشتركة');
        this.addCalculationStep('special_case', 'اكتشاف حالة المشتركة');
        return;
      }
    }
    
    // الأكدرية
    if (hasHusband && hasMother && (hasFather || hasGrandfather) && 
        (this.getHeirCount('full_sister') === 1) && !this.hasHeir('full_brother') && !hasChildren) {
      this.specialCase = 'akdariyya';
      this.specialCaseData = SPECIAL_CASES.akdariyya;
      this.log('تم اكتشاف حالة الأكدرية');
      this.addCalculationStep('special_case', 'اكتشاف حالة الأكدرية');
      return;
    }
    
    this.specialCase = null;
    this.specialCaseData = null;
  }
  
  /**
   * التحقق من صحة المسألة
   * @returns {Object} نتيجة التحقق
   */
  validate() {
    const errors = [];
    const warnings = [];
    
    // التحقق من وجود ورثة
    if (Object.keys(this.heirs).length === 0) {
      errors.push(MESSAGES.errors.NO_HEIRS);
    }
    
    // التحقق من وجود زوجين
    if (this.hasHeir('husband') && this.hasHeir('wife')) {
      errors.push('لا يمكن وجود زوج وزوجة في نفس الوقت');
    }
    
    // التحقق من وجود أب وجد
    if (this.hasHeir('father') && this.hasHeir('grandfather')) {
      warnings.push('الجد محجوب بالأب');
    }
    
    // التحقق من المسائل المعقدة
    const heirCount = Object.values(this.heirs).reduce((a, b) => a + b, 0);
    if (heirCount > 15) {
      warnings.push(MESSAGES.warnings.COMPLEX_CASE);
    }
    
    this.validationErrors = errors;
    this.warnings = warnings;
    
    return {
      valid: errors.length === 0,
      errors,
      warnings
    };
  }
  
  /**
   * الحساب الرئيسي
   * @returns {Object} نتائج الحساب
   */
  calculate() {
    this.log('بدء الحساب', { madhhab: this.madhhab, heirs: this.heirs });
    this.addCalculationStep('start', 'بدء الحساب', { 
      madhhab: this.madhhab, 
      heirs: { ...this.heirs } 
    });
    
    // التحقق من الصحة
    const validation = this.validate();
    if (!validation.valid) {
      return {
        error: true,
        errors: validation.errors,
        warnings: validation.warnings
      };
    }
    
    this.applyBlockingRules();
    this.checkSpecialCases();
    
    this.shares = {};
    let fixedShares = new Fraction(0);
    const residueHeirs = [];
    
    // حساب الفروض الثابتة
    for (const [heirType, count] of Object.entries(this.heirs)) {
      if (count === 0) continue;
      
      // التحقق من الحجب
      const isBlocked = this.blockedHeirs.some(b => b.heir === heirType);
      if (isBlocked) continue;
      
      const share = this.calculateBasicShare(heirType);
      
      if (share instanceof Fraction) {
        if (!share.isZero()) {
          this.shares[heirType] = { 
            type: 'fixed', 
            share: share.clone(), 
            count,
            originalShare: share.clone()
          };
          fixedShares = fixedShares.add(share);
        }
      } else if (share.type === 'residue') {
        residueHeirs.push({ type: heirType, count, note: share.note });
      }
    }
    
    this.totalShares = fixedShares;
    this.addCalculationStep('fixed_shares', 'حساب الفروض الثابتة', {
      fixedShares: fixedShares.toArabic(),
      shares: { ...this.shares }
    });
    
    // معالجة العول
    if (fixedShares.greaterThan(1)) {
      this.handleAwl(fixedShares);
      return this.getResults();
    }
    
    // حساب الباقي
    this.residue = new Fraction(1).subtract(fixedShares);
    
    // توزيع الباقي
    if (!this.residue.isZero() && residueHeirs.length > 0) {
      this.distributeResidue(residueHeirs);
    }
    
    // معالجة الرد
    if (this.residue.isPositive() && residueHeirs.length === 0) {
      this.handleRadd();
    }
    
    // معالجة الحالات الخاصة
    if (this.specialCase) {
      this.handleSpecialCase();
    }
    
    this.addCalculationStep('complete', 'اكتمال الحساب');
    return this.getResults();
  }
  
  /**
   * معالجة العول
   * @param {Fraction} fixedShares - مجموع الفروض الثابتة
   */
  handleAwl(fixedShares) {
    this.awlFactor = Math.ceil(fixedShares.toDecimal() * 6) / 6; // تقريب لأقرب قاسم
    if (this.awlFactor < fixedShares.toDecimal()) {
      this.awlFactor = Math.ceil(fixedShares.toDecimal());
    }
    this.base = this.awlFactor;
    
    for (const [heirType, data] of Object.entries(this.shares)) {
      if (data.type === 'fixed') {
        data.originalShare = data.share.clone();
        data.share = data.share.divide(this.awlFactor);
        data.isAwl = true;
      }
    }
    
    this.residue = new Fraction(0);
    this.log('تم تطبيق العول', { factor: this.awlFactor });
    this.addCalculationStep('awl', 'تطبيق العول', { 
      factor: this.awlFactor,
      originalTotal: fixedShares.toArabic()
    });
  }
  
  /**
   * توزيع الباقي
   * @param {Array} residueHeirs - ورثة الباقي
   */
  distributeResidue(residueHeirs) {
    let totalParts = 0;
    const parts = [];
    
    for (const heir of residueHeirs) {
      let part = 0;
      if (heir.type.includes('son') || heir.type.includes('brother') || 
          heir.type.includes('uncle') || heir.type.includes('nephew') ||
          heir.type.includes('cousin') || heir.type.includes('father') || 
          heir.type.includes('grandfather')) {
        part = heir.count * 2;
      } else if (heir.type.includes('daughter') || heir.type.includes('sister') || 
                 heir.type.includes('aunt') || heir.type.includes('mother') || 
                 heir.type.includes('grandmother')) {
        part = heir.count;
      }
      
      if (part > 0) {
        parts.push({ ...heir, part });
        totalParts += part;
      }
    }
    
    if (totalParts > 0) {
      for (const heir of parts) {
        const share = this.residue.multiply(heir.part).divide(totalParts);
        this.shares[heir.type] = { 
          type: 'residue', 
          share: share.clone(), 
          count: heir.count,
          note: heir.note,
          originalShare: share.clone()
        };
      }
    }
    
    this.residue = new Fraction(0);
    this.addCalculationStep('residue', 'توزيع الباقي', { 
      heirs: residueHeirs.map(h => h.type),
      totalParts 
    });
  }
  
  /**
   * معالجة الرد
   */
  handleRadd() {
    const fixedHeirs = Object.entries(this.shares).filter(([_, d]) => d.type === 'fixed');
    if (fixedHeirs.length === 0) return;
    
    const totalFixed = fixedHeirs.reduce((sum, [_, d]) => sum.add(d.share), new Fraction(0));
    const raddAmount = new Fraction(1).subtract(totalFixed);
    
    if (raddAmount.isZero() || raddAmount.isNegative()) return;
    
    // التحقق من الرد على الزوجين
    const spouseTypes = ['husband', 'wife'];
    const hasSpouse = spouseTypes.some(s => this.hasHeir(s));
    const raddToSpouse = this.madhhabRules.raddToSpouse;
    
    let eligibleForRadd = fixedHeirs.filter(([type, _]) => {
      if (spouseTypes.includes(type)) return raddToSpouse;
      return true;
    });
    
    if (eligibleForRadd.length === 0) return;
    
    const totalParts = eligibleForRadd.reduce((sum, [_, d]) => sum.add(d.share), new Fraction(0));
    
    for (const [heirType, data] of Object.entries(this.shares)) {
      if (data.type === 'fixed') {
        const isSpouse = spouseTypes.includes(heirType);
        if (!isSpouse || raddToSpouse) {
          const raddShare = raddAmount.multiply(data.share).divide(totalParts);
          data.originalShare = data.share.clone();
          data.share = data.share.add(raddShare);
          data.radd = raddShare.clone();
          data.isRadd = true;
        }
      }
    }
    
    this.residue = new Fraction(0);
    this.log('تم تطبيق الرد');
    this.addCalculationStep('radd', 'تطبيق الرد', { 
      amount: raddAmount.toArabic(),
      toSpouse: raddToSpouse 
    });
  }
  
  /**
   * معالجة الحالات الخاصة
   */
  handleSpecialCase() {
    switch (this.specialCase) {
      case 'umariyyah':
        this.handleUmariyyah();
        break;
      case 'musharraka':
        this.handleMusharraka();
        break;
      case 'akdariyya':
        this.handleAkdariyya();
        break;
    }
  }
  
  /**
   * معالجة العمرية
   */
  handleUmariyyah() {
    if (!this.shares['mother']) return;
    
    // الأم تأخذ ثلث الباقي بدلاً من الثلث
    let residue = new Fraction(1);
    for (const [type, data] of Object.entries(this.shares)) {
      if (type !== 'mother' && data.share) {
        residue = residue.subtract(data.share);
      }
    }
    
    if (residue.isPositive()) {
      const motherShare = residue.divide(3);
      this.shares['mother'].originalShare = this.shares['mother'].share.clone();
      this.shares['mother'].share = motherShare;
      this.shares['mother'].special = 'العمرية: ثلث الباقي';
      this.shares['mother'].isUmariyyah = true;
      this.addCalculationStep('umariyyah', 'تطبيق قواعد العمرية', {
        motherShare: motherShare.toArabic()
      });
    }
  }
  
  /**
   * معالجة المشتركة
   */
  handleMusharraka() {
    if (!this.madhhabRules.musharrakaEnabled) return;
    
    // تطبيق قواعد المشتركة حسب المذهب
    this.log('تم تطبيق قواعد المشتركة');
    this.addCalculationStep('musharraka', 'تطبيق قواعد المشتركة');
  }
  
  /**
   * معالجة الأكدرية
   */
  handleAkdariyya() {
    // تطبيق قواعد الأكدرية
    this.log('تم تطبيق قواعد الأكدرية');
    this.addCalculationStep('akdariyya', 'تطبيق قواعد الأكدرية');
  }
  
  /**
   * الحصول على النتائج
   * @returns {Object} النتائج الكاملة
   */
  getResults() {
    const results = [];
    let totalDistributed = new Fraction(0);
    
    for (const [heirType, data] of Object.entries(this.shares)) {
      if (data.share.isZero()) continue;
      
      const name = FIQH_DATABASE.heirNames[heirType] || heirType;
      const count = data.count || 1;
      
      const individualShare = data.share.divide(count);
      
      results.push({
        type: heirType,
        name,
        count,
        share: data.share.clone(),
        individualShare: individualShare.clone(),
        shareArabic: data.share.toArabic(),
        individualShareArabic: individualShare.toArabic(),
        sharePercent: (data.share.toDecimal() * 100).toFixed(2) + '%',
        individualSharePercent: (individualShare.toDecimal() * 100).toFixed(2) + '%',
        shareType: data.type,
        note: data.note || data.special || '',
        originalShare: data.originalShare ? data.originalShare.toArabic() : null,
        radd: data.radd ? data.radd.toArabic() : null,
        isAwl: data.isAwl || false,
        isRadd: data.isRadd || false,
        isSpecialCase: data.isUmariyyah || false
      });
      
      totalDistributed = totalDistributed.add(data.share);
    }
    
    // إضافة بيت المال إذا كان هناك باقي
    if (this.residue.isPositive()) {
      results.push({
        type: 'treasury',
        name: 'بيت المال',
        count: 1,
        share: this.residue.clone(),
        individualShare: this.residue.clone(),
        shareArabic: this.residue.toArabic(),
        individualShareArabic: this.residue.toArabic(),
        sharePercent: (this.residue.toDecimal() * 100).toFixed(2) + '%',
        individualSharePercent: (this.residue.toDecimal() * 100).toFixed(2) + '%',
        shareType: 'residue',
        note: 'الباقي لبيت المال'
      });
      totalDistributed = totalDistributed.add(this.residue);
    }
    
    // ترتيب النتائج حسب الأهمية
    const order = FIQH_DATABASE.displayOrder;
    results.sort((a, b) => order.indexOf(a.type) - order.indexOf(b.type));
    
    return {
      results,
      blocked: this.blockedHeirs,
      specialCase: this.specialCase,
      specialCaseInfo: this.specialCaseData,
      awlFactor: this.awlFactor > 1 ? this.awlFactor : null,
      totalShares: this.totalShares.toArabic(),
      totalDistributed: totalDistributed.toArabic(),
      isComplete: totalDistributed.equals(1) || this.awlFactor > 1,
      validation: {
        errors: this.validationErrors,
        warnings: this.warnings
      },
      calculationSteps: this.calculationSteps,
      auditLog: this.auditLog,
      madhhab: this.madhhab
    };
  }
  
  /**
   * الحصول على ملخص سريع
   * @returns {Object} ملخص النتائج
   */
  getSummary() {
    const results = this.getResults();
    return {
      heirsCount: results.results.length,
      blockedCount: results.blocked.length,
      hasSpecialCase: !!results.specialCase,
      specialCaseName: results.specialCaseInfo?.name || null,
      hasAwl: !!results.awlFactor,
      isValid: results.validation.errors.length === 0
    };
  }
}

export default InheritanceEngine;
