/**
 * @fileoverview مجموعة الاختبارات الشاملة
 * @module core/TestSuite
 * @description اختبارات للتحقق من صحة الحسابات الفقهية
 */

import { InheritanceEngine } from './InheritanceEngine';
import { Fraction } from './Fraction';
import { MADHABS_LIST } from './FiqhDatabase';

/**
 * مجموعة الاختبارات
 * @class
 */
export class TestSuite {
  constructor() {
    this.tests = [];
    this.results = [];
    this.setupTests();
  }
  
  /**
   * إعداد الاختبارات
   * @private
   */
  setupTests() {
    // اختبارات الأساسية
    this.addTest('test_basic_husband_only', 'زوج فقط', { husband: 1 }, { husband: '1/2' });
    this.addTest('test_basic_wife_only', 'زوجة فقط', { wife: 1 }, { wife: '1/4' });
    this.addTest('test_basic_father_only', 'أب فقط', { father: 1 }, { father: '1' });
    this.addTest('test_basic_mother_only', 'أم فقط', { mother: 1 }, { mother: '1/3' });
    this.addTest('test_basic_son_only', 'ابن فقط', { son: 1 }, { son: '1' });
    this.addTest('test_basic_daughter_only', 'بنت فقط', { daughter: 1 }, { daughter: '1/2' });
    
    // اختبارات الزوجين مع الأبناء
    this.addTest('test_husband_with_son', 'زوج مع ابن', 
      { husband: 1, son: 1 }, 
      { husband: '1/4', son: '3/4' });
    this.addTest('test_wife_with_daughter', 'زوجة مع بنت', 
      { wife: 1, daughter: 1 }, 
      { wife: '1/8', daughter: '1/2' });
    this.addTest('test_husband_with_children', 'زوج مع أبناء', 
      { husband: 1, son: 1, daughter: 1 }, 
      { husband: '1/4', son: '4/6', daughter: '2/6' });
    
    // اختبارات الآباء
    this.addTest('test_father_with_children', 'أب مع أبناء', 
      { father: 1, son: 1 }, 
      { father: '1/6', son: '5/6' });
    this.addTest('test_mother_with_children', 'أم مع أبناء', 
      { mother: 1, son: 1 }, 
      { mother: '1/6', son: '5/6' });
    this.addTest('test_parents_with_children', 'أب وأم مع أبناء', 
      { father: 1, mother: 1, son: 1 }, 
      { father: '1/6', mother: '1/6', son: '4/6' });
    
    // اختبارات البنات
    this.addTest('test_two_daughters', 'بنتان', 
      { daughter: 2 }, 
      { daughter: '2/3' });
    this.addTest('test_daughters_with_son', 'بنات مع ابن', 
      { daughter: 2, son: 1 }, 
      { daughter: '2/3', son: '1/3' });
    
    // اختبارات العول
    this.addTest('test_awl_case_1', 'عول من 6 إلى 8', 
      { husband: 1, full_sister: 2, mother: 1 }, 
      { husband: '3/8', full_sister: '4/8', mother: '1/8' });
    this.addTest('test_awl_case_2', 'عول من 12 إلى 13', 
      { wife: 1, mother: 1, full_sister: 2 }, 
      { wife: '3/13', mother: '4/13', full_sister: '6/13' });
    
    // اختبارات الرد
    this.addTest('test_radd_mother_daughter', 'رد على الأم والبنت', 
      { mother: 1, daughter: 1 }, 
      { mother: '2/7', daughter: '5/7' });
    this.addTest('test_radd_wife_daughter', 'رد على الزوجة والبنت', 
      { wife: 1, daughter: 1 }, 
      { wife: '1/4', daughter: '3/4' });
    
    // اختبارات العمرية
    this.addTest('test_umariyyah_1', 'العمرية الأولى', 
      { husband: 1, father: 1, mother: 1 }, 
      { husband: '1/2', father: '1/3', mother: '1/6' });
    this.addTest('test_umariyyah_2', 'العمرية الثانية', 
      { wife: 1, father: 1, mother: 1 }, 
      { wife: '1/4', father: '1/2', mother: '1/4' });
    
    // اختبارات الإخوة
    this.addTest('test_full_siblings', 'إخوة أشقاء', 
      { full_brother: 1, full_sister: 1 }, 
      { full_brother: '2/3', full_sister: '1/3' });
    this.addTest('test_maternal_siblings', 'إخوة لأم', 
      { maternal_brother: 1, maternal_sister: 1 }, 
      { maternal_brother: '1/3', maternal_sister: '1/3' });
    
    // اختبارات الحجب
    this.addTest('test_blocking_grandfather', 'حجب الجد بالأب', 
      { father: 1, grandfather: 1 }, 
      { father: '1' }, 
      { blocked: ['grandfather'] });
    this.addTest('test_blocking_grandson', 'حجب حفيد بالابن', 
      { son: 1, grandson: 1 }, 
      { son: '1' }, 
      { blocked: ['grandson'] });
    
    // اختبارات معقدة
    this.addTest('test_complex_1', 'مسألة معقدة 1', 
      { husband: 1, mother: 1, father: 1, daughter: 1 }, 
      { husband: '3/13', mother: '2/13', father: '4/13', daughter: '4/13' });
    this.addTest('test_complex_2', 'مسألة معقدة 2', 
      { wife: 1, mother: 1, full_sister: 1, paternal_brother: 1 }, 
      { wife: '1/4', mother: '1/6', full_sister: '7/12' });
    
    // اختبارات الأجداد
    this.addTest('test_grandmother', 'جدة فقط', 
      { grandmother: 1 }, 
      { grandmother: '1/6' });
    this.addTest('test_grandmother_with_mother', 'جدة مع أم', 
      { mother: 1, grandmother: 1 }, 
      { mother: '1/3' }, 
      { blocked: ['grandmother'] });
    
    // اختبارات الأحفاد
    this.addTest('test_granddaughter', 'حفيدة فقط', 
      { granddaughter: 1 }, 
      { granddaughter: '1/2' });
    this.addTest('test_granddaughter_with_daughter', 'حفيدة مع بنت', 
      { daughter: 1, granddaughter: 1 }, 
      { daughter: '1/2' }, 
      { blocked: ['granddaughter'] });
    
    // اختبارات متعددة الزوجات
    this.addTest('test_multiple_wives', 'زوجات متعددات', 
      { wife: 4 }, 
      { wife: '1/4' });
    
    // اختبارات خاصة بالمذاهب
    this.addTest('test_hanafi_radd_spouse', 'رد الحنفي على الزوجين', 
      { wife: 1, daughter: 1 }, 
      { wife: '1/4', daughter: '3/4' }, 
      {}, 
      ['hanafi']);
    
    this.addTest('test_maliki_muqasama', 'مقاسمة المالكي', 
      { grandfather: 1, full_brother: 1 }, 
      { grandfather: '1/2', full_brother: '1/2' }, 
      {}, 
      ['maliki']);
  }
  
  /**
   * إضافة اختبار
   * @param {string} id - معرف الاختبار
   * @param {string} name - اسم الاختبار
   * @param {Object} heirs - الورثة
   * @param {Object} expected - النتيجة المتوقعة
   * @param {Object} options - الخيارات
   * @param {string[]} madhabs - المذاهب المطبقة
   */
  addTest(id, name, heirs, expected, options = {}, madhabs = null) {
    this.tests.push({
      id,
      name,
      heirs,
      expected,
      options,
      madhabs: madhabs || MADHABS_LIST.map(m => m.id)
    });
  }
  
  /**
   * تشغيل اختبار واحد
   * @param {Object} test - الاختبار
   * @param {string} madhhab - المذهب
   * @returns {Object} نتيجة الاختبار
   */
  runTest(test, madhhab = 'shafii') {
    try {
      const engine = new InheritanceEngine(madhhab);
      
      for (const [heirType, count] of Object.entries(test.heirs)) {
        engine.addHeir(heirType, count);
      }
      
      const result = engine.calculate();
      
      if (result.error) {
        return {
          id: test.id,
          name: test.name,
          success: false,
          error: result.errors.join(', '),
          heirs: test.heirs,
          expected: test.expected,
          actual: null,
          madhhab
        };
      }
      
      // التحقق من النتائج
      let success = true;
      const failures = [];
      
      for (const [heirType, expectedShare] of Object.entries(test.expected)) {
        const actualResult = result.results.find(r => r.type === heirType);
        
        if (!actualResult) {
          success = false;
          failures.push(`${heirType}: expected ${expectedShare}, got nothing`);
          continue;
        }
        
        // مقارنة الكسور
        const expectedFrac = this.parseShare(expectedShare);
        const actualFrac = actualResult.share;
        
        if (!this.compareFractions(expectedFrac, actualFrac)) {
          success = false;
          failures.push(`${heirType}: expected ${expectedShare}, got ${actualFrac.toArabic()}`);
        }
      }
      
      // التحقق من الحجب
      if (test.options.blocked) {
        for (const blockedHeir of test.options.blocked) {
          const isBlocked = result.blocked.some(b => b.heir === blockedHeir);
          if (!isBlocked) {
            success = false;
            failures.push(`${blockedHeir}: expected to be blocked`);
          }
        }
      }
      
      return {
        id: test.id,
        name: test.name,
        success,
        failures: failures.length > 0 ? failures : null,
        heirs: test.heirs,
        expected: test.expected,
        actual: result.results.reduce((acc, r) => {
          acc[r.type] = r.shareArabic;
          return acc;
        }, {}),
        madhhab
      };
      
    } catch (error) {
      return {
        id: test.id,
        name: test.name,
        success: false,
        error: error.message,
        heirs: test.heirs,
        expected: test.expected,
        actual: null,
        madhhab
      };
    }
  }
  
  /**
   * تحويل نص الكسر إلى كائن Fraction
   * @private
   * @param {string} share - نص الكسر
   * @returns {Fraction}
   */
  parseShare(share) {
    const parts = share.split('/');
    if (parts.length === 2) {
      return new Fraction(parseInt(parts[0]), parseInt(parts[1]));
    }
    return new Fraction(parseInt(share));
  }
  
  /**
   * مقارنة كسرين
   * @private
   * @param {Fraction} f1 - الكسر الأول
   * @param {Fraction} f2 - الكسر الثاني
   * @returns {boolean}
   */
  compareFractions(f1, f2) {
    const tolerance = 0.001;
    return Math.abs(f1.toDecimal() - f2.toDecimal()) < tolerance;
  }
  
  /**
   * تشغيل جميع الاختبارات
   * @param {string} madhhab - المذهب
   * @returns {Object} نتائج جميع الاختبارات
   */
  runAllTests(madhhab = 'shafii') {
    this.results = [];
    
    for (const test of this.tests) {
      if (test.madhabs.includes(madhhab)) {
        const result = this.runTest(test, madhhab);
        this.results.push(result);
      }
    }
    
    const passed = this.results.filter(r => r.success).length;
    const failed = this.results.filter(r => !r.success).length;
    const total = this.results.length;
    const passRate = total > 0 ? ((passed / total) * 100).toFixed(1) : '0.0';
    
    return {
      total,
      passed,
      failed,
      passRate: passRate + '%',
      results: this.results,
      madhhab,
      timestamp: new Date().toISOString()
    };
  }
  
  /**
   * تشغيل اختبارات جميع المذاهب
   * @returns {Object} نتائج الاختبارات لجميع المذاهب
   */
  runAllMadhhabTests() {
    const allResults = {};
    
    for (const madhhab of MADHABS_LIST) {
      allResults[madhhab.id] = this.runAllTests(madhhab.id);
    }
    
    return allResults;
  }
  
  /**
   * الحصول على ملخص الاختبارات
   * @returns {Object} ملخص الاختبارات
   */
  getSummary() {
    if (this.results.length === 0) {
      return { message: 'لم يتم تشغيل الاختبارات بعد' };
    }
    
    const passed = this.results.filter(r => r.success).length;
    const failed = this.results.filter(r => !r.success).length;
    
    return {
      total: this.results.length,
      passed,
      failed,
      passRate: ((passed / this.results.length) * 100).toFixed(1) + '%',
      failedTests: this.results.filter(r => !r.success).map(r => r.name)
    };
  }
}

export default TestSuite;
