/**
 * @fileoverview نقطة دخول وحدة المحرك الأساسي
 * @module core
 */

export { Fraction } from './Fraction';
export { InheritanceEngine } from './InheritanceEngine';
export { 
  FIQH_DATABASE, 
  MADHABS_LIST, 
  SPECIAL_CASES, 
  BLOCKING_RULES,
  MESSAGES 
} from './FiqhDatabase';
export { TestSuite } from './TestSuite';
export { AuditLog } from './AuditLog';

// إعادة التصدير الافتراضي
export { InheritanceEngine as default } from './InheritanceEngine';
