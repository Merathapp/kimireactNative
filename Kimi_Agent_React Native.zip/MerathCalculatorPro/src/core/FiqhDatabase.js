/**
 * @fileoverview قاعدة البيانات الفقهية الشاملة
 * @module core/FiqhDatabase
 * @description تحتوي على جميع البيانات الفقهية للمذاهب الأربعة والورثة والحالات الخاصة
 */

/**
 * قاعدة بيانات المذاهب والقواعد الفقهية
 * @constant
 */
export const FIQH_DATABASE = {
  /**
   * معلومات المذاهب الأربعة
   */
  madhabs: {
    shafii: {
      id: 'shafii',
      name: 'الشافعي',
      nameEn: 'Shafi\'i',
      icon: '🟢',
      color: '#059669',
      lightColor: '#ecfdf5',
      borderColor: '#a7f3d0',
      textColor: '#065f46',
      gradient: ['#059669', '#047857'],
      description: 'الرد على أصحاب الفروض عدا الزوجين. الجد يحجب الإخوة مطلقاً. المشتركة معتبرة.',
      scholar: 'الإمام محمد بن إدريس الشافعي',
      rules: {
        grandfatherWithSiblings: 'blocks',
        raddToSpouse: false,
        bloodRelativesEnabled: true,
        musharrakaEnabled: true,
        akdariyyaEnabled: true,
        umariyyahEnabled: true,
        muqasamaEnabled: false
      },
      features: ['المشتركة', 'العمرية', 'الأكدرية', 'ذوي الأرحام']
    },
    hanafi: {
      id: 'hanafi',
      name: 'الحنفي',
      nameEn: 'Hanafi',
      icon: '🔴',
      color: '#dc2626',
      lightColor: '#fef2f2',
      borderColor: '#fecaca',
      textColor: '#991b1b',
      gradient: ['#dc2626', '#b91c1c'],
      description: 'الرد على الزوجين عند عدم وجود غيرهم. الجد يحجب الإخوة. لا مشتركة.',
      scholar: 'الإمام أبو حنيفة النعمان',
      rules: {
        grandfatherWithSiblings: 'blocks',
        raddToSpouse: true,
        bloodRelativesEnabled: true,
        musharrakaEnabled: false,
        akdariyyaEnabled: true,
        umariyyahEnabled: true,
        muqasamaEnabled: false
      },
      features: ['الرد على الزوجين', 'العمرية', 'الأكدرية', 'ذوي الأرحام']
    },
    maliki: {
      id: 'maliki',
      name: 'المالكي',
      nameEn: 'Maliki',
      icon: '🟣',
      color: '#7c3aed',
      lightColor: '#faf5ff',
      borderColor: '#e9d5ff',
      textColor: '#6b21a8',
      gradient: ['#7c3aed', '#6d28d9'],
      description: 'الجد يُقاسم الإخوة. لا رد على الزوجين. الباقي لبيت المال. المشتركة معتبرة.',
      scholar: 'الإمام مالك بن أنس',
      rules: {
        grandfatherWithSiblings: 'shares',
        raddToSpouse: false,
        bloodRelativesEnabled: false,
        musharrakaEnabled: true,
        akdariyyaEnabled: true,
        umariyyahEnabled: true,
        muqasamaEnabled: true
      },
      features: ['المقاسمة', 'المشتركة', 'العمرية', 'الأكدرية']
    },
    hanbali: {
      id: 'hanbali',
      name: 'الحنبلي',
      nameEn: 'Hanbali',
      icon: '🔵',
      color: '#0284c7',
      lightColor: '#eff6ff',
      borderColor: '#bfdbfe',
      textColor: '#1e40af',
      gradient: ['#0284c7', '#0369a1'],
      description: 'الجد يُقاسم الإخوة. يُرد على الزوجين عند الحاجة. لا مشتركة.',
      scholar: 'الإمام أحمد بن حنبل',
      rules: {
        grandfatherWithSiblings: 'shares',
        raddToSpouse: true,
        bloodRelativesEnabled: true,
        musharrakaEnabled: false,
        akdariyyaEnabled: true,
        umariyyahEnabled: true,
        muqasamaEnabled: true
      },
      features: ['المقاسمة', 'الرد على الزوجين', 'العمرية', 'الأكدرية', 'ذوي الأرحام']
    }
  },

  /**
   * أسماء الورثة بالعربية
   */
  heirNames: {
    // الزوجين
    husband: 'الزوج',
    wife: 'الزوجة',
    wives: 'الزوجات',
    
    // الآباء
    father: 'الأب',
    mother: 'الأم',
    grandfather: 'الجد',
    grandmother: 'الجدة',
    grandmother_mother: 'الجدة لأم',
    grandmother_father: 'الجدة لأب',
    grandmothers: 'الجدات',
    great_grandfather: 'الجد لأب',
    great_grandmother: 'الجدة لأب لأب',
    
    // الأبناء
    son: 'الابن',
    sons: 'الأبناء',
    daughter: 'البنت',
    daughters: 'البنات',
    grandson: 'ابن الابن',
    grandsons: 'أبناء الابن',
    granddaughter: 'بنت الابن',
    granddaughters: 'بنات الابن',
    great_grandson: 'ابن ابن الابن',
    great_granddaughter: 'بنت ابن الابن',
    
    // الإخوة
    full_brother: 'الأخ الشقيق',
    full_brothers: 'الإخوة الأشقاء',
    full_sister: 'الأخت الشقيقة',
    full_sisters: 'الأخوات الشقيقات',
    paternal_brother: 'الأخ لأب',
    paternal_brothers: 'الإخوة لأب',
    paternal_sister: 'الأخت لأب',
    paternal_sisters: 'الأخوات لأب',
    maternal_brother: 'الأخ لأم',
    maternal_brother_plural: 'الإخوة لأم',
    maternal_sister: 'الأخت لأم',
    maternal_sister_plural: 'الأخوات لأم',
    maternal_siblings: 'الإخوة لأم',
    
    // الأبناء والبنات
    full_nephew: 'ابن الأخ الشقيق',
    full_nephews: 'أبناء الأخ الشقيق',
    paternal_nephew: 'ابن الأخ لأب',
    paternal_nephews: 'أبناء الأخ لأب',
    full_nephew_son: 'ابن ابن الأخ الشقيق',
    paternal_nephew_son: 'ابن ابن الأخ لأب',
    
    // الأعمام
    full_uncle: 'العم الشقيق',
    full_uncles: 'الأعمام الأشقاء',
    paternal_uncle: 'العم لأب',
    paternal_uncles: 'الأعمام لأب',
    full_cousin: 'ابن العم الشقيق',
    full_cousins: 'أبناء العم الشقيق',
    paternal_cousin: 'ابن العم لأب',
    paternal_cousins: 'أبناء العم لأب',
    
    // ذوي الأرحام
    daughter_son: 'ابن البنت',
    daughter_sons: 'أبناء البنت',
    daughter_daughter: 'بنت البنت',
    daughter_daughters: 'بنات البنت',
    sister_son: 'ابن الأخت',
    sister_sons: 'أبناء الأخت',
    sister_daughter: 'بنت الأخت',
    sister_daughters: 'بنات الأخت',
    maternal_uncle: 'الخال',
    maternal_uncles: 'الأخوال',
    maternal_aunt: 'الخالة',
    maternal_aunts: 'الخالات',
    paternal_aunt: 'العمة',
    paternal_aunts: 'العمات',
    
    // بيت المال
    treasury: 'بيت المال',
    muslim_community: 'المجتمع المسلم'
  },

  /**
   * معلومات الورثة
   */
  heirInfo: {
    husband: {
      fixed: true,
      shares: { withChildren: '1/4', withoutChildren: '1/2' },
      blockedBy: [],
      blocks: ['wife'],
      description: 'الزوج يستحق النصف إذا لم يكن هناك فرع وارث، والربع إذا وجد'
    },
    wife: {
      fixed: true,
      shares: { withChildren: '1/8', withoutChildren: '1/4' },
      blockedBy: ['husband'],
      blocks: [],
      description: 'الزوجة تستحق الربع إذا لم يكن هناك فرع وارث، والثمن إذا وجد'
    },
    father: {
      fixed: true,
      shares: { withChildren: '1/6', withoutChildren: 'residue' },
      blockedBy: [],
      blocks: ['grandfather', 'grandmother_father'],
      description: 'الأب يستحق السدس مع الفرع الوارث، والباقي بدونه'
    },
    mother: {
      fixed: true,
      shares: { 
        withChildrenOrSiblings: '1/6', 
        withoutChildrenOrSiblings: '1/3',
        umariyyah: '1/3 of residue'
      },
      blockedBy: [],
      blocks: ['grandmother_mother', 'grandmother_father'],
      description: 'الأم تستحق الثلث، أو السدس مع الفرع الوارث أو الإخوة'
    },
    son: {
      fixed: false,
      shares: { default: 'residue' },
      blockedBy: [],
      blocks: ['grandson', 'granddaughter', 'full_brother', 'full_sister', 
               'paternal_brother', 'paternal_sister', 'maternal_brother', 'maternal_sister'],
      description: 'الابن يأخذ الباقي للذكر مثل حظ الأنثيين'
    },
    daughter: {
      fixed: true,
      shares: { alone: '1/2', withSisters: '2/3', withSon: 'residue' },
      blockedBy: [],
      blocks: ['granddaughter'],
      description: 'البنت تستحق النصف، والبنتان فأكثر الثلثان'
    }
  },

  /**
   * الفروض الأساسية في المواريث
   */
  shares: {
    '1/2': { value: 0.5, arabic: 'النصف', symbol: '½' },
    '1/3': { value: 0.333333, arabic: 'الثلث', symbol: '⅓' },
    '2/3': { value: 0.666667, arabic: 'ثلثا', symbol: '⅔' },
    '1/4': { value: 0.25, arabic: 'الربع', symbol: '¼' },
    '3/4': { value: 0.75, arabic: 'ثلاثة أرباع', symbol: '¾' },
    '1/6': { value: 0.166667, arabic: 'السدس', symbol: '⅙' },
    '5/6': { value: 0.833333, arabic: 'خمسة أسداس', symbol: '⅚' },
    '1/8': { value: 0.125, arabic: 'الثمن', symbol: '⅛' },
    '3/8': { value: 0.375, arabic: 'ثلاثة أثمان', symbol: '⅜' },
    '5/8': { value: 0.625, arabic: 'خمسة أثمان', symbol: '⅝' },
    '7/8': { value: 0.875, arabic: 'سبعة أثمان', symbol: '⅞' },
    '1/12': { value: 0.083333, arabic: 'ثمن عشر', symbol: '¹⁄₁₂' },
    '1/24': { value: 0.041667, arabic: 'واحد من أربعة وعشرين', symbol: '¹⁄₂₄' }
  },

  /**
   * أصول المسائل
   */
  problemBases: [2, 3, 4, 6, 8, 12, 24],

  /**
   * ترتيب ذوي الأرحام حسب الصنف
   */
  bloodRelativesOrder: [
    { key: 'daughter_son', class: 1, name: 'ابن البنت', share: 'residue' },
    { key: 'daughter_daughter', class: 1, name: 'بنت البنت', share: 'residue' },
    { key: 'sister_son', class: 2, name: 'ابن الأخت', share: 'residue' },
    { key: 'sister_daughter', class: 2, name: 'بنت الأخت', share: 'residue' },
    { key: 'maternal_uncle', class: 3, name: 'الخال', share: 'residue' },
    { key: 'maternal_aunt', class: 3, name: 'الخالة', share: 'residue' },
    { key: 'paternal_aunt', class: 4, name: 'العمة', share: 'residue' },
    { key: 'paternal_uncle', class: 5, name: 'العم', share: 'residue' }
  ],

  /**
   * أولوية الورثة للرد
   */
  raddPriority: [
    'wife', 'husband', 'mother', 'father', 'daughter', 'son',
    'granddaughter', 'grandson', 'full_sister', 'full_brother',
    'paternal_sister', 'paternal_brother', 'maternal_sister', 'maternal_brother'
  ],

  /**
   * ترتيب الورثة للعرض
   */
  displayOrder: [
    'husband', 'wife', 
    'father', 'mother', 
    'grandfather', 'grandmother', 'grandmother_mother', 'grandmother_father',
    'son', 'daughter', 
    'grandson', 'granddaughter',
    'full_brother', 'full_sister', 
    'paternal_brother', 'paternal_sister',
    'maternal_brother', 'maternal_sister',
    'full_nephew', 'paternal_nephew',
    'full_uncle', 'paternal_uncle',
    'full_cousin', 'paternal_cousin',
    'treasury'
  ]
};

/**
 * قائمة المذاهب كمصفوفة
 * @constant
 */
export const MADHABS_LIST = Object.values(FIQH_DATABASE.madhabs);

/**
 * الحالات الخاصة في المواريث
 * @constant
 */
export const SPECIAL_CASES = {
  umariyyah: {
    id: 'umariyyah',
    name: 'العُمَريَّة',
    nameEn: 'Al-Umariyyah',
    description: 'زوج/زوجة + أب/جد + أم/جدة بدون فرع وارث. الأم تأخذ ثلث الباقي.',
    condition: 'spouse + (father OR grandfather) + (mother OR grandmother) AND NO children',
    formula: 'mother = 1/3 of residue',
    examples: [
      { 
        name: 'العُمَريَّة الأولى', 
        heirs: { husband: 1, father: 1, mother: 1 },
        result: { husband: '1/2', father: '1/3', mother: '1/6' }
      },
      { 
        name: 'العُمَريَّة الثانية', 
        heirs: { wife: 1, father: 1, mother: 1 },
        result: { wife: '1/4', father: '1/2', mother: '1/4' }
      }
    ],
    madhabs: ['shafii', 'hanafi', 'maliki', 'hanbali'],
    priority: 'high'
  },
  
  musharraka: {
    id: 'musharraka',
    name: 'المسألة المشتركة (الحمارية)',
    nameEn: 'Al-Musharraka',
    description: 'زوج + أم/جدة + إخوة لأم (2+) + إخوة أشقاء. الإخوة الأشقاء يشتركون مع الإخوة لأم.',
    condition: 'husband + mother + (maternal_siblings >= 2) + (full_brother OR full_sister)',
    formula: 'full_siblings share with maternal_siblings',
    examples: [
      { 
        name: 'المشتركة الكبرى', 
        heirs: { husband: 1, mother: 1, maternal_brother: 2, full_brother: 1 },
        result: { husband: '1/2', mother: '1/6', full_brother: '1/3', maternal_brother: 'excluded' }
      }
    ],
    madhabs: ['shafii', 'maliki'],
    priority: 'high'
  },
  
  akdariyya: {
    id: 'akdariyya',
    name: 'الأكدرية (الغرّاء)',
    nameEn: 'Al-Akdariyya',
    description: 'زوج + أم + جد + أخت شقيقة. تُجمع وتُقسم بطريقة خاصة.',
    condition: 'husband + mother + grandfather + (full_sister = 1) AND NO full_brother AND NO children',
    formula: 'special distribution with base 12',
    examples: [
      { 
        name: 'الأكدرية', 
        heirs: { husband: 1, mother: 1, grandfather: 1, full_sister: 1 },
        result: { husband: '3/12', mother: '2/12', grandfather: '4/12', full_sister: '3/12' }
      }
    ],
    madhabs: ['shafii', 'hanafi', 'maliki', 'hanbali'],
    priority: 'high'
  },
  
  awl: {
    id: 'awl',
    name: 'العَوْل',
    nameEn: 'Awl',
    description: 'عندما يزيد مجموع الفروض عن أصل المسألة. يتم زيادة المقام.',
    condition: 'sum of fixed shares > 1',
    formula: 'increase denominator to accommodate all shares',
    examples: [
      { 
        name: 'عول من 6 إلى 8', 
        heirs: { husband: 1, full_sister: 2, mother: 1 },
        result: { base: 6, awl: 8, husband: '3/8', full_sister: '4/8', mother: '1/8' }
      },
      { 
        name: 'عول من 12 إلى 13', 
        heirs: { wife: 1, mother: 1, full_sister: 2 },
        result: { base: 12, awl: 13, wife: '3/13', mother: '4/13', full_sister: '6/13' }
      }
    ],
    madhabs: ['shafii', 'hanafi', 'maliki', 'hanbali'],
    priority: 'critical'
  },
  
  radd: {
    id: 'radd',
    name: 'الرَّد',
    nameEn: 'Radd',
    description: 'توزيع الفائض على أصحاب الفروض بنسبة فروضهم عند عدم وجود عصبة.',
    condition: 'residue > 0 AND no residue heirs AND no blood relatives',
    formula: 'distribute residue proportionally to fixed shares',
    examples: [
      { 
        name: 'رد على الأم والبنت', 
        heirs: { mother: 1, daughter: 1 },
        result: { mother: '2/5', daughter: '3/5' }
      }
    ],
    madhabs: ['shafii', 'hanafi', 'maliki', 'hanbali'],
    priority: 'critical'
  },
  
  muqasama: {
    id: 'muqasama',
    name: 'المُقاسَمة',
    nameEn: 'Muqasama',
    description: 'الجد يُقاسم الإخوة الأشقاء والأخوات لأب.',
    condition: 'grandfather + siblings AND madhhab in [maliki, hanbali]',
    formula: 'grandfather shares with siblings as if he were a brother',
    examples: [
      { 
        name: 'مقاسمة الجد مع الأخوة', 
        heirs: { grandfather: 1, full_brother: 1, full_sister: 1 },
        result: { grandfather: '2/5', full_brother: '2/5', full_sister: '1/5' }
      }
    ],
    madhabs: ['maliki', 'hanbali'],
    priority: 'medium'
  },
  
  mushtarika: {
    id: 'mushtarika',
    name: 'المُشتَرِكة',
    nameEn: 'Al-Mushtarika',
    description: 'الجد يأخذ السدس مع الإخوة.',
    condition: 'grandfather + siblings AND madhhab in [shafii, hanafi]',
    formula: 'grandfather = 1/6, siblings share residue',
    examples: [
      { 
        name: 'المشتركة', 
        heirs: { grandfather: 1, full_brother: 1 },
        result: { grandfather: '1/6', full_brother: '5/6' }
      }
    ],
    madhabs: ['shafii', 'hanafi'],
    priority: 'medium'
  }
};

/**
 * قواعد الحجب في المواريث
 * @constant
 */
export const BLOCKING_RULES = {
  // حجب الجد بالأب
  grandfather_blocked_by_father: {
    heir: 'grandfather',
    blocker: 'father',
    reason: 'الأب يحجب الجد',
    type: 'total'
  },
  
  // حجب الجدة بالأم
  grandmother_blocked_by_mother: {
    heir: 'grandmother_mother',
    blocker: 'mother',
    reason: 'الأم تحجب الجدة لأم',
    type: 'total'
  },
  
  grandmother_father_blocked_by_mother: {
    heir: 'grandmother_father',
    blocker: 'mother',
    reason: 'الأم تحجب الجدة لأب',
    type: 'total'
  },
  
  // حجب الأحفاد بالأبناء
  grandson_blocked_by_son: {
    heir: 'grandson',
    blocker: 'son',
    reason: 'الابن يحجب ابن الابن',
    type: 'total'
  },
  
  granddaughter_blocked_by_son: {
    heir: 'granddaughter',
    blocker: 'son',
    reason: 'الابن يحجب بنت الابن',
    type: 'total'
  },
  
  granddaughter_blocked_by_daughter: {
    heir: 'granddaughter',
    blocker: 'daughter',
    reason: 'البنت تحجب بنت الابن',
    type: 'total'
  },
  
  // حجب الإخوة والأخوات
  siblings_blocked_by_father: {
    heirs: ['full_brother', 'full_sister', 'paternal_brother', 'paternal_sister', 
            'maternal_brother', 'maternal_sister'],
    blocker: 'father',
    reason: 'الأب يحجب الإخوة',
    type: 'total'
  },
  
  siblings_blocked_by_grandfather: {
    heirs: ['full_brother', 'full_sister', 'paternal_brother', 'paternal_sister', 
            'maternal_brother', 'maternal_sister'],
    blocker: 'grandfather',
    reason: 'الجد يحجب الإخوة',
    type: 'total'
  },
  
  // حجب الإخوة لأم بالأبناء
  maternal_siblings_blocked_by_children: {
    heirs: ['maternal_brother', 'maternal_sister'],
    blocker: ['son', 'daughter', 'grandson', 'granddaughter'],
    reason: 'الأبناء يحجبون الإخوة لأم',
    type: 'total'
  },
  
  // حجب الأخوات لأب بالإخوة الأشقاء
  paternal_siblings_blocked_by_full_siblings: {
    heirs: ['paternal_brother', 'paternal_sister'],
    blocker: ['full_brother', 'full_sister'],
    reason: 'الإخوة الأشقاء يحجبون الإخوة لأب',
    type: 'total'
  }
};

/**
 * رسائل الخطأ والتحذيرات
 * @constant
 */
export const MESSAGES = {
  errors: {
    INVALID_HEIR: 'نوع الورثة غير صالح',
    INVALID_COUNT: 'عدد الورثة يجب أن يكون أكبر من صفر',
    NO_HEIRS: 'لم يتم إضافة أي ورثة',
    INVALID_MADHHAB: 'المذهب غير معروف',
    CALCULATION_ERROR: 'حدث خطأ في الحساب',
    INVALID_ESTATE: 'قيمة التركة غير صالحة'
  },
  warnings: {
    NO_FIXED_SHARES: 'لا يوجد ورثة بفرض ثابت',
    ALL_BLOCKED: 'جميع الورثة محجوبون',
    COMPLEX_CASE: 'هذه مسألة معقدة، يرجى مراجعة عالم'
  },
  success: {
    CALCULATION_COMPLETE: 'تم الحساب بنجاح',
    SAVED: 'تم الحفظ بنجاح',
    EXPORTED: 'تم التصدير بنجاح'
  }
};

export default FIQH_DATABASE;
