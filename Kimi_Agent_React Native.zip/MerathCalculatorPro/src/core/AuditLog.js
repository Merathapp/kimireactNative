/**
 * @fileoverview نظام سجل المراجعة والتدقيق
 * @module core/AuditLog
 * @description تتبع وتوثيق جميع العمليات الحسابية
 */

import AsyncStorage from '@react-native-async-storage/async-storage';

/**
 * نظام سجل المراجعة
 * @class
 */
export class AuditLog {
  constructor() {
    this.logs = [];
    this.storageKey = '@merath_audit_logs';
    this.maxLogs = 1000;
    this.isLoaded = false;
  }
  
  /**
   * تحميل السجلات من التخزين
   * @returns {Promise<boolean>}
   */
  async load() {
    try {
      const stored = await AsyncStorage.getItem(this.storageKey);
      if (stored) {
        this.logs = JSON.parse(stored);
      }
      this.isLoaded = true;
      return true;
    } catch (error) {
      console.error('Error loading audit logs:', error);
      this.logs = [];
      this.isLoaded = true;
      return false;
    }
  }
  
  /**
   * حفظ السجلات في التخزين
   * @returns {Promise<boolean>}
   */
  async save() {
    try {
      // الاحتفاظ فقط بآخر maxLogs سجل
      if (this.logs.length > this.maxLogs) {
        this.logs = this.logs.slice(-this.maxLogs);
      }
      
      await AsyncStorage.setItem(this.storageKey, JSON.stringify(this.logs));
      return true;
    } catch (error) {
      console.error('Error saving audit logs:', error);
      return false;
    }
  }
  
  /**
   * إضافة سجل جديد
   * @param {string} type - نوع السجل
   * @param {Object} data - بيانات السجل
   * @returns {Promise<Object>}
   */
  async add(type, data = {}) {
    if (!this.isLoaded) {
      await this.load();
    }
    
    const log = {
      id: this.generateId(),
      timestamp: new Date().toISOString(),
      type,
      data,
      deviceInfo: await this.getDeviceInfo()
    };
    
    this.logs.unshift(log);
    await this.save();
    
    return log;
  }
  
  /**
   * إضافة سجل حساب
   * @param {Object} calculationData - بيانات الحساب
   * @returns {Promise<Object>}
   */
  async addCalculation(calculationData) {
    return this.add('calculation', {
      madhhab: calculationData.madhhab,
      heirs: calculationData.heirs,
      results: calculationData.results,
      estateValue: calculationData.estateValue,
      summary: calculationData.summary
    });
  }
  
  /**
   * إضافة سجل مقارنة
   * @param {Object} comparisonData - بيانات المقارنة
   * @returns {Promise<Object>}
   */
  async addComparison(comparisonData) {
    return this.add('comparison', {
      heirs: comparisonData.heirs,
      results: comparisonData.results,
      madhhabs: comparisonData.madhhabs
    });
  }
  
  /**
   * إضافة سجل اختبار
   * @param {Object} testData - بيانات الاختبار
   * @returns {Promise<Object>}
   */
  async addTestRun(testData) {
    return this.add('test_run', {
      madhhab: testData.madhhab,
      total: testData.total,
      passed: testData.passed,
      failed: testData.failed,
      passRate: testData.passRate
    });
  }
  
  /**
   * إضافة سجل تصدير
   * @param {Object} exportData - بيانات التصدير
   * @returns {Promise<Object>}
   */
  async addExport(exportData) {
    return this.add('export', {
      format: exportData.format,
      recordCount: exportData.recordCount,
      fileName: exportData.fileName
    });
  }
  
  /**
   * الحصول على جميع السجلات
   * @param {Object} filters - مرشحات البحث
   * @returns {Array}
   */
  getAll(filters = {}) {
    let filtered = [...this.logs];
    
    if (filters.type) {
      filtered = filtered.filter(log => log.type === filters.type);
    }
    
    if (filters.startDate) {
      filtered = filtered.filter(log => new Date(log.timestamp) >= filters.startDate);
    }
    
    if (filters.endDate) {
      filtered = filtered.filter(log => new Date(log.timestamp) <= filters.endDate);
    }
    
    if (filters.limit) {
      filtered = filtered.slice(0, filters.limit);
    }
    
    return filtered;
  }
  
  /**
   * الحصول على سجل واحد
   * @param {string} id - معرف السجل
   * @returns {Object|null}
   */
  getById(id) {
    return this.logs.find(log => log.id === id) || null;
  }
  
  /**
   * حذف سجل
   * @param {string} id - معرف السجل
   * @returns {Promise<boolean>}
   */
  async delete(id) {
    this.logs = this.logs.filter(log => log.id !== id);
    await this.save();
    return true;
  }
  
  /**
   * مسح جميع السجلات
   * @returns {Promise<boolean>}
   */
  async clear() {
    this.logs = [];
    await AsyncStorage.removeItem(this.storageKey);
    return true;
  }
  
  /**
   * الحصول على الإحصائيات
   * @returns {Object}
   */
  getStatistics() {
    const stats = {
      total: this.logs.length,
      byType: {},
      byMadhhab: {},
      byDate: {},
      lastCalculation: null,
      mostUsedMadhhab: null
    };
    
    for (const log of this.logs) {
      // حسب النوع
      stats.byType[log.type] = (stats.byType[log.type] || 0) + 1;
      
      // حسب المذهب
      if (log.data?.madhhab) {
        stats.byMadhhab[log.data.madhhab] = (stats.byMadhhab[log.data.madhhab] || 0) + 1;
      }
      
      // حسب التاريخ
      const date = log.timestamp.split('T')[0];
      stats.byDate[date] = (stats.byDate[date] || 0) + 1;
      
      // آخر حساب
      if (log.type === 'calculation' && !stats.lastCalculation) {
        stats.lastCalculation = log.timestamp;
      }
    }
    
    // أكثر مذهب استخداماً
    if (Object.keys(stats.byMadhhab).length > 0) {
      stats.mostUsedMadhhab = Object.entries(stats.byMadhhab)
        .sort((a, b) => b[1] - a[1])[0][0];
    }
    
    return stats;
  }
  
  /**
   * البحث في السجلات
   * @param {string} query - نص البحث
   * @returns {Array}
   */
  search(query) {
    const lowerQuery = query.toLowerCase();
    return this.logs.filter(log => {
      const searchable = JSON.stringify(log).toLowerCase();
      return searchable.includes(lowerQuery);
    });
  }
  
  /**
   * تصدير السجلات إلى JSON
   * @param {Object} filters - مرشحات التصدير
   * @returns {string}
   */
  exportToJSON(filters = {}) {
    const logs = this.getAll(filters);
    return JSON.stringify({
      exportDate: new Date().toISOString(),
      totalRecords: logs.length,
      logs
    }, null, 2);
  }
  
  /**
   * تصدير السجلات إلى CSV
   * @param {Object} filters - مرشحات التصدير
   * @returns {string}
   */
  exportToCSV(filters = {}) {
    const logs = this.getAll(filters);
    
    if (logs.length === 0) return '';
    
    const headers = ['ID', 'Timestamp', 'Type', 'Data'];
    const rows = logs.map(log => [
      log.id,
      log.timestamp,
      log.type,
      JSON.stringify(log.data)
    ]);
    
    return [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  }
  
  /**
   * استيراد السجلات
   * @param {string} json - نص JSON
   * @returns {Promise<boolean>}
   */
  async importFromJSON(json) {
    try {
      const data = JSON.parse(json);
      if (data.logs && Array.isArray(data.logs)) {
        this.logs = [...data.logs, ...this.logs];
        await this.save();
        return true;
      }
      return false;
    } catch (error) {
      console.error('Error importing logs:', error);
      return false;
    }
  }
  
  /**
   * توليد معرف فريد
   * @private
   * @returns {string}
   */
  generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
  }
  
  /**
   * الحصول على معلومات الجهاز
   * @private
   * @returns {Promise<Object>}
   */
  async getDeviceInfo() {
    try {
      const deviceInfo = {
        platform: 'unknown',
        version: 'unknown',
        brand: 'unknown',
        model: 'unknown'
      };
      
      // يمكن إضافة مكتبة expo-device هنا
      return deviceInfo;
    } catch (error) {
      return {};
    }
  }
}

export default AuditLog;
