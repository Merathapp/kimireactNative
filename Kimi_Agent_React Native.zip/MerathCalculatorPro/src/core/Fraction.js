/**
 * @fileoverview نظام الكسور المتقدم للمواريث
 * @module core/Fraction
 * @description فئة متكاملة للتعامل مع الكسور في حسابات المواريث
 */

/**
 * فئة الكسر - تمثل كسراً رياضياً مع عملياته
 * @class
 */
export class Fraction {
  /**
   * إنشاء كسر جديد
   * @param {number} numerator - البسط
   * @param {number} denominator - المقام (افتراضي: 1)
   */
  constructor(numerator, denominator = 1) {
    if (typeof numerator !== 'number' || typeof denominator !== 'number') {
      throw new Error('البسط والمقام يجب أن يكونا أرقاماً');
    }
    if (denominator === 0) {
      throw new Error('المقام لا يمكن أن يكون صفراً');
    }
    if (!Number.isFinite(numerator) || !Number.isFinite(denominator)) {
      throw new Error('القيم يجب أن تكون أرقاماً منتهية');
    }
    
    // التطبيع: جعل المقام دائماً موجباً
    const sign = denominator < 0 ? -1 : 1;
    numerator = Math.round(numerator * sign);
    denominator = Math.abs(Math.round(denominator));
    
    const g = Fraction.gcd(Math.abs(numerator), denominator);
    this.num = numerator / g;
    this.den = denominator / g;
    
    // حماية من التضخم
    if (Math.abs(this.num) > 1e12 || this.den > 1e12) {
      const decimal = this.num / this.den;
      this.num = Math.round(decimal * 1e9);
      this.den = 1e9;
      const g2 = Fraction.gcd(Math.abs(this.num), this.den);
      this.num /= g2;
      this.den /= g2;
    }
  }
  
  /**
   * حساب القاسم المشترك الأكبر (GCD)
   * @param {number} a - الرقم الأول
   * @param {number} b - الرقم الثاني
   * @returns {number} القاسم المشترك الأكبر
   */
  static gcd(a, b) {
    a = Math.abs(Math.round(a));
    b = Math.abs(Math.round(b));
    while (b > 0) {
      [a, b] = [b, a % b];
    }
    return a || 1;
  }
  
  /**
   * حساب المضاعف المشترك الأصغر (LCM)
   * @param {number} a - الرقم الأول
   * @param {number} b - الرقم الثاني
   * @returns {number} المضاعف المشترك الأصغر
   */
  static lcm(a, b) {
    a = Math.abs(Math.round(a));
    b = Math.abs(Math.round(b));
    if (a === 0 || b === 0) return 0;
    return (a * b) / Fraction.gcd(a, b);
  }
  
  /**
   * حساب المضاعف المشترك الأصغر لمجموعة أرقام
   * @param {number[]} arr - مصفوفة الأرقام
   * @returns {number} المضاعف المشترك الأصغر
   */
  static lcmArray(arr) {
    if (!arr || arr.length === 0) return 1;
    const filtered = arr.filter(n => n > 0);
    if (filtered.length === 0) return 1;
    return filtered.reduce((a, b) => Fraction.lcm(a, b), filtered[0]);
  }
  
  /**
   * إنشاء كسر من عدد عشري
   * @param {number} decimal - العدد العشري
   * @param {number} maxDenominator - الحد الأقصى للمقام
   * @returns {Fraction} الكسر الناتج
   */
  static fromDecimal(decimal, maxDenominator = 10000) {
    if (decimal === 0) return new Fraction(0);
    
    const sign = decimal < 0 ? -1 : 1;
    decimal = Math.abs(decimal);
    
    let bestNum = 1, bestDen = 1;
    let minError = Math.abs(decimal - 1);
    
    for (let den = 1; den <= maxDenominator; den++) {
      const num = Math.round(decimal * den);
      const error = Math.abs(decimal - num / den);
      if (error < minError) {
        minError = error;
        bestNum = num;
        bestDen = den;
        if (error < 1e-10) break;
      }
    }
    
    return new Fraction(sign * bestNum, bestDen);
  }
  
  /**
   * جمع كسرين
   * @param {Fraction|number} other - الكسر الآخر
   * @returns {Fraction} ناتج الجمع
   */
  add(other) {
    if (!(other instanceof Fraction)) other = new Fraction(other);
    return new Fraction(
      this.num * other.den + other.num * this.den,
      this.den * other.den
    );
  }
  
  /**
   * طرح كسر من آخر
   * @param {Fraction|number} other - الكسر الآخر
   * @returns {Fraction} ناتج الطرح
   */
  subtract(other) {
    if (!(other instanceof Fraction)) other = new Fraction(other);
    return new Fraction(
      this.num * other.den - other.num * this.den,
      this.den * other.den
    );
  }
  
  /**
   * ضرب كسرين
   * @param {Fraction|number} other - الكسر الآخر
   * @returns {Fraction} ناتج الضرب
   */
  multiply(other) {
    if (!(other instanceof Fraction)) other = new Fraction(other);
    return new Fraction(this.num * other.num, this.den * other.den);
  }
  
  /**
   * قسمة كسر على آخر
   * @param {Fraction|number} other - الكسر الآخر
   * @returns {Fraction} ناتج القسمة
   */
  divide(other) {
    if (!(other instanceof Fraction)) other = new Fraction(other);
    if (other.num === 0) throw new Error('القسمة على صفر');
    return new Fraction(this.num * other.den, this.den * other.num);
  }
  
  /**
   * تحويل الكسر إلى عدد عشري
   * @returns {number} العدد العشري
   */
  toDecimal() { 
    return this.num / this.den; 
  }
  
  /**
   * تحويل الكسر إلى نص
   * @returns {string} النص الممثل للكسر
   */
  toString() {
    if (this.num === 0) return '0';
    if (this.den === 1) return String(this.num);
    return `${this.num}/${this.den}`;
  }
  
  /**
   * تحويل الرقم إلى أرقام عربية
   * @private
   * @param {number} n - الرقم
   * @returns {string} الأرقام العربية
   */
  _toArabicNum(n) {
    return String(Math.abs(n)).replace(/\d/g, d => '٠١٢٣٤٥٦٧٨٩'[d]);
  }
  
  /**
   * تحويل الكسر إلى صيغة عربية
   * @returns {string} الكسر بالعربية
   */
  toArabic() {
    if (this.num === 0) return '٠';
    const sign = this.num < 0 ? '-' : '';
    if (this.den === 1) return sign + this._toArabicNum(this.num);
    
    // الكسور الشائعة في الميراث مع رموزها الخاصة
    const common = {
      '1/2': 'النصف',
      '1/3': 'الثلث',
      '2/3': 'ثلثا',
      '1/4': 'الربع',
      '3/4': 'ثلاثة أرباع',
      '1/6': 'السدس',
      '5/6': 'خمسة أسداس',
      '1/8': 'الثمن',
      '3/8': 'ثلاثة أثمان',
      '5/8': 'خمسة أثمان',
      '7/8': 'سبعة أثمان',
      '1/12': 'الثمن عشر',
      '5/12': 'خمسة أثنا عشر',
      '7/12': 'سبعة أثنا عشر',
      '11/12': 'أحد عشر ثمن عشر'
    };
    
    const key = `${Math.abs(this.num)}/${this.den}`;
    if (common[key]) return sign + common[key];
    
    return sign + this._toArabicNum(Math.abs(this.num)) + '/' + this._toArabicNum(this.den);
  }
  
  /**
   * الحصول على الكسر بصيغة مختصرة
   * @returns {string} الكسر المختصر
   */
  toShortArabic() {
    const common = {
      '1/2': '½', '1/3': '⅓', '2/3': '⅔', '1/4': '¼', '3/4': '¾',
      '1/6': '⅙', '5/6': '⅚', '1/8': '⅛', '3/8': '⅜', '5/8': '⅝', '7/8': '⅞'
    };
    const key = `${Math.abs(this.num)}/${this.den}`;
    return common[key] || this.toArabic();
  }
  
  /**
   * التحقق إذا كان الكسر صفراً
   * @returns {boolean}
   */
  isZero() { return this.num === 0; }
  
  /**
   * التحقق إذا كان الكسر موجباً
   * @returns {boolean}
   */
  isPositive() { return this.num > 0; }
  
  /**
   * التحقق إذا كان الكسر سالباً
   * @returns {boolean}
   */
  isNegative() { return this.num < 0; }
  
  /**
   * المقارنة مع كسر آخر
   * @param {Fraction|number} other - الكسر الآخر
   * @returns {boolean}
   */
  equals(other) {
    if (!(other instanceof Fraction)) other = new Fraction(other);
    return this.num === other.num && this.den === other.den;
  }
  
  /**
   * المقارنة مع كسر آخر
   * @param {Fraction|number} other - الكسر الآخر
   * @returns {number} سالب إذا كان أصغر، صفر إذا متساوي، موجب إذا أكبر
   */
  compareTo(other) {
    if (!(other instanceof Fraction)) other = new Fraction(other);
    return this.num * other.den - other.num * this.den;
  }
  
  /**
   * التحقق إذا كان أصغر من كسر آخر
   * @param {Fraction|number} other - الكسر الآخر
   * @returns {boolean}
   */
  lessThan(other) { return this.compareTo(other) < 0; }
  
  /**
   * التحقق إذا كان أكبر من كفر آخر
   * @param {Fraction|number} other - الكسر الآخر
   * @returns {boolean}
   */
  greaterThan(other) { return this.compareTo(other) > 0; }
  
  /**
   * التحقق إذا كان أصغر أو يساوي كسر آخر
   * @param {Fraction|number} other - الكسر الآخر
   * @returns {boolean}
   */
  lessThanOrEqual(other) { return this.compareTo(other) <= 0; }
  
  /**
   * التحقق إذا كان أكبر أو يساوي كسر آخر
   * @param {Fraction|number} other - الكسر الآخر
   * @returns {boolean}
   */
  greaterThanOrEqual(other) { return this.compareTo(other) >= 0; }
  
  /**
   * إنشاء نسخة طبق الأصل
   * @returns {Fraction}
   */
  clone() { return new Fraction(this.num, this.den); }
  
  /**
   * الحصول على القيمة المطلقة
   * @returns {Fraction}
   */
  abs() { return new Fraction(Math.abs(this.num), this.den); }
  
  /**
   * رفع للأس
   * @param {number} n - الأس
   * @returns {Fraction}
   */
  pow(n) {
    return new Fraction(Math.pow(this.num, n), Math.pow(this.den, n));
  }
  
  // الثوابت الثابتة
  static ZERO = Object.freeze(new Fraction(0));
  static ONE = Object.freeze(new Fraction(1));
  static HALF = Object.freeze(new Fraction(1, 2));
  static THIRD = Object.freeze(new Fraction(1, 3));
  static QUARTER = Object.freeze(new Fraction(1, 4));
  static SIXTH = Object.freeze(new Fraction(1, 6));
  static EIGHTH = Object.freeze(new Fraction(1, 8));
  static TWO_THIRDS = Object.freeze(new Fraction(2, 3));
  static THREE_QUARTERS = Object.freeze(new Fraction(3, 4));
  static FIVE_SIXTHS = Object.freeze(new Fraction(5, 6));
}

export default Fraction;
