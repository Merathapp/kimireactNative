/**
 * @fileoverview نظام التنقل الرئيسي
 * @module navigation/AppNavigator
 */

import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { useTheme } from '../contexts';

// الشاشات
import CalculatorScreen from '../screens/CalculatorScreen';
import ComparisonScreen from '../screens/ComparisonScreen';
import TestsScreen from '../screens/TestsScreen';
import RulesScreen from '../screens/RulesScreen';
import AuditScreen from '../screens/AuditScreen';
import AboutScreen from '../screens/AboutScreen';
import SettingsScreen from '../screens/SettingsScreen';
import FavoritesScreen from '../screens/FavoritesScreen';
import LearningScreen from '../screens/LearningScreen';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

// أيقونة التبويب المخصصة
const TabIcon = ({ icon, label, focused, theme }) => (
  <View style={styles.tabIconContainer}>
    <View style={[
      styles.iconContainer,
      focused && { backgroundColor: theme.colors.primary + '20' }
    ]}>
      <Text style={[
        styles.tabIcon,
        focused && { color: theme.colors.primary }
      ]}>
        {icon}
      </Text>
    </View>
    <Text style={[
      styles.tabLabel,
      { color: focused ? theme.colors.primary : theme.colors.textSecondary }
    ]}>
      {label}
    </Text>
  </View>
);

// شريط التبويبات الرئيسي
const MainTabs = () => {
  const { theme } = useTheme();
  
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: true,
        tabBarStyle: [
          styles.tabBar,
          { 
            backgroundColor: theme.colors.surface,
            borderTopColor: theme.colors.border 
          }
        ],
        tabBarActiveTintColor: theme.colors.primary,
        tabBarInactiveTintColor: theme.colors.textSecondary,
        headerStyle: [
          styles.header,
          { backgroundColor: theme.colors.surface }
        ],
        headerTitleStyle: [
          styles.headerTitle,
          { color: theme.colors.text }
        ],
        headerTitleAlign: 'center',
        tabBarShowLabel: false,
        tabBarButton: (props) => (
          <TouchableOpacity
            {...props}
            activeOpacity={0.7}
            style={styles.tabButton}
          />
        )
      })}
    >
      <Tab.Screen
        name="Calculator"
        component={CalculatorScreen}
        options={{
          title: 'الحاسبة',
          tabBarIcon: ({ focused }) => (
            <TabIcon icon="⚖️" label="الحاسبة" focused={focused} theme={theme} />
          ),
        }}
      />
      <Tab.Screen
        name="Comparison"
        component={ComparisonScreen}
        options={{
          title: 'مقارنة',
          tabBarIcon: ({ focused }) => (
            <TabIcon icon="📊" label="مقارنة" focused={focused} theme={theme} />
          ),
        }}
      />
      <Tab.Screen
        name="Learning"
        component={LearningScreen}
        options={{
          title: 'تعلم',
          tabBarIcon: ({ focused }) => (
            <TabIcon icon="📚" label="تعلم" focused={focused} theme={theme} />
          ),
        }}
      />
      <Tab.Screen
        name="Rules"
        component={RulesScreen}
        options={{
          title: 'القواعد',
          tabBarIcon: ({ focused }) => (
            <TabIcon icon="📜" label="القواعد" focused={focused} theme={theme} />
          ),
        }}
      />
      <Tab.Screen
        name="More"
        component={MoreStack}
        options={{
          title: 'المزيد',
          tabBarIcon: ({ focused }) => (
            <TabIcon icon="☰" label="المزيد" focused={focused} theme={theme} />
          ),
        }}
      />
    </Tab.Navigator>
  );
};

// مكدس المزيد
const MoreStack = () => {
  const { theme } = useTheme();
  
  return (
    <Stack.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: theme.colors.surface },
        headerTitleStyle: { color: theme.colors.text },
        headerTintColor: theme.colors.primary,
        headerTitleAlign: 'center'
      }}
    >
      <Stack.Screen 
        name="MoreMenu" 
        component={MoreMenuScreen} 
        options={{ title: 'المزيد' }}
      />
      <Stack.Screen 
        name="Tests" 
        component={TestsScreen} 
        options={{ title: 'اختبارات' }}
      />
      <Stack.Screen 
        name="Audit" 
        component={AuditScreen} 
        options={{ title: 'السجل' }}
      />
      <Stack.Screen 
        name="Favorites" 
        component={FavoritesScreen} 
        options={{ title: 'المفضلة' }}
      />
      <Stack.Screen 
        name="Settings" 
        component={SettingsScreen} 
        options={{ title: 'الإعدادات' }}
      />
      <Stack.Screen 
        name="About" 
        component={AboutScreen} 
        options={{ title: 'حول التطبيق' }}
      />
    </Stack.Navigator>
  );
};

// شاشة قائمة المزيد
const MoreMenuScreen = ({ navigation }) => {
  const { theme } = useTheme();
  
  const menuItems = [
    { icon: '✅', title: 'اختبارات', screen: 'Tests' },
    { icon: '📋', title: 'السجل', screen: 'Audit' },
    { icon: '⭐', title: 'المفضلة', screen: 'Favorites' },
    { icon: '⚙️', title: 'الإعدادات', screen: 'Settings' },
    { icon: 'ℹ️', title: 'حول التطبيق', screen: 'About' },
  ];
  
  return (
    <View style={[styles.menuContainer, { backgroundColor: theme.colors.background }]}>
      {menuItems.map((item, index) => (
        <TouchableOpacity
          key={index}
          style={[styles.menuItem, { backgroundColor: theme.colors.surface }]}
          onPress={() => navigation.navigate(item.screen)}
          activeOpacity={0.7}
        >
          <Text style={styles.menuIcon}>{item.icon}</Text>
          <Text style={[styles.menuTitle, { color: theme.colors.text }]}>
            {item.title}
          </Text>
          <Text style={[styles.menuArrow, { color: theme.colors.textSecondary }]}>
            ←
          </Text>
        </TouchableOpacity>
      ))}
    </View>
  );
};

// الملاح الرئيسي
const AppNavigator = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Main" component={MainTabs} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

const styles = StyleSheet.create({
  tabBar: {
    height: 80,
    paddingBottom: 12,
    paddingTop: 8,
    borderTopWidth: 1,
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  tabButton: {
    flex: 1,
  },
  header: {
    elevation: 0,
    shadowOpacity: 0,
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '700',
  },
  tabIconContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 4,
  },
  iconContainer: {
    width: 44,
    height: 44,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 2,
  },
  tabIcon: {
    fontSize: 22,
  },
  tabLabel: {
    fontSize: 11,
    fontWeight: '600',
  },
  menuContainer: {
    flex: 1,
    padding: 16,
  },
  menuItem: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  menuIcon: {
    fontSize: 24,
    marginLeft: 16,
  },
  menuTitle: {
    flex: 1,
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'right',
  },
  menuArrow: {
    fontSize: 18,
  },
});

export default AppNavigator;
