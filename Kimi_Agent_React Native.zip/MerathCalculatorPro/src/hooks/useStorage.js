/**
 * @fileoverview Hook للتعامل مع التخزين المحلي
 * @module hooks/useStorage
 */

import { useState, useEffect, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

/**
 * Hook للتعامل مع AsyncStorage
 * @param {string} key - مفتاح التخزين
 * @param {*} initialValue - القيمة الافتراضية
 * @returns {Array} [value, setValue, loading, error]
 */
export const useStorage = (key, initialValue = null) => {
  const [value, setValue] = useState(initialValue);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  // تحميل القيمة
  useEffect(() => {
    const loadValue = async () => {
      try {
        setLoading(true);
        const stored = await AsyncStorage.getItem(key);
        if (stored !== null) {
          setValue(JSON.parse(stored));
        }
      } catch (err) {
        setError(err);
      } finally {
        setLoading(false);
      }
    };
    
    loadValue();
  }, [key]);
  
  // حفظ القيمة
  const saveValue = useCallback(async (newValue) => {
    try {
      setLoading(true);
      setValue(newValue);
      await AsyncStorage.setItem(key, JSON.stringify(newValue));
      return true;
    } catch (err) {
      setError(err);
      return false;
    } finally {
      setLoading(false);
    }
  }, [key]);
  
  // حذف القيمة
  const removeValue = useCallback(async () => {
    try {
      setLoading(true);
      setValue(initialValue);
      await AsyncStorage.removeItem(key);
      return true;
    } catch (err) {
      setError(err);
      return false;
    } finally {
      setLoading(false);
    }
  }, [key, initialValue]);
  
  return [value, saveValue, removeValue, loading, error];
};

/**
 * Hook للتعامل مع الإعدادات
 * @returns {Object} إدارة الإعدادات
 */
export const useSettings = () => {
  const [settings, setSettings, , loading] = useStorage('@app_settings', {
    madhhab: 'shafii',
    language: 'ar',
    notifications: true,
    hapticFeedback: true,
    soundEffects: false,
    showCalculationSteps: true,
    defaultEstate: ''
  });
  
  const updateSetting = useCallback(async (key, value) => {
    const newSettings = { ...settings, [key]: value };
    await setSettings(newSettings);
  }, [settings, setSettings]);
  
  return {
    settings,
    updateSetting,
    loading
  };
};

/**
 * Hook للتعامل مع المفضلة
 * @returns {Object} إدارة المفضلة
 */
export const useFavorites = () => {
  const [favorites, setFavorites, , loading] = useStorage('@favorites', []);
  
  const addFavorite = useCallback(async (calculation) => {
    const newFavorite = {
      ...calculation,
      id: Date.now().toString(),
      timestamp: new Date().toISOString()
    };
    await setFavorites([newFavorite, ...favorites].slice(0, 100));
    return newFavorite.id;
  }, [favorites, setFavorites]);
  
  const removeFavorite = useCallback(async (id) => {
    await setFavorites(favorites.filter(f => f.id !== id));
  }, [favorites, setFavorites]);
  
  const isFavorite = useCallback((id) => {
    return favorites.some(f => f.id === id);
  }, [favorites]);
  
  return {
    favorites,
    addFavorite,
    removeFavorite,
    isFavorite,
    loading
  };
};

export default useStorage;
