/**
 * @fileoverview نقطة دخول الـ Hooks
 * @module hooks
 */

export { useStorage, useSettings, useFavorites } from './useStorage';
