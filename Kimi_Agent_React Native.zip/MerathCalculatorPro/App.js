/**
 * @fileoverview التطبيق الرئيسي
 * @module App
 */

import React, { useEffect } from 'react';
import { StatusBar } from 'expo-status-bar';
import { View, StyleSheet, LogBox } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import Toast from 'react-native-toast-message';

// السياقات
import { ThemeProvider, CalculatorProvider } from './src/contexts';

// التنقل
import AppNavigator from './src/navigation/AppNavigator';

// إخفاء التحذيرات غير الضرورية
LogBox.ignoreLogs([
  'Non-serializable values were found in the navigation state',
  'ViewPropTypes will be removed',
  'AsyncStorage has been extracted'
]);

/**
 * مكون التطبيق الرئيسي
 * @returns {JSX.Element}
 */
export default function App() {
  useEffect(() => {
    // تهيئة التطبيق
    initializeApp();
  }, []);
  
  const initializeApp = async () => {
    // يمكن إضافة تهيئة إضافية هنا
    // مثل: Analytics, Crash Reporting, etc.
  };
  
  return (
    <GestureHandlerRootView style={styles.container}>
      <SafeAreaProvider>
        <ThemeProvider>
          <CalculatorProvider>
            <View style={styles.container}>
              <StatusBar style="auto" />
              <AppNavigator />
              <Toast />
            </View>
          </CalculatorProvider>
        </ThemeProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});
