/**
 * @fileoverview نقطة دخول التطبيق
 * @module index
 */

import { registerRootComponent } from 'expo';
import App from './App';

// تسجيل مكون الجذر
registerRootComponent(App);
